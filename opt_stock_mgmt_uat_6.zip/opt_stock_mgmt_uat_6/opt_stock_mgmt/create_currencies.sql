insert into currency(name,symbol,creation_date,last_update_date,creator,updater) values ('US Dollar','$',current_timestamp(),current_timestamp(),'SYSTEM','SYSTEM');
commit;