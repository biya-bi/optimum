insert into department(name,creation_date,last_update_date,creator,updater) values ('Sample Department',current_timestamp(),current_timestamp(),'SYSTEM','SYSTEM');
commit;