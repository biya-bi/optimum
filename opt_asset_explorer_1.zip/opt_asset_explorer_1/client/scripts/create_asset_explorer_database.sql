-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema optimum_asset_explorer
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `optimum_asset_explorer` ;

-- -----------------------------------------------------
-- Schema optimum_asset_explorer
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `optimum_asset_explorer` DEFAULT CHARACTER SET utf8 ;
USE `optimum_asset_explorer` ;

-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`address` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE1` VARCHAR(255) NULL DEFAULT NULL,
  `LINE2` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`schedule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`schedule` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DAY_OF_MONTH` VARCHAR(255) NULL DEFAULT NULL,
  `DAY_OF_WEEK` VARCHAR(255) NULL DEFAULT NULL,
  `HOUR` TINYINT(4) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `MINUTE` TINYINT(4) NULL DEFAULT NULL,
  `MONTH` VARCHAR(255) NULL DEFAULT NULL,
  `SECOND` TINYINT(4) NULL DEFAULT NULL,
  `TIMER_HANDLE` LONGBLOB NULL DEFAULT NULL,
  `TIME_ZONE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `YEAR` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 103
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`alert`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`alert` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `ALERT_CATEGORY` VARCHAR(255) NOT NULL,
  `ALERT_TYPE` VARCHAR(255) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `IS_ENABLED` TINYINT(1) NOT NULL DEFAULT '0',
  `IS_IMMEDIATE` TINYINT(1) NOT NULL DEFAULT '0',
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `SCHEDULE_ID` INT(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_ALERT_0` (`ALERT_TYPE` ASC, `ALERT_CATEGORY` ASC),
  INDEX `FK_ALERT_SCHEDULE_ID` (`SCHEDULE_ID` ASC),
  CONSTRAINT `FK_ALERT_SCHEDULE_ID`
    FOREIGN KEY (`SCHEDULE_ID`)
    REFERENCES `optimum_asset_explorer`.`schedule` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 103
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`alert_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`alert_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ALERT_CATEGORY` VARCHAR(255) NOT NULL,
  `ALERT_TYPE` VARCHAR(255) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `IS_ENABLED` TINYINT(1) NOT NULL DEFAULT '0',
  `ID` INT(11) NULL DEFAULT NULL,
  `IS_IMMEDIATE` TINYINT(1) NOT NULL DEFAULT '0',
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `SCHEDULE_ID` INT(11) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`locale`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`locale` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LANGUAGE_CODE` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LCID` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 109
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`email_recipient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`email_recipient` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `EMAIL` VARCHAR(255) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `LOCALE_ID` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `EMAIL` (`EMAIL` ASC),
  INDEX `FK_EMAIL_RECIPIENT_LOCALE_ID` (`LOCALE_ID` ASC),
  CONSTRAINT `FK_EMAIL_RECIPIENT_LOCALE_ID`
    FOREIGN KEY (`LOCALE_ID`)
    REFERENCES `optimum_asset_explorer`.`locale` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 108
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`alert_email_recipient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`alert_email_recipient` (
  `ALERT_ID` INT(11) NOT NULL,
  `EMAIL_RECIPIENT_ID` INT(11) NOT NULL,
  PRIMARY KEY (`ALERT_ID`, `EMAIL_RECIPIENT_ID`),
  INDEX `FK_ALERT_EMAIL_RECIPIENT_EMAIL_RECIPIENT_ID` (`EMAIL_RECIPIENT_ID` ASC),
  CONSTRAINT `FK_ALERT_EMAIL_RECIPIENT_ALERT_ID`
    FOREIGN KEY (`ALERT_ID`)
    REFERENCES `optimum_asset_explorer`.`alert` (`ID`),
  CONSTRAINT `FK_ALERT_EMAIL_RECIPIENT_EMAIL_RECIPIENT_ID`
    FOREIGN KEY (`EMAIL_RECIPIENT_ID`)
    REFERENCES `optimum_asset_explorer`.`email_recipient` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`email_template`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`email_template` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `CONTENT` TEXT NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `SUBJECT` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `LOCALE_ID` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC),
  INDEX `FK_EMAIL_TEMPLATE_LOCALE_ID` (`LOCALE_ID` ASC),
  CONSTRAINT `FK_EMAIL_TEMPLATE_LOCALE_ID`
    FOREIGN KEY (`LOCALE_ID`)
    REFERENCES `optimum_asset_explorer`.`locale` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 108
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`alert_email_template`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`alert_email_template` (
  `ALERT_ID` INT(11) NOT NULL,
  `EMAIL_TEMPLATE_ID` INT(11) NOT NULL,
  PRIMARY KEY (`ALERT_ID`, `EMAIL_TEMPLATE_ID`),
  INDEX `FK_ALERT_EMAIL_TEMPLATE_EMAIL_TEMPLATE_ID` (`EMAIL_TEMPLATE_ID` ASC),
  CONSTRAINT `FK_ALERT_EMAIL_TEMPLATE_ALERT_ID`
    FOREIGN KEY (`ALERT_ID`)
    REFERENCES `optimum_asset_explorer`.`alert` (`ID`),
  CONSTRAINT `FK_ALERT_EMAIL_TEMPLATE_EMAIL_TEMPLATE_ID`
    FOREIGN KEY (`EMAIL_TEMPLATE_ID`)
    REFERENCES `optimum_asset_explorer`.`email_template` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `CRITICAL_STOCK_DATE` DATE NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `NUMBER` VARCHAR(255) NOT NULL,
  `REORDER_POINT` SMALLINT(6) NOT NULL,
  `SAFETY_STOCK_LEVEL` SMALLINT(6) NULL DEFAULT NULL,
  `STOCK_COVER` SMALLINT(6) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC),
  UNIQUE INDEX `NUMBER` (`NUMBER` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 110
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`currency`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`currency` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `SYMBOL` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 101
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`site`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`site` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ADDRESS` VARCHAR(255) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DATE_OF_COMMISSIONING` DATE NULL DEFAULT NULL,
  `DATE_OF_DECOMMISSIONING` DATE NULL DEFAULT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCATION` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 107
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 108
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`asset`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`asset` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ACQUISITION_DATE` DATE NULL DEFAULT NULL,
  `ASSET_TYPE` VARCHAR(255) NULL DEFAULT NULL,
  `BAR_CODE` VARCHAR(255) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DEPRECIATION_METHOD` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `EXPIRY_DATE` DATE NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `MANUFACTURER` VARCHAR(255) NOT NULL,
  `MANUFACTURER_BUSINESS_IMPACT` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `PURCHASE_COST` DOUBLE NULL DEFAULT NULL,
  `SERIAL_NUMBER` VARCHAR(255) NOT NULL,
  `ASSET_STATE` VARCHAR(255) NULL DEFAULT NULL,
  `TAG` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WARRANTY_EXPIRY_DATE` DATE NULL DEFAULT NULL,
  `PRODUCT_ID` BIGINT(20) NULL DEFAULT NULL,
  `PURCHASE_CURRENCY_ID` INT(11) NULL DEFAULT NULL,
  `SITE_ID` BIGINT(20) NULL DEFAULT NULL,
  `VENDOR_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `SERIAL_NUMBER` (`SERIAL_NUMBER` ASC),
  INDEX `FK_ASSET_VENDOR_ID` (`VENDOR_ID` ASC),
  INDEX `FK_ASSET_PRODUCT_ID` (`PRODUCT_ID` ASC),
  INDEX `FK_ASSET_SITE_ID` (`SITE_ID` ASC),
  INDEX `FK_ASSET_PURCHASE_CURRENCY_ID` (`PURCHASE_CURRENCY_ID` ASC),
  CONSTRAINT `FK_ASSET_PRODUCT_ID`
    FOREIGN KEY (`PRODUCT_ID`)
    REFERENCES `optimum_asset_explorer`.`product` (`ID`),
  CONSTRAINT `FK_ASSET_PURCHASE_CURRENCY_ID`
    FOREIGN KEY (`PURCHASE_CURRENCY_ID`)
    REFERENCES `optimum_asset_explorer`.`currency` (`ID`),
  CONSTRAINT `FK_ASSET_SITE_ID`
    FOREIGN KEY (`SITE_ID`)
    REFERENCES `optimum_asset_explorer`.`site` (`ID`),
  CONSTRAINT `FK_ASSET_VENDOR_ID`
    FOREIGN KEY (`VENDOR_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`asset_document`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`asset_document` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `DOCUMENT_TYPE` VARCHAR(255) NOT NULL,
  `FILE_CONTENT` LONGBLOB NOT NULL,
  `FILE_CONTENT_TYPE` VARCHAR(255) NOT NULL,
  `FILE_NAME` VARCHAR(255) NOT NULL,
  `FILE_SIZE` BIGINT(20) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `ASSET_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_ASSET_DOCUMENT_ASSET_ID` (`ASSET_ID` ASC),
  CONSTRAINT `FK_ASSET_DOCUMENT_ASSET_ID`
    FOREIGN KEY (`ASSET_ID`)
    REFERENCES `optimum_asset_explorer`.`asset` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`asset_document_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`asset_document_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `SITE_ID` BIGINT(20) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `DOCUMENT_TYPE` VARCHAR(255) NOT NULL,
  `FILE_CONTENT` LONGBLOB NULL DEFAULT NULL,
  `FILE_NAME` VARCHAR(255) NOT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_address` (
  `ADDRESS_ID` BIGINT(20) NOT NULL,
  `ADDRESS_TYPE` VARCHAR(255) NOT NULL,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ADDRESS_ID`),
  UNIQUE INDEX `UNQ_BUSINESS_ENTITY_ADDRESS_0` (`BUSINESS_ENTITY_ID` ASC, `ADDRESS_TYPE` ASC),
  CONSTRAINT `FK_BUSINESS_ENTITY_ADDRESS_ADDRESS_ID`
    FOREIGN KEY (`ADDRESS_ID`)
    REFERENCES `optimum_asset_explorer`.`address` (`ID`),
  CONSTRAINT `FK_BUSINESS_ENTITY_ADDRESS_BUSINESS_ENTITY_ID`
    FOREIGN KEY (`BUSINESS_ENTITY_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_address_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_address_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ADDRESS_TYPE` VARCHAR(255) NOT NULL,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `ADDRESS_ID` BIGINT(20) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE1` VARCHAR(255) NULL DEFAULT NULL,
  `LINE2` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`email`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`email` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_email`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_email` (
  `EMAIL_ID` BIGINT(20) NOT NULL,
  `EMAIL_TYPE` VARCHAR(255) NOT NULL,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`EMAIL_ID`),
  UNIQUE INDEX `UNQ_BUSINESS_ENTITY_EMAIL_0` (`BUSINESS_ENTITY_ID` ASC, `EMAIL_TYPE` ASC),
  CONSTRAINT `FK_BUSINESS_ENTITY_EMAIL_BUSINESS_ENTITY_ID`
    FOREIGN KEY (`BUSINESS_ENTITY_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`),
  CONSTRAINT `FK_BUSINESS_ENTITY_EMAIL_EMAIL_ID`
    FOREIGN KEY (`EMAIL_ID`)
    REFERENCES `optimum_asset_explorer`.`email` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_email_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_email_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `EMAIL_TYPE` VARCHAR(255) NOT NULL,
  `EMAIL_ID` BIGINT(20) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`fax`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`fax` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_fax`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_fax` (
  `FAX_ID` BIGINT(20) NOT NULL,
  `FAX_TYPE` VARCHAR(255) NOT NULL,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`FAX_ID`),
  UNIQUE INDEX `UNQ_BUSINESS_ENTITY_FAX_0` (`BUSINESS_ENTITY_ID` ASC, `FAX_TYPE` ASC),
  CONSTRAINT `FK_BUSINESS_ENTITY_FAX_BUSINESS_ENTITY_ID`
    FOREIGN KEY (`BUSINESS_ENTITY_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`),
  CONSTRAINT `FK_BUSINESS_ENTITY_FAX_FAX_ID`
    FOREIGN KEY (`FAX_ID`)
    REFERENCES `optimum_asset_explorer`.`fax` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_fax_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_fax_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `FAX_TYPE` VARCHAR(255) NOT NULL,
  `FAX_ID` BIGINT(20) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`phone`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`phone` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_phone`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_phone` (
  `PHONE_ID` BIGINT(20) NOT NULL,
  `PHONE_TYPE` VARCHAR(255) NOT NULL,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`PHONE_ID`),
  UNIQUE INDEX `UNQ_BUSINESS_ENTITY_PHONE_0` (`BUSINESS_ENTITY_ID` ASC, `PHONE_TYPE` ASC),
  CONSTRAINT `FK_BUSINESS_ENTITY_PHONE_BUSINESS_ENTITY_ID`
    FOREIGN KEY (`BUSINESS_ENTITY_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`),
  CONSTRAINT `FK_BUSINESS_ENTITY_PHONE_PHONE_ID`
    FOREIGN KEY (`PHONE_ID`)
    REFERENCES `optimum_asset_explorer`.`phone` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`business_entity_phone_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`business_entity_phone_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `BUSINESS_ENTITY_ID` BIGINT(20) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `PHONE_ID` BIGINT(20) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  `PHONE_TYPE` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`contact`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`contact` (
  `ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `FK_CONTACT_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`contact_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`contact_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `BIRTH_DATE` DATE NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `FIRST_NAME` VARCHAR(255) NULL DEFAULT NULL,
  `GENDER` VARCHAR(255) NOT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_NAME` VARCHAR(255) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `MIDDLE_NAME` VARCHAR(255) NULL DEFAULT NULL,
  `NAME_STYLE` TINYINT(1) NOT NULL DEFAULT '0',
  `SUFFIX` VARCHAR(255) NULL DEFAULT NULL,
  `TITLE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`department` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 101
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`document`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`document` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `REFERENCE_NUMBER` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 134
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`email_recipient_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`email_recipient_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `EMAIL` VARCHAR(255) NOT NULL,
  `ID` INT(11) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCALE_ID` INT(11) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`email_template_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`email_template_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CONTENT` TEXT NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` INT(11) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCALE_ID` INT(11) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `SUBJECT` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`locale_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`locale_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `ID` INT(11) NULL DEFAULT NULL,
  `LANGUAGE_CODE` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LCID` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`location`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`location` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 114
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`location_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`location_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`person`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`person` (
  `ID` BIGINT(20) NOT NULL,
  `BIRTH_DATE` DATE NULL DEFAULT NULL,
  `FIRST_NAME` VARCHAR(255) NULL DEFAULT NULL,
  `GENDER` VARCHAR(255) NOT NULL,
  `LAST_NAME` VARCHAR(255) NOT NULL,
  `MIDDLE_NAME` VARCHAR(255) NULL DEFAULT NULL,
  `NAME_STYLE` TINYINT(1) NOT NULL DEFAULT '0',
  `SUFFIX` VARCHAR(255) NULL DEFAULT NULL,
  `TITLE` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `FK_PERSON_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_alert_info`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_alert_info` (
  `ALERT_DATE` DATETIME NOT NULL,
  `ALERT_TYPE` VARCHAR(255) NOT NULL,
  `AVAILABLE_QUANTITY` SMALLINT(6) NOT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `REORDER_POINT` SMALLINT(6) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  `LOCATION_ID` BIGINT(20) NOT NULL,
  `ALERT_CATEGORY` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`PRODUCT_ID`, `LOCATION_ID`, `ALERT_CATEGORY`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `CRITICAL_STOCK_DATE` DATE NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `NUMBER` VARCHAR(255) NOT NULL,
  `REORDER_POINT` SMALLINT(6) NOT NULL,
  `SAFETY_STOCK_LEVEL` SMALLINT(6) NULL DEFAULT NULL,
  `STOCK_COVER` SMALLINT(6) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_inventory`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_inventory` (
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `QUANTITY` SMALLINT(6) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  `LOCATION_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`PRODUCT_ID`, `LOCATION_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_issue`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_issue` (
  `ID` BIGINT(20) NOT NULL,
  `ISSUE_DATE` DATE NOT NULL,
  `REQUISITIONER` VARCHAR(255) NOT NULL,
  `DEPARTMENT_ID` INT(11) NULL DEFAULT NULL,
  `LOCATION_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_PRODUCT_ISSUE_DEPARTMENT_ID` (`DEPARTMENT_ID` ASC),
  INDEX `FK_PRODUCT_ISSUE_LOCATION_ID` (`LOCATION_ID` ASC),
  CONSTRAINT `FK_PRODUCT_ISSUE_DEPARTMENT_ID`
    FOREIGN KEY (`DEPARTMENT_ID`)
    REFERENCES `optimum_asset_explorer`.`department` (`ID`),
  CONSTRAINT `FK_PRODUCT_ISSUE_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`document` (`ID`),
  CONSTRAINT `FK_PRODUCT_ISSUE_LOCATION_ID`
    FOREIGN KEY (`LOCATION_ID`)
    REFERENCES `optimum_asset_explorer`.`location` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_issue_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_issue_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DEPARTMENTID` INT(11) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `ISSUE_DATE` DATE NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCATION_ID` BIGINT(20) NOT NULL,
  `REFERENCE_NUMBER` VARCHAR(255) NOT NULL,
  `REQUISITIONER` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_issue_detail`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_issue_detail` (
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `QUANTITY` SMALLINT(6) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `PRODUCT_ISSUE_ID` BIGINT(20) NOT NULL,
  `DETAIL_ID` INT(11) NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`PRODUCT_ISSUE_ID`, `DETAIL_ID`),
  INDEX `FK_PRODUCT_ISSUE_DETAIL_PRODUCT_ID` (`PRODUCT_ID` ASC),
  CONSTRAINT `FK_PRODUCT_ISSUE_DETAIL_PRODUCT_ID`
    FOREIGN KEY (`PRODUCT_ID`)
    REFERENCES `optimum_asset_explorer`.`product` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_issue_detail_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_issue_detail_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  `QUANTITY` SMALLINT(6) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  `DETAIL_ID` INT(11) NULL DEFAULT NULL,
  `PRODUCT_ISSUE_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 41
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_receipt`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_receipt` (
  `ID` BIGINT(20) NOT NULL,
  `RECEIPT_DATE` DATE NOT NULL,
  `CURRENCY_ID` INT(11) NOT NULL,
  `LOCATION_ID` BIGINT(20) NOT NULL,
  `VENDOR_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_PRODUCT_RECEIPT_VENDOR_ID` (`VENDOR_ID` ASC),
  INDEX `FK_PRODUCT_RECEIPT_CURRENCY_ID` (`CURRENCY_ID` ASC),
  INDEX `FK_PRODUCT_RECEIPT_LOCATION_ID` (`LOCATION_ID` ASC),
  CONSTRAINT `FK_PRODUCT_RECEIPT_CURRENCY_ID`
    FOREIGN KEY (`CURRENCY_ID`)
    REFERENCES `optimum_asset_explorer`.`currency` (`ID`),
  CONSTRAINT `FK_PRODUCT_RECEIPT_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`document` (`ID`),
  CONSTRAINT `FK_PRODUCT_RECEIPT_LOCATION_ID`
    FOREIGN KEY (`LOCATION_ID`)
    REFERENCES `optimum_asset_explorer`.`location` (`ID`),
  CONSTRAINT `FK_PRODUCT_RECEIPT_VENDOR_ID`
    FOREIGN KEY (`VENDOR_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_receipt_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_receipt_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `CURRENCY_ID` INT(11) NOT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCATION_ID` BIGINT(20) NOT NULL,
  `RECEIPT_DATE` DATE NOT NULL,
  `REFERENCE_NUMBER` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VENDOR_ID` BIGINT(20) NOT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_receipt_detail`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_receipt_detail` (
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `QUANTITY` SMALLINT(6) NOT NULL,
  `UNIT_PRICE` DOUBLE NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `DETAIL_ID` INT(11) NOT NULL,
  `PRODUCT_RECEIPT_ID` BIGINT(20) NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`DETAIL_ID`, `PRODUCT_RECEIPT_ID`),
  INDEX `FK_PRODUCT_RECEIPT_DETAIL_PRODUCT_ID` (`PRODUCT_ID` ASC),
  CONSTRAINT `FK_PRODUCT_RECEIPT_DETAIL_PRODUCT_ID`
    FOREIGN KEY (`PRODUCT_ID`)
    REFERENCES `optimum_asset_explorer`.`product` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`product_receipt_detail_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`product_receipt_detail_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  `QUANTITY` SMALLINT(6) NOT NULL,
  `UNIT_PRICE` DOUBLE NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  `DETAIL_ID` INT(11) NULL DEFAULT NULL,
  `PRODUCT_RECEIPT_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 37
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`ship_method`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`ship_method` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_SHIP_METHOD_0` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 107
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`purchase_order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`purchase_order` (
  `ID` BIGINT(20) NOT NULL,
  `FREIGHT` DOUBLE NOT NULL,
  `REVISION_NUMBER` TINYINT(4) NULL DEFAULT NULL,
  `SHIP_DATE` DATE NULL DEFAULT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `TAX_AMOUNT` DOUBLE NOT NULL,
  `LOCATION_ID` BIGINT(20) NULL DEFAULT NULL,
  `SHIP_METHOD_ID` BIGINT(20) NULL DEFAULT NULL,
  `VENDOR_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_PURCHASE_ORDER_SHIP_METHOD_ID` (`SHIP_METHOD_ID` ASC),
  INDEX `FK_PURCHASE_ORDER_LOCATION_ID` (`LOCATION_ID` ASC),
  INDEX `FK_PURCHASE_ORDER_VENDOR_ID` (`VENDOR_ID` ASC),
  CONSTRAINT `FK_PURCHASE_ORDER_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`document` (`ID`),
  CONSTRAINT `FK_PURCHASE_ORDER_LOCATION_ID`
    FOREIGN KEY (`LOCATION_ID`)
    REFERENCES `optimum_asset_explorer`.`location` (`ID`),
  CONSTRAINT `FK_PURCHASE_ORDER_SHIP_METHOD_ID`
    FOREIGN KEY (`SHIP_METHOD_ID`)
    REFERENCES `optimum_asset_explorer`.`ship_method` (`ID`),
  CONSTRAINT `FK_PURCHASE_ORDER_VENDOR_ID`
    FOREIGN KEY (`VENDOR_ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`purchase_order_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`purchase_order_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `FREIGHT` DOUBLE NOT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCATION_ID` BIGINT(20) NULL DEFAULT NULL,
  `REFERENCE_NUMBER` VARCHAR(255) NOT NULL,
  `REVISION_NUMBER` TINYINT(4) NULL DEFAULT NULL,
  `SHIP_DATE` DATE NULL DEFAULT NULL,
  `SHIP_METHOD_ID` BIGINT(20) NULL DEFAULT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `TAX_AMOUNT` DOUBLE NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VENDOR_ID` BIGINT(20) NOT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 19
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`purchase_order_detail`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`purchase_order_detail` (
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DUE_DATE` DATE NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `ORDERED_QUANTITY` SMALLINT(6) NOT NULL,
  `RECEIVED_QUANTITY` SMALLINT(6) NOT NULL,
  `REJECTED_QUANTITY` SMALLINT(6) NOT NULL,
  `UNIT_PRICE` DOUBLE NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `PURCHASE_ORDER_ID` BIGINT(20) NOT NULL,
  `DETAIL_ID` INT(11) NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`PURCHASE_ORDER_ID`, `DETAIL_ID`),
  INDEX `FK_PURCHASE_ORDER_DETAIL_PRODUCT_ID` (`PRODUCT_ID` ASC),
  CONSTRAINT `FK_PURCHASE_ORDER_DETAIL_PRODUCT_ID`
    FOREIGN KEY (`PRODUCT_ID`)
    REFERENCES `optimum_asset_explorer`.`product` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`purchase_order_detail_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`purchase_order_detail_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DUE_DATE` DATE NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `ORDERED_QUANTITY` SMALLINT(6) NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  `RECEIVED_QUANTITY` SMALLINT(6) NOT NULL,
  `REJECTED_QUANTITY` SMALLINT(6) NOT NULL,
  `UNIT_PRICE` DOUBLE NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  `DETAIL_ID` INT(11) NULL DEFAULT NULL,
  `PURCHASE_ORDER_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 19
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`schedule_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`schedule_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DAY_OF_MONTH` VARCHAR(255) NULL DEFAULT NULL,
  `DAY_OF_WEEK` VARCHAR(255) NULL DEFAULT NULL,
  `HOUR` TINYINT(4) NULL DEFAULT NULL,
  `ID` INT(11) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `MINUTE` TINYINT(4) NULL DEFAULT NULL,
  `MONTH` VARCHAR(255) NULL DEFAULT NULL,
  `SECOND` TINYINT(4) NULL DEFAULT NULL,
  `TIMER_HANDLE` LONGBLOB NULL DEFAULT NULL,
  `TIME_ZONE` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  `YEAR` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`ship_method_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`ship_method_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`shipping_order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`shipping_order` (
  `ID` BIGINT(20) NOT NULL,
  `DELIVERY_DATE` DATE NULL DEFAULT NULL,
  `SHIP_DATE` DATE NULL DEFAULT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `SHIP_METHOD_ID` BIGINT(20) NOT NULL,
  `SOURCE_LOCATION_ID` BIGINT(20) NOT NULL,
  `TARGET_LOCATION_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_SHIPPING_ORDER_SHIP_METHOD_ID` (`SHIP_METHOD_ID` ASC),
  INDEX `FK_SHIPPING_ORDER_SOURCE_LOCATION_ID` (`SOURCE_LOCATION_ID` ASC),
  INDEX `FK_SHIPPING_ORDER_TARGET_LOCATION_ID` (`TARGET_LOCATION_ID` ASC),
  CONSTRAINT `FK_SHIPPING_ORDER_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`document` (`ID`),
  CONSTRAINT `FK_SHIPPING_ORDER_SHIP_METHOD_ID`
    FOREIGN KEY (`SHIP_METHOD_ID`)
    REFERENCES `optimum_asset_explorer`.`ship_method` (`ID`),
  CONSTRAINT `FK_SHIPPING_ORDER_SOURCE_LOCATION_ID`
    FOREIGN KEY (`SOURCE_LOCATION_ID`)
    REFERENCES `optimum_asset_explorer`.`location` (`ID`),
  CONSTRAINT `FK_SHIPPING_ORDER_TARGET_LOCATION_ID`
    FOREIGN KEY (`TARGET_LOCATION_ID`)
    REFERENCES `optimum_asset_explorer`.`location` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`shipping_order_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`shipping_order_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DELIVERY_DATE` DATE NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `REFERENCE_NUMBER` VARCHAR(255) NOT NULL,
  `SHIP_DATE` DATE NULL DEFAULT NULL,
  `SHIP_METHOD_ID` BIGINT(20) NOT NULL,
  `SOURCE_LOCATION_ID` BIGINT(20) NOT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `TARGET_LOCATION_ID` BIGINT(20) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 25
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`shipping_order_detail`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`shipping_order_detail` (
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `RECEIVED_QUANTITY` SMALLINT(6) NOT NULL,
  `REJECTED_QUANTITY` SMALLINT(6) NOT NULL,
  `SHIPPED_QUANTITY` SMALLINT(6) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `DETAIL_ID` INT(11) NOT NULL,
  `SHIPPING_ORDER_ID` BIGINT(20) NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`DETAIL_ID`, `SHIPPING_ORDER_ID`),
  INDEX `FK_SHIPPING_ORDER_DETAIL_PRODUCT_ID` (`PRODUCT_ID` ASC),
  CONSTRAINT `FK_SHIPPING_ORDER_DETAIL_PRODUCT_ID`
    FOREIGN KEY (`PRODUCT_ID`)
    REFERENCES `optimum_asset_explorer`.`product` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`shipping_order_detail_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`shipping_order_detail_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `PRODUCT_ID` BIGINT(20) NOT NULL,
  `RECEIVED_QUANTITY` SMALLINT(6) NOT NULL,
  `REJECTED_QUANTITY` SMALLINT(6) NOT NULL,
  `SHIPPED_QUANTITY` SMALLINT(6) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  `DETAIL_ID` INT(11) NULL DEFAULT NULL,
  `SHIPPING_ORDER_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 11
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`site_asset`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`site_asset` (
  `Site_ID` BIGINT(20) NOT NULL,
  `assets_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`Site_ID`, `assets_ID`),
  INDEX `FK_SITE_ASSET_assets_ID` (`assets_ID` ASC),
  CONSTRAINT `FK_SITE_ASSET_Site_ID`
    FOREIGN KEY (`Site_ID`)
    REFERENCES `optimum_asset_explorer`.`site` (`ID`),
  CONSTRAINT `FK_SITE_ASSET_assets_ID`
    FOREIGN KEY (`assets_ID`)
    REFERENCES `optimum_asset_explorer`.`asset` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`site_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`site_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ADDRESS` VARCHAR(255) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DATE_OF_COMMISSIONING` DATE NULL DEFAULT NULL,
  `DATE_OF_DECOMMISSIONING` DATE NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCATION` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`site_document`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`site_document` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `DOCUMENT_TYPE` VARCHAR(255) NOT NULL,
  `FILE_CONTENT` LONGBLOB NOT NULL,
  `FILE_CONTENT_TYPE` VARCHAR(255) NOT NULL,
  `FILE_NAME` VARCHAR(255) NOT NULL,
  `FILE_SIZE` BIGINT(20) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `SITE_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_SITE_DOCUMENT_SITE_ID` (`SITE_ID` ASC),
  CONSTRAINT `FK_SITE_DOCUMENT_SITE_ID`
    FOREIGN KEY (`SITE_ID`)
    REFERENCES `optimum_asset_explorer`.`site` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`site_document_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`site_document_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `DESCRIPTION` TEXT NULL DEFAULT NULL,
  `DOCUMENT_TYPE` VARCHAR(255) NOT NULL,
  `FILE_CONTENT` LONGBLOB NULL DEFAULT NULL,
  `FILE_NAME` VARCHAR(255) NOT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `SITE_ID` BIGINT(20) NOT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`stock_level_alert_column`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`stock_level_alert_column` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `COLUMN_TYPE` VARCHAR(255) NOT NULL,
  `HEADER_TEXT` VARCHAR(255) NOT NULL,
  `LOCALE_ID` INT(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_STOCK_LEVEL_ALERT_COLUMN_0` (`COLUMN_TYPE` ASC, `LOCALE_ID` ASC),
  INDEX `FK_STOCK_LEVEL_ALERT_COLUMN_LOCALE_ID` (`LOCALE_ID` ASC),
  CONSTRAINT `FK_STOCK_LEVEL_ALERT_COLUMN_LOCALE_ID`
    FOREIGN KEY (`LOCALE_ID`)
    REFERENCES `optimum_asset_explorer`.`locale` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`vendor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`vendor` (
  `ID` BIGINT(20) NOT NULL,
  `ACCOUNT_NUMBER` VARCHAR(255) NOT NULL,
  `IS_ACTIVE` TINYINT(1) NOT NULL DEFAULT '0',
  `NAME` VARCHAR(255) NOT NULL,
  `PURCHASING_URL` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_VENDOR_0` (`ACCOUNT_NUMBER` ASC),
  CONSTRAINT `FK_VENDOR_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `optimum_asset_explorer`.`business_entity` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `optimum_asset_explorer`.`vendor_audit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `optimum_asset_explorer`.`vendor_audit` (
  `AUDIT_ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_NUMBER` VARCHAR(255) NOT NULL,
  `IS_ACTIVE` TINYINT(1) NOT NULL DEFAULT '0',
  `CREATION_DATE` DATETIME NOT NULL,
  `CREATOR` VARCHAR(255) NULL DEFAULT NULL,
  `ID` BIGINT(20) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `PURCHASING_URL` VARCHAR(255) NULL DEFAULT NULL,
  `UPDATER` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_OPERATION` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`AUDIT_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
