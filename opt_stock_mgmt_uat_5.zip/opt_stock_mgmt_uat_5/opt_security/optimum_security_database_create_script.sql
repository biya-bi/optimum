-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema optimum_security
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `optimum_security` ;

-- -----------------------------------------------------
-- Schema optimum_security
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `optimum_security` DEFAULT CHARACTER SET utf8 ;
USE `optimum_security` ;

-- -----------------------------------------------------
-- Table `application`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `application` (
  `ID` VARCHAR(255) NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `cryptography_setting`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cryptography_setting` (
  `CHAR_SET` VARCHAR(255) NOT NULL,
  `DIGEST_ALGORITHM` VARCHAR(255) NOT NULL,
  `RANDOM_NUMBER_LENGTH` INT(11) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`APPLICATION_ID`),
  CONSTRAINT `FK_CRYPTOGRAPHY_SETTING_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `user` (
  `ID` VARCHAR(255) NOT NULL,
  `LAST_ACTIVITY_DATE` DATETIME NULL DEFAULT NULL,
  `USER_NAME` VARCHAR(255) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_USER_0` (`APPLICATION_ID` ASC, `USER_NAME` ASC),
  CONSTRAINT `FK_USER_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `membership`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `membership` (
  `APPROVED` TINYINT(1) NULL DEFAULT '0',
  `CREATION_DATE` DATETIME NULL DEFAULT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `EMAIL` VARCHAR(255) NULL DEFAULT NULL,
  `FAILED_PWD_ANS_ATPT_WIN_START` DATETIME NULL DEFAULT NULL,
  `FAILED_PWD_ATMPT_CNT` INT(11) NULL DEFAULT NULL,
  `FAILED_PWD_ATMPT_WIN_START` DATETIME NULL DEFAULT NULL,
  `FAILED_PWD_QUES_ANS_ATMPT_CNT` INT(11) NULL DEFAULT NULL,
  `LAST_LOCK_OUT_DATE` DATETIME NULL DEFAULT NULL,
  `LAST_LOGIN_DATE` DATETIME NULL DEFAULT NULL,
  `LAST_PWD_CHANGE_DATE` DATETIME NULL DEFAULT NULL,
  `LOCKED_OUT` TINYINT(1) NULL DEFAULT '0',
  `PASSWORD` VARCHAR(255) NULL DEFAULT NULL,
  `PASSWORD_QUESTION` VARCHAR(255) NULL DEFAULT NULL,
  `PASSWORD_QUESTION_ANSWER` VARCHAR(255) NULL DEFAULT NULL,
  `PASSWORD_SALT` VARCHAR(255) NULL DEFAULT NULL,
  `PHONE` VARCHAR(255) NULL DEFAULT NULL,
  `USER_ID` VARCHAR(255) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`USER_ID`),
  INDEX `FK_MEMBERSHIP_APPLICATION_ID` (`APPLICATION_ID` ASC),
  CONSTRAINT `FK_MEMBERSHIP_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`),
  CONSTRAINT `FK_MEMBERSHIP_USER_ID`
    FOREIGN KEY (`USER_ID`)
    REFERENCES `user` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `password_history`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `password_history` (
  `ID` VARCHAR(255) NOT NULL,
  `CHANGE_DATE` DATETIME NOT NULL,
  `PASSWORD` VARCHAR(255) NOT NULL,
  `PASSWORD_SALT` VARCHAR(255) NOT NULL,
  `MEMBERSHIP_ID` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_PASSWORD_HISTORY_MEMBERSHIP_ID` (`MEMBERSHIP_ID` ASC),
  CONSTRAINT `FK_PASSWORD_HISTORY_MEMBERSHIP_ID`
    FOREIGN KEY (`MEMBERSHIP_ID`)
    REFERENCES `membership` (`USER_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `password_policy`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `password_policy` (
  `MAXIMUM_INVALID_PASSWORD_ATTEMPTS` INT(11) NOT NULL,
  `MAXIMUM_PASSWORD_AGE` INT(11) NOT NULL,
  `MAXIMUM_PASSWORD_LENGTH` INT(11) NOT NULL,
  `MINIMUM_LOWERCASE_CHARACTERS` INT(11) NOT NULL,
  `MINIMUM_NUMERIC` INT(11) NOT NULL,
  `MINIMUM_PASSWORD_AGE` INT(11) NOT NULL,
  `MINIMUM_PASSWORD_LENGTH` INT(11) NOT NULL,
  `MINIMUM_SPECIAL_CHARACTERS` INT(11) NOT NULL,
  `MINIMUM_UPPERCASE_CHARACTERS` INT(11) NOT NULL,
  `PASSWORD_ATTEMPT_WINDOW` INT(11) NOT NULL,
  `PASSWORD_HISTORY_LENGTH` INT(11) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`APPLICATION_ID`),
  CONSTRAINT `FK_PASSWORD_POLICY_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `permission`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `permission` (
  `ID` VARCHAR(255) NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_PERMISSION_0` (`APPLICATION_ID` ASC, `NAME` ASC),
  CONSTRAINT `FK_PERMISSION_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `role` (
  `ID` VARCHAR(255) NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_ROLE_0` (`APPLICATION_ID` ASC, `NAME` ASC),
  CONSTRAINT `FK_ROLE_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `role_permission`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permission` (
  `ROLE_ID` VARCHAR(255) NOT NULL,
  `PERMISSION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ROLE_ID`, `PERMISSION_ID`),
  INDEX `FK_ROLE_PERMISSION_PERMISSION_ID` (`PERMISSION_ID` ASC),
  CONSTRAINT `FK_ROLE_PERMISSION_PERMISSION_ID`
    FOREIGN KEY (`PERMISSION_ID`)
    REFERENCES `permission` (`ID`),
  CONSTRAINT `FK_ROLE_PERMISSION_ROLE_ID`
    FOREIGN KEY (`ROLE_ID`)
    REFERENCES `role` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `token`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `token` (
  `EXPIRATION_DATE` DATETIME NOT NULL,
  `GENERATION_DATE` DATETIME NOT NULL,
  `VALUE` VARCHAR(255) NOT NULL,
  `USER_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`USER_ID`),
  CONSTRAINT `FK_TOKEN_USER_ID`
    FOREIGN KEY (`USER_ID`)
    REFERENCES `user` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `token_policy`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `token_policy` (
  `MAXIMUM_AGE` INT(11) NOT NULL,
  `APPLICATION_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`APPLICATION_ID`),
  CONSTRAINT `FK_TOKEN_POLICY_APPLICATION_ID`
    FOREIGN KEY (`APPLICATION_ID`)
    REFERENCES `application` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `user_role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_role` (
  `ROLE_ID` VARCHAR(255) NOT NULL,
  `USER_ID` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ROLE_ID`, `USER_ID`),
  INDEX `FK_USER_ROLE_USER_ID` (`USER_ID` ASC),
  CONSTRAINT `FK_USER_ROLE_ROLE_ID`
    FOREIGN KEY (`ROLE_ID`)
    REFERENCES `role` (`ID`),
  CONSTRAINT `FK_USER_ROLE_USER_ID`
    FOREIGN KEY (`USER_ID`)
    REFERENCES `user` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
