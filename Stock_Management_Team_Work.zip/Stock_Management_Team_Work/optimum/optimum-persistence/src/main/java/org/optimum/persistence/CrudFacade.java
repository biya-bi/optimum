/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.persistence;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceUnitUtil;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.optimum.persistence.exceptions.NonexistentEntityException;

/**
 *
 * @author Biya-Bi
 * @param <T>
 */
public abstract class CrudFacade<T> {

    private final Class<T> entityClass;

    public CrudFacade(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    protected abstract EntityManager getEntityManager();

    protected void validate(T entity, UpdateOperation operation) throws Exception {

    }

    public void create(T entity) throws Exception {
        validate(entity, UpdateOperation.CREATE);
        persist(entity);
    }

    protected void persist(T entity) {
        getEntityManager().persist(entity);
    }

    public void edit(T entity) throws Exception {
        validate(entity, UpdateOperation.UPDATE);
        merge(entity);
    }

    protected void merge(T entity) {
        getEntityManager().merge(entity);
    }

    public void remove(T entity) throws Exception {
        validate(entity, UpdateOperation.DELETE);
        delete(entity);
    }

    public T getPersistent(T entity) throws NonexistentEntityException {
        try {
            EntityManager em = getEntityManager();
            PersistenceUnitUtil util = em.getEntityManagerFactory().getPersistenceUnitUtil();
            Object id = util.getIdentifier(entity);
            return em.getReference(entityClass, id);
        } catch (EntityNotFoundException e) {
            throw new NonexistentEntityException("An attempt to use a non-existing entity was made.", e);
        }
    }

    protected void delete(T entity) throws NonexistentEntityException {
        getEntityManager().remove(getPersistent(entity));
    }

    public T find(Object id) {
        return getEntityManager().find(entityClass, id);
    }

    public List<T> findAll() {
        CriteriaQuery<T> cq = getEntityManager().getCriteriaBuilder().createQuery(entityClass);
        cq.select(cq.from(entityClass));
        return getEntityManager().createQuery(cq).getResultList();
    }

    public List<T> find(SearchCriteria criteria) {
        Pageable[] annotations = this.getClass().getAnnotationsByType(Pageable.class);

        if (annotations.length == 0) {
            throw new UnsupportedOperationException(String.format("The class '%s' is not annotated with an annotation of type '%s'.", this.getClass(), Pageable.class));
        }

        String attributeName = annotations[0].attributeName();

        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery();
        Root<T> rt = cq.from(entityClass);

        Expression exp = rt.get(attributeName);

        Expression<Boolean> e1 = criteria.getIds() != null && !criteria.getIds().isEmpty() ? exp.in(criteria.getIds()) : null;
        Expression<Boolean> e2 = null;

        List<Filter> filters = criteria.getFilters();
        if (filters != null && !filters.isEmpty()) {
            e2 = getExpression(filters, cb, rt, cq);
        }

        Expression<Boolean> e = and(cb, e1, e2);
        if (e != null) {
            cq = cq.select(rt).where(e);
        }
        else {
            cq = cq.select(rt);
        }
        cq = cq.orderBy(cb.asc(exp));

        TypedQuery<T> query = getEntityManager().createQuery(cq);
        if (criteria.getFilters() != null && !criteria.getFilters().isEmpty()) {
            query = setParameters(criteria.getFilters(), query);
        }

        if (criteria.getPageIndex() != null && criteria.getPageSize() != null) {
            query.setFirstResult(criteria.getPageIndex() * criteria.getPageSize());
        }
        if (criteria.getPageSize() != null) {
            query.setMaxResults(criteria.getPageSize());
        }

        return query.getResultList();
    }

    public long count(SearchCriteria criteria) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery();
        Root<T> rt = cq.from(entityClass);
        cq.select(cb.count(rt));
        Expression<Boolean> e = null;

        List<Filter> filters = criteria.getFilters();
        if (filters != null && !filters.isEmpty()) {
            e = getExpression(filters, cb, rt, cq);
        }

        if (e != null) {
            cq.where(e);
        }
        TypedQuery q = getEntityManager().createQuery(cq);
        if (criteria.getFilters() != null && criteria.getFilters().size() > 0) {
            q = setParameters(criteria.getFilters(), q);
        }
        return (long) q.getSingleResult();
    }

    protected Expression<Boolean> and(CriteriaBuilder cb, Expression<Boolean>... expressions) {
        Expression<Boolean> e = null;
        for (Expression<Boolean> expression : expressions) {
            if (expression != null) {
                if (e == null) {
                    e = expression;
                }
                else {
                    e = cb.and(e, expression);
                }
            }
        }
        return e;
    }

    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<T> rt, CriteriaQuery cq) {
        return cb.literal(true);
    }

    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query) {
        return query;
    }

    public long count() {
        CriteriaQuery<Object> cq = getEntityManager().getCriteriaBuilder().createQuery();
        Root<T> rt = cq.from(entityClass);
        cq.select(getEntityManager().getCriteriaBuilder().count(rt));
        TypedQuery<Object> q = getEntityManager().createQuery(cq);
        return (long) q.getSingleResult();
    }

    private Expression<Boolean> getNumberExpression(Class cls, Filter filter, CriteriaBuilder cb, Root<T> rt) {
        String parameterName = getParameterName(filter);
        RelationalOperator operator = filter.getOperator();
        if (operator == null) {
            // If the operator is not specified, we ignore the value.
            return cb.literal(true);
        }
        else if (operator == RelationalOperator.EQUAL) {
            if (filter.getValue() == null) {
                return cb.isNull(getPath(filter, rt));
            }
            return cb.equal(getPath(filter, rt), cb.parameter(cls, parameterName));
        }
        else if (operator == RelationalOperator.IS_EMPTY) {
            return cb.isNull(getPath(filter, rt));
        }
        else if (operator == RelationalOperator.IS_NOT_EMPTY) {
            return cb.isNotNull(getPath(filter, rt));
        }
        else if (operator == RelationalOperator.NOT_EQUAL) {
            if (filter.getValue() == null) {
                return cb.isNotNull(getPath(filter, rt));
            }
            return cb.notEqual(getPath(filter, rt), cb.parameter(cls, parameterName));
        }
        else if (operator == RelationalOperator.LESS_THAN) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.lessThan(getPath(filter, rt), cb.parameter(cls, parameterName));
        }
        else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.lessThanOrEqualTo(getPath(filter, rt), cb.parameter(cls, parameterName));
        }
        else if (operator == RelationalOperator.GREATER_THAN) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.greaterThan(getPath(filter, rt), cb.parameter(cls, parameterName));
        }
        else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(cls, parameterName));
        }
        return cb.literal(true);
    }

    private Expression<Boolean> getStringExpression(Filter filter, CriteriaBuilder cb, Root<T> rt) {
        String parameterName = getParameterName(filter);
        RelationalOperator operator = filter.getOperator();
        if (operator == null) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            // For Strings, we want the default operator to be the CONTAINS operator.
            return cb.like(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.CONTAINS) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.like(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.DOES_NOT_CONTAIN) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(false); // No string can contain NULL, even NULL itself.
            }
            return cb.not(cb.like(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName)));
        }
        else if (operator == RelationalOperator.ENDS_WITH) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.like(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.EQUAL) {
            if (filter.getValue() == null) {
                return cb.isNull(getPath(filter, rt));
            }
            return cb.equal(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.IS_EMPTY) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.or(cb.equal(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName)), cb.isNull(getPath(filter, rt)));
        }
        else if (operator == RelationalOperator.IS_NOT_EMPTY) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.isNotNull(getPath(filter, rt));
        }
        else if (operator == RelationalOperator.NOT_EQUAL) {
            if (filter.getValue() == null) {
                return cb.isNotNull(getPath(filter, rt));
            }
            return cb.notEqual(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.STARTS_WITH) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.like(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.LESS_THAN) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.lessThan(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.lessThanOrEqualTo(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.GREATER_THAN) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.greaterThan(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
            String value = (String) filter.getValue();
            if (value == null || value.trim().isEmpty()) {
                return cb.literal(true);
            }
            return cb.greaterThanOrEqualTo(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
        }
        return cb.literal(true);
    }

    protected Expression<Boolean> getExpression(Filter filter, DataType dataType, CriteriaBuilder cb, Root<T> rt, CriteriaQuery cq) {

        String parameterName = getParameterName(filter);
        RelationalOperator operator = filter.getOperator();

        if (null != dataType) {
            switch (dataType) {
                case STRING:
                    return getStringExpression(filter, cb, rt);
                case OBJECT:
                    if (operator == null) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        // For Objects, we want the default operator to be the EQUAL operator.
                        return cb.equal(getPath(filter, rt), cb.parameter(filter.getValue().getClass(), parameterName));
                    }
                    else if (operator == RelationalOperator.EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.isNull(getPath(filter, rt));
                        }
                        return cb.equal(getPath(filter, rt), cb.parameter(filter.getValue().getClass(), parameterName));
                    }
                    else if (operator == RelationalOperator.IS_EMPTY) {
                        return cb.isNull(getPath(filter, rt));
                    }
                    else if (operator == RelationalOperator.IS_NOT_EMPTY) {
                        return cb.isNotNull(getPath(filter, rt));
                    }
                    else if (operator == RelationalOperator.NOT_EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.isNotNull(getPath(filter, rt));
                        }
                        return cb.notEqual(cb.upper(getPath(filter, rt)), cb.parameter(filter.getValue().getClass(), parameterName));
                    }
                    else if (operator == RelationalOperator.LESS_THAN) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.lessThan(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
                    }
                    else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.lessThanOrEqualTo(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
                    }
                    else if (operator == RelationalOperator.GREATER_THAN) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.greaterThan(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
                    }
                    else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.greaterThanOrEqualTo(cb.upper(getPath(filter, rt)), cb.parameter(String.class, parameterName));
                    }
                    break;
                case DATE:
                    if (operator == null) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        // For Dates, we want the default operator to be the EQUAL operator.
                        return cb.equal(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    else if (operator == RelationalOperator.EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.isNull(getPath(filter, rt));
                        }
                        return cb.equal(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    else if (operator == RelationalOperator.IS_EMPTY) {
                        return cb.isNull(getPath(filter, rt));
                    }
                    else if (operator == RelationalOperator.IS_NOT_EMPTY) {
                        return cb.isNotNull(getPath(filter, rt));
                    }
                    else if (operator == RelationalOperator.NOT_EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.isNotNull(getPath(filter, rt));
                        }
                        return cb.notEqual(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    else if (operator == RelationalOperator.LESS_THAN) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.lessThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    else if (operator == RelationalOperator.GREATER_THAN) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.greaterThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
                        if (filter.getValue() == null) {
                            return cb.literal(true);
                        }
                        return cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    break;
                case BYTE:
                    return getNumberExpression(Byte.class, filter, cb, rt);
                case SHORT:
                    return getNumberExpression(Short.class, filter, cb, rt);
                case DOUBLE:
                    return getNumberExpression(Double.class, filter, cb, rt);
                default:
                    break;
            }
        }
        return cb.literal(true);
    }

    protected String getParameterName(Filter filter) {
        return filter.getFieldName();
    }

    protected TypedQuery setParameter(Filter filter, TypedQuery query, DataType dataType) {
        RelationalOperator operator = filter.getOperator();
        if (null != dataType) {
            switch (dataType) {
                case STRING:
                    if (operator == null) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), "%" + String.valueOf(filter.getValue()).trim().toUpperCase() + "%");
                        }
                    }
                    else if (operator == RelationalOperator.CONTAINS) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), "%" + String.valueOf(filter.getValue()).trim().toUpperCase() + "%");
                        }
                    }
                    else if (operator == RelationalOperator.DOES_NOT_CONTAIN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), "%" + String.valueOf(filter.getValue()).trim().toUpperCase() + "%");
                        }
                    }
                    else if (operator == RelationalOperator.ENDS_WITH) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), "%" + String.valueOf(filter.getValue()).trim().toUpperCase());
                        }
                    }
                    else if (operator == RelationalOperator.EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), String.valueOf(filter.getValue()).trim().toUpperCase());
                        }
                    }
                    else if (operator == RelationalOperator.IS_EMPTY) {
                        query.setParameter(getParameterName(filter), "");
                    }
                    else if (operator == RelationalOperator.NOT_EQUAL) {
                        String v = (String) filter.getValue();
                        if (v != null) {
                            query.setParameter(getParameterName(filter), v.trim().toUpperCase());
                        }
                    }
                    else if (operator == RelationalOperator.STARTS_WITH) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), String.valueOf(filter.getValue()).trim().toUpperCase() + "%");
                        }
                    }
                    else if (operator == RelationalOperator.LESS_THAN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), String.valueOf(filter.getValue()).trim().toUpperCase());
                        }
                    }
                    else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), String.valueOf(filter.getValue()).trim().toUpperCase());
                        }
                    }
                    else if (operator == RelationalOperator.GREATER_THAN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), String.valueOf(filter.getValue()).trim().toUpperCase());
                        }
                    }
                    else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), String.valueOf(filter.getValue()).trim().toUpperCase());
                        }
                    }
                    break;
                case OBJECT:
                    if (operator == null) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.NOT_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.LESS_THAN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.GREATER_THAN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    break;
                case BYTE:
                case SHORT:
                case DOUBLE:
                case DATE:
                    if (operator == null) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.NOT_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.LESS_THAN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.LESS_THAN_OR_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.GREATER_THAN) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    else if (operator == RelationalOperator.GREATER_THAN_OR_EQUAL) {
                        if (filter.getValue() != null) {
                            query.setParameter(getParameterName(filter), filter.getValue());
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        return query;
    }

    protected Path getPath(Filter filter, Root<T> rt) {
        String[] parts = filter.getFieldName().split(Pattern.quote("."));
        if (parts != null && parts.length > 1) {
            Join p = null;
            for (int i = 0; i < parts.length - 1; i++) {
                if (p == null) {
                    p = rt.join(parts[i]);
                }
                else {
                    p = p.join(parts[i]);
                }
            }
            if (p != null) {
                return p.get(parts[parts.length - 1]);
            }
        }
        return rt.get(filter.getFieldName());
    }

//    protected Expression<Boolean> getDayExpression(Filter filter, CriteriaBuilder cb, Root<T> rt, CriteriaQuery cq, String previousDayParamName, String nextDayParamName) {
//        String parameterName = getParameterName(filter);
//        if (null != filter.getOperator()) {
//            switch (filter.getOperator()) {
//                case EQUAL:
//                    if (filter.getValue() != null) {
//                        Predicate e1 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                        Predicate e2 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
//                        return cb.and(e1, e2);
//                    }
//                    break;
//                case NOT_EQUAL:
//                    if (filter.getValue() != null) {
//                        Predicate e1 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                        Predicate e2 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
//                        Predicate e3 = cb.isNull(getPath(filter, rt));
//                        return cb.or(e1, e2, e3);
//                    }
//                    break;
//                case LESS_THAN:
//                    if (filter.getValue() != null) {
////                        return cb.lessThanOrEqualTo(rt.get(fieldName), cb.parameter(Date.class, previousDayParamName));
//                        return cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                    }
//                    break;
//                case LESS_THAN_OR_EQUAL:
//                    if (filter.getValue() != null) {
//                        Predicate e1 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                        Predicate e2 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
////                        Predicate e3 = cb.lessThanOrEqualTo(rt.get(fieldName), cb.parameter(Date.class, previousDayParamName));
//                        Predicate e3 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                        return cb.or(e3, cb.and(e1, e2));
//                    }
//                    break;
//                case GREATER_THAN:
//                    if (filter.getValue() != null) {
//                        return cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
//                    }
//                    break;
//                case GREATER_THAN_OR_EQUAL:
//                    if (filter.getValue() != null) {
//                        Predicate e1 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                        Predicate e2 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
////                        Predicate e3 = cb.greaterThanOrEqualTo(rt.get(fieldName), cb.parameter(Date.class, nextDayParamName));
//                        Predicate e3 = cb.greaterThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
//                        return cb.or(e3, cb.and(e1, e2));
//                    }
//                    break;
//                case IS_EMPTY:
//                    return cb.isNull(getPath(filter, rt));
//                case IS_NOT_EMPTY:
//                    return cb.isNotNull(getPath(filter, rt));
//                default:
//                    break;
//            }
//        }
//        return cb.literal(true);
//    }

       protected Expression<Boolean> getDayExpression(Filter filter, CriteriaBuilder cb, Root<T> rt, CriteriaQuery cq, String previousDayParamName, String nextDayParamName) {
        String parameterName = getParameterName(filter);
        if (null != filter.getOperator()) {
            switch (filter.getOperator()) {
                case EQUAL:
                    if (filter.getValue() != null) {
                        Predicate e1 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                        Predicate e2 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
                        return cb.and(e1, e2);
                    }
                    break;
                case NOT_EQUAL:
                    if (filter.getValue() != null) {
                        Predicate e1 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                        Predicate e2 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
                        Predicate e3 = cb.isNull(getPath(filter, rt));
                        return cb.or(e1, e2, e3);
                    }
                    break;
                case LESS_THAN:
                    if (filter.getValue() != null) {
//                        return cb.lessThanOrEqualTo(rt.get(fieldName), cb.parameter(Date.class, previousDayParamName));
                        return cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                    }
                    break;
                case LESS_THAN_OR_EQUAL:
                    if (filter.getValue() != null) {
                        Predicate e1 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                        Predicate e2 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
//                        Predicate e3 = cb.lessThanOrEqualTo(rt.get(fieldName), cb.parameter(Date.class, previousDayParamName));
                        Predicate e3 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                        return cb.or(e3, cb.and(e1, e2));
                    }
                    break;
                case GREATER_THAN:
                    if (filter.getValue() != null) {
                        return cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
                    }
                    break;
                case GREATER_THAN_OR_EQUAL:
                    if (filter.getValue() != null) {
                        Predicate e1 = cb.greaterThanOrEqualTo(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                        Predicate e2 = cb.lessThan(getPath(filter, rt), cb.parameter(Date.class, nextDayParamName));
//                        Predicate e3 = cb.greaterThanOrEqualTo(rt.get(fieldName), cb.parameter(Date.class, nextDayParamName));
                        Predicate e3 = cb.greaterThan(getPath(filter, rt), cb.parameter(Date.class, parameterName));
                        return cb.or(e3, cb.and(e1, e2));
                    }
                    break;
                case IS_EMPTY:
                    return cb.isNull(getPath(filter, rt));
                case IS_NOT_EMPTY:
                    return cb.isNotNull(getPath(filter, rt));
                default:
                    break;
            }
        }
        return cb.literal(true);
    }

    protected TypedQuery setDayParameters(Filter filter, TypedQuery query, String previousDayParamName, String nextDayParamName) {
        String parameterName = getParameterName(filter);
        if (filter.getValue() != null) {
            Date date;
            if (filter.getValue() instanceof Date) {
                date = (Date) filter.getValue();
            }
            else {
                SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                try {
                    date = simpleFormat.parse((String) filter.getValue());
                } catch (ParseException ex) {
                    throw new RuntimeException(ex);
                }
            }
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);

            c.add(Calendar.DATE, 1);
            Date nextDay = c.getTime();
//            c.add(Calendar.DATE, -2);
//            Date previousDay = c.getTime();
            if (null != filter.getOperator()) {
                switch (filter.getOperator()) {
                    case EQUAL:
                        query.setParameter(parameterName, date);
                        query.setParameter(nextDayParamName, nextDay);
                        break;
                    case NOT_EQUAL:
                        //query.setParameter(previousDayParamName, previousDay);
                        query.setParameter(parameterName, date);
                        query.setParameter(nextDayParamName, nextDay);
                        break;
                    case LESS_THAN:
                        query.setParameter(parameterName, date);
//                        query.setParameter(previousDayParamName, previousDay);
                        break;
                    case LESS_THAN_OR_EQUAL:
                        query.setParameter(parameterName, date);
                        //query.setParameter(previousDayParamName, previousDay);
                        query.setParameter(nextDayParamName, nextDay);
                        break;
                    case GREATER_THAN:
                        query.setParameter(nextDayParamName, nextDay);
                        break;
                    case GREATER_THAN_OR_EQUAL:
                        query.setParameter(parameterName, date);
                        //query.setParameter(previousDayParamName, previousDay);
                        query.setParameter(nextDayParamName, nextDay);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }

    protected boolean exists(String value, String valueAttributeName, String idAttributeName, Object id) {
        EntityManager em = getEntityManager();
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery();
        Root<T> rt = cq.from(entityClass);
        cq.select(cb.count(rt));
        Predicate p1 = cb.equal(cb.upper(rt.<String>get(valueAttributeName)), value.toUpperCase());
        Predicate p2 = null;
        if (id != null) {
            p2 = cb.notEqual(rt.get(idAttributeName), id);
        }
        Predicate p = p2 == null ? p1 : cb.and(p1, p2);
        cq.where(p);
        TypedQuery tq = em.createQuery(cq);
        return (long) tq.getSingleResult() > 0;
    }
}
