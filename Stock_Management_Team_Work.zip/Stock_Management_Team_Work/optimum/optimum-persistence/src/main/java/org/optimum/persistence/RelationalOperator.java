/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.persistence;

/**
 *
 * @author Biya-Bi
 */
public enum RelationalOperator {
    EQUAL,
    NOT_EQUAL,
    CONTAINS,
    DOES_NOT_CONTAIN,
    LESS_THAN,
    LESS_THAN_OR_EQUAL,
    GREATER_THAN,
    GREATER_THAN_OR_EQUAL,
    STARTS_WITH,
    ENDS_WITH,
    IS_EMPTY,
    IS_NOT_EMPTY,
    IS_BETWEEN,
    IS_NOT_BETWEEN
}