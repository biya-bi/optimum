/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.ProductIssue;
import org.optimum.stock.management.core.persistence.ProductIssueFacade;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ProductIssueLazyDataModel extends AbstractLazyDataModel<ProductIssue> {

    @EJB
    private ProductIssueFacade productIssueFacade;

    private static final String REFERENCE_NUMBER_FILTER = "referenceNumber";
    private static final String LOCATION_NAME_FILTER = "location.name";

    private final List<Filter> filters;

    private final Filter referenceNumberFilter;
    private final Filter locationNameFilter;

    public ProductIssueLazyDataModel() {

        referenceNumberFilter = new Filter(REFERENCE_NUMBER_FILTER, RelationalOperator.CONTAINS, "");
        locationNameFilter = new Filter(LOCATION_NAME_FILTER, RelationalOperator.CONTAINS, "");

        filters = new ArrayList<>();
        filters.add(referenceNumberFilter);
        filters.add(locationNameFilter);
    }

    @Override
    protected CrudFacade<ProductIssue> getFacade() {
        return productIssueFacade;
    }

    public Filter getReferenceNumberFilter() {
        return referenceNumberFilter;
    }

    public Filter getLocationNameFilter() {
        return locationNameFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<ProductIssue> list) {
        if (sortField == null) {
            sortField = REFERENCE_NUMBER_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case REFERENCE_NUMBER_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ProductIssue>() {
                        @Override
                        public int compare(ProductIssue one, ProductIssue other) {
                            int result = comparator.compare(one.getReferenceNumber(), other.getReferenceNumber());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case LOCATION_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ProductIssue>() {
                        @Override
                        public int compare(ProductIssue one, ProductIssue other) {
                            int result = comparator.compare(one.getLocation().getName(), other.getLocation().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
