/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import org.optimum.persistence.CrudFacade;

/**
 *
 * @author Biya-Bi
 * @param <T>
 */
public abstract class Controller<T> implements Serializable {

    private T current;
    private Class modelClass;

    public Controller() {
    }

    protected abstract CrudFacade<T> getFacade();

    public Controller(Class modelClass) {
        this.modelClass = modelClass;
    }

    public T getCurrent() {
        return current;
    }

    public void setCurrent(T current) {
        this.current = current;
    }

    public void create() throws Exception {
        getFacade().create(current);
    }

    public void edit() throws Exception {
        getFacade().edit(current);
    }

    public void delete() throws Exception {
        getFacade().remove(current);
    }

    public T prepareCreate() {

        try {
            return this.current = (T) modelClass.getConstructor().newInstance(new Object[]{});
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            throw new RuntimeException(ex);
        }
    }
}
