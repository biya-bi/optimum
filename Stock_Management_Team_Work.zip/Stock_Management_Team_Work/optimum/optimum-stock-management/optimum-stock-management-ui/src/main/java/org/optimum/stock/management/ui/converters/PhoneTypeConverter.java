/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.converters;

import java.util.ResourceBundle;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import org.optimum.stock.management.core.entities.PhoneType;
import static org.optimum.stock.management.core.entities.PhoneType.MOBILE;
import org.optimum.stock.management.ui.utilities.ResourceBundles;

/**
 *
 * @author Biya-Bi
 */
@FacesConverter("org.optimum.stock.management.ui.converters.PhoneTypeConverter")
public class PhoneTypeConverter implements Converter {

    private final ResourceBundle resourceBundle;

    public PhoneTypeConverter() {
        resourceBundle = ResourceBundle.getBundle(ResourceBundles.LABELS);
    }

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        PhoneType phoneType = (PhoneType) value;
        switch (phoneType) {
            case BUSINESS:
                return resourceBundle.getString("Business");
            case HOME:
                return resourceBundle.getString("Home");
            case MOBILE:
                return resourceBundle.getString("Mobile");
            default:
                return resourceBundle.getString("Other");
        }
    }
}
