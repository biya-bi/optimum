/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.List;
import java.util.Map;
import org.optimum.common.utilities.BeanUtilities;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.SearchCriteria;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 * @param <TModel>
 */
public abstract class AbstractLazyDataModel<TModel> extends LazyDataModel<TModel> {

    private final SearchCriteria criteria;

    public AbstractLazyDataModel() {
        criteria = new SearchCriteria();
    }

    protected abstract CrudFacade<TModel> getFacade();

    @Override
    public TModel getRowData(String rowKey) {
        return getFacade().find(Long.valueOf(rowKey));
    }

    @Override
    public Object getRowKey(TModel object) {
        return BeanUtilities.getProperty(object, "id");
    }

    protected List<Filter> getFilters() {
        return null;
    }

    @Override
    public List<TModel> load(
            int first, int pageSize,
            String sortField, SortOrder sortOrder,
            Map<String, Object> filters) {

        int pageIndex = pageSize == 0 ? 0 : first / pageSize;

        criteria.setPageIndex(pageIndex);
        criteria.setPageSize(pageSize);
        criteria.setFilters(getFilters());

        CrudFacade<TModel> facade = getFacade();
        List<TModel> result = facade.find(criteria);
        setRowCount((int) facade.count(criteria));

        sort(sortField, sortOrder, result);

        return result;
    }

    protected void sort(String sortField, SortOrder sortOrder, List<TModel> list) {
    }
}
