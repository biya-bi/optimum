/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.persistence.ProductFacade;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ProductLazyDataModel extends AbstractLazyDataModel<Product> {

    @EJB
    private ProductFacade productFacade;

    private static final String NAME_FILTER = "name";
    private static final String NUMBER_FILTER = "number";
    private static final String SAFETY_STOCK_LEVEL_FILTER = "safetyStockLevel";
    private static final String STOCK_COVER_FILTER = "stockCover";
    private static final String REORDER_POINT_FILTER = "reorderPoint";

    private final List<Filter> filters;

    private final Filter nameFilter;
    private final Filter numberFilter;
    private final Filter safetyStockLevelFilter;
    private final Filter stockCoverFilter;
    private final Filter reorderPointFilter;

    public ProductLazyDataModel() {
        nameFilter = new Filter(NAME_FILTER, RelationalOperator.CONTAINS, "");
        numberFilter = new Filter(NUMBER_FILTER, RelationalOperator.CONTAINS, "");
        safetyStockLevelFilter = new Filter(SAFETY_STOCK_LEVEL_FILTER);
        stockCoverFilter = new Filter(STOCK_COVER_FILTER);
        reorderPointFilter = new Filter(REORDER_POINT_FILTER);

        filters = new ArrayList<>();
        filters.add(nameFilter);
        filters.add(numberFilter);
        filters.add(safetyStockLevelFilter);
        filters.add(stockCoverFilter);
        filters.add(reorderPointFilter);
    }

    @Override
    protected CrudFacade<Product> getFacade() {
        return productFacade;
    }

    public Filter getNameFilter() {
        return nameFilter;
    }

    public Filter getNumberFilter() {
        return numberFilter;
    }

    public Filter getSafetyStockLevelFilter() {
        return safetyStockLevelFilter;
    }

    public Filter getStockCoverFilter() {
        return stockCoverFilter;
    }

    public Filter getReorderPointFilter() {
        return reorderPointFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<Product> list) {
        if (sortField == null) {
            sortField = NAME_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Product>() {
                        @Override
                        public int compare(Product one, Product other) {
                            int result = comparator.compare(one.getName(), other.getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case NUMBER_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Product>() {
                        @Override
                        public int compare(Product one, Product other) {
                            int result = comparator.compare(one.getNumber(), other.getNumber());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SAFETY_STOCK_LEVEL_FILTER: {
                    final Comparator<Short> comparator = DefaultComparator.<Short>getInstance();
                    Collections.sort(list, new Comparator<Product>() {
                        @Override
                        public int compare(Product one, Product other) {
                            int result = comparator.compare(one.getSafetyStockLevel(), other.getSafetyStockLevel());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case STOCK_COVER_FILTER: {
                    final Comparator<Short> comparator = DefaultComparator.<Short>getInstance();
                    Collections.sort(list, new Comparator<Product>() {
                        @Override
                        public int compare(Product one, Product other) {
                            int result = comparator.compare(one.getStockCover(), other.getStockCover());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case REORDER_POINT_FILTER: {
                    final Comparator<Short> comparator = DefaultComparator.<Short>getInstance();
                    Collections.sort(list, new Comparator<Product>() {
                        @Override
                        public int compare(Product one, Product other) {
                            int result = comparator.compare(one.getReorderPoint(), other.getReorderPoint());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
