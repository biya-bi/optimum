/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.PurchaseOrderStatus;
import org.optimum.stock.management.core.entities.ShippingOrder;
import org.optimum.stock.management.core.entities.ShippingOrderDetail;
import org.optimum.stock.management.core.entities.ShippingOrderStatus;
import org.optimum.stock.management.core.persistence.ShippingOrderFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ShippingOrderController extends Controller<ShippingOrder> {

    @EJB
    private ShippingOrderFacade shippingOrderFacade;

    private ShippingOrderDetail detail;

    public ShippingOrderController() {
        super(ShippingOrder.class);
    }

    @Override
    protected CrudFacade<ShippingOrder> getFacade() {
        return shippingOrderFacade;
    }

    @Override
    public ShippingOrder prepareCreate() {
        ShippingOrder shippingOrder = super.prepareCreate();
        shippingOrder.setStatus(ShippingOrderStatus.PENDING);
        return shippingOrder;
    }

    public ShippingOrderDetail getDetail() {
        return detail;
    }

    public void setDetail(ShippingOrderDetail detail) {
        this.detail = detail;
    }

    public void addDetail() {
        ShippingOrder shippingOrder = this.getCurrent();
        if (shippingOrder != null) {
            List<ShippingOrderDetail> details = shippingOrder.getDetails();
            if (details == null) {
                details = new ArrayList<>();
                shippingOrder.setDetails(details);
            }
            details.add(detail);
        }
    }

    public void removeDetail(ShippingOrderDetail detail) {
        if (detail != null) {
            ShippingOrder shippingOrder = this.getCurrent();
            if (shippingOrder != null) {
                List<ShippingOrderDetail> details = shippingOrder.getDetails();
                if (details != null) {
                    details.remove(detail);
                }
            }
        }
    }

    public void prepareDetail() {
        detail = new ShippingOrderDetail();
        detail.setReceivedQuantity((short) 0);
        detail.setRejectedQuantity((short) 0);
    }

    public boolean canBeApproved() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == ShippingOrderStatus.PENDING;
    }

    public boolean canBeRejected() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == ShippingOrderStatus.PENDING;
    }

    public boolean canBeShipped() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == ShippingOrderStatus.APPROVED;
    }

    public boolean canBeRestituted() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == ShippingOrderStatus.IN_TRANSIT;
    }

    public boolean canBeDelivered() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == ShippingOrderStatus.IN_TRANSIT;
    }

    public void approve() throws Exception {
        shippingOrderFacade.approve(this.getCurrent().getId());
    }

    public void reject() throws Exception {
        shippingOrderFacade.reject(this.getCurrent().getId());
    }

    public void ship() throws Exception {
        shippingOrderFacade.transit(this.getCurrent().getId());
    }

    public void restitute() throws Exception {
        shippingOrderFacade.restitute(this.getCurrent().getId());
    }

    public void deliver() throws Exception {
        //shippingOrderFacade.complete(this.getCurrent().getId());
    }
}
