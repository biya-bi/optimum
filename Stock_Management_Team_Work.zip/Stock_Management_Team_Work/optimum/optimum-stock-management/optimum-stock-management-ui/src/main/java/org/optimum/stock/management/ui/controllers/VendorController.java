/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.AddressType;
import org.optimum.stock.management.core.entities.BusinessEntityAddress;
import org.optimum.stock.management.core.entities.BusinessEntityEmail;
import org.optimum.stock.management.core.entities.BusinessEntityFax;
import org.optimum.stock.management.core.entities.BusinessEntityPhone;
import org.optimum.stock.management.core.entities.EmailType;
import org.optimum.stock.management.core.entities.FaxType;
import org.optimum.stock.management.core.entities.PhoneType;
import org.optimum.stock.management.core.entities.Vendor;
import org.optimum.stock.management.core.persistence.VendorFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class VendorController extends Controller<Vendor> {

    @EJB
    private VendorFacade vendorFacade;

    public VendorController() {
        super(Vendor.class);
    }

    @Override
    protected CrudFacade<Vendor> getFacade() {
        return vendorFacade;
    }

    @Override
    public Vendor prepareCreate() {
        Vendor vendor = super.prepareCreate();

        List<BusinessEntityAddress> contactAddresses = new ArrayList<>();
        contactAddresses.add(new BusinessEntityAddress(AddressType.BUSINESS));
        contactAddresses.add(new BusinessEntityAddress(AddressType.HOME));
        contactAddresses.add(new BusinessEntityAddress(AddressType.BILLING));
        contactAddresses.add(new BusinessEntityAddress(AddressType.SHIPPING));
        contactAddresses.add(new BusinessEntityAddress(AddressType.OTHER));
        vendor.setAddresses(contactAddresses);

        List<BusinessEntityPhone> contactPhones = new ArrayList<>();
        contactPhones.add(new BusinessEntityPhone(PhoneType.BUSINESS));
        contactPhones.add(new BusinessEntityPhone(PhoneType.HOME));
        contactPhones.add(new BusinessEntityPhone(PhoneType.MOBILE));
        contactPhones.add(new BusinessEntityPhone(PhoneType.OTHER));
        vendor.setPhones(contactPhones);

        List<BusinessEntityFax> contactFaxes = new ArrayList<>();
        contactFaxes.add(new BusinessEntityFax(FaxType.BUSINESS));
        contactFaxes.add(new BusinessEntityFax(FaxType.HOME));
        contactFaxes.add(new BusinessEntityFax(FaxType.OTHER));
        vendor.setFaxes(contactFaxes);

        List<BusinessEntityEmail> contactEmails = new ArrayList<>();
        contactEmails.add(new BusinessEntityEmail(EmailType.EMAIL1));
        contactEmails.add(new BusinessEntityEmail(EmailType.EMAIL2));
        contactEmails.add(new BusinessEntityEmail(EmailType.EMAIL3));
        vendor.setEmails(contactEmails);
        
        return vendor;
    }

}
