/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.ProductIssue;
import org.optimum.stock.management.core.entities.ProductIssueDetail;
import org.optimum.stock.management.core.persistence.ProductIssueFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ProductIssueController extends Controller<ProductIssue> {

    @EJB
    private ProductIssueFacade productIssueFacade;

    private ProductIssueDetail detail;

    public ProductIssueController() {
        super(ProductIssue.class);
    }

    @Override
    protected CrudFacade<ProductIssue> getFacade() {
        return productIssueFacade;
    }

    public ProductIssueDetail getDetail() {
        return detail;
    }

    public void setDetail(ProductIssueDetail detail) {
        this.detail = detail;
    }

    public void addDetail() {
        ProductIssue productIssue = this.getCurrent();
        if (productIssue != null) {
            List<ProductIssueDetail> details = productIssue.getDetails();
            if (details == null) {
                details = new ArrayList<>();
                productIssue.setDetails(details);
            }
            details.add(detail);
        }
    }

    public void removeDetail(ProductIssueDetail detail) {
        if (detail != null) {
            ProductIssue productIssue = this.getCurrent();
            if (productIssue != null) {
                List<ProductIssueDetail> details = productIssue.getDetails();
                if (details != null) {
                    details.remove(detail);
                }
            }
        }
    }

    public void prepareDetail() {
        detail = new ProductIssueDetail();
    }
}
