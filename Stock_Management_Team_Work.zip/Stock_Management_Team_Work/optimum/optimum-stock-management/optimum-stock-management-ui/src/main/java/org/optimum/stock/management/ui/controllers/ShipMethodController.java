/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.ShipMethod;
import org.optimum.stock.management.core.persistence.ShipMethodFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ShipMethodController extends Controller<ShipMethod> {

    @EJB
    private ShipMethodFacade shipMethodFacade;

    public ShipMethodController() {
        super(ShipMethod.class);
    }

    @Override
    protected CrudFacade<ShipMethod> getFacade() {
        return shipMethodFacade;
    }
    
    
}
