/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.ProductReceipt;
import org.optimum.stock.management.core.entities.ProductReceiptDetail;
import org.optimum.stock.management.core.persistence.ProductReceiptFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ProductReceiptController extends Controller<ProductReceipt> {

    @EJB
    private ProductReceiptFacade productReceiptFacade;

    private ProductReceiptDetail detail;

    public ProductReceiptController() {
        super(ProductReceipt.class);
    }

    @Override
    protected CrudFacade<ProductReceipt> getFacade() {
        return productReceiptFacade;
    }

    public ProductReceiptDetail getDetail() {
        return detail;
    }

    public void setDetail(ProductReceiptDetail detail) {
        this.detail = detail;
    }

    public void addDetail() {
        ProductReceipt productReceipt = this.getCurrent();
        if (productReceipt != null) {
            List<ProductReceiptDetail> details = productReceipt.getDetails();
            if (details == null) {
                details = new ArrayList<>();
                productReceipt.setDetails(details);
            }
            details.add(detail);
        }
    }

    public void removeDetail(ProductReceiptDetail detail) {
        if (detail != null) {
            ProductReceipt productReceipt = this.getCurrent();
            if (productReceipt != null) {
                List<ProductReceiptDetail> details = productReceipt.getDetails();
                if (details != null) {
                    details.remove(detail);
                }
            }
        }
    }

    public void prepareDetail() {
        detail = new ProductReceiptDetail();
    }
}
