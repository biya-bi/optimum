/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.List;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.BusinessEntity;
import org.optimum.stock.management.core.entities.BusinessEntityAddress;
import org.optimum.stock.management.core.entities.BusinessEntityEmail;
import org.optimum.stock.management.core.entities.BusinessEntityFax;
import org.optimum.stock.management.core.entities.BusinessEntityPhone;

/**
 *
 * @author Biya-Bi
 * @param <T>
 */
public abstract class BusinessEntityFacade<T extends BusinessEntity> extends CrudFacade<T> {

    public BusinessEntityFacade(Class<T> entityClass) {
        super(entityClass);
    }

    @Override
    public void create(T entity) throws Exception {
        List<BusinessEntityAddress> addresses = entity.getAddresses();
        if (addresses != null) {
            for (BusinessEntityAddress address : addresses) {
                address.setBusinessEntity(entity);
            }
        }
        List<BusinessEntityPhone> phones = entity.getPhones();
        if (phones != null) {
            for (BusinessEntityPhone phone : phones) {
                phone.setBusinessEntity(entity);
            }
        }
        List<BusinessEntityFax> faxes = entity.getFaxes();
        if (faxes != null) {
            for (BusinessEntityFax fax : faxes) {
                fax.setBusinessEntity(entity);
            }
        }
        List<BusinessEntityEmail> emails = entity.getEmails();
        if (emails != null) {
            for (BusinessEntityEmail email : emails) {
                email.setBusinessEntity(entity);
            }
        }

        super.create(entity);
    }

}
