package org.optimum.stock.management.core.entities;

public enum MaritalStatus {
    SINGLE,
    MARRIED
}
