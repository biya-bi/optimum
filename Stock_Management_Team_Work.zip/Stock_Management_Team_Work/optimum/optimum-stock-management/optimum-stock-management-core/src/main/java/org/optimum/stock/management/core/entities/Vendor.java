/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Biya-Bi
 */
@Entity
@Table(uniqueConstraints = {
    @UniqueConstraint(columnNames = {"ACCOUNT_NUMBER"})})
public class Vendor extends BusinessEntity {

    private String accountNumber;
    private String name;
    private boolean active;
    private String purchasingUrl;

    public Vendor() {
    }

    public Vendor(Long id) {
        super(id);
    }

    public Vendor(String accountNumber, String name, boolean active, String purchasingUrl) {
        this.accountNumber = accountNumber;
        this.name = name;
        this.active = active;
        this.purchasingUrl = purchasingUrl;
    }

    public Vendor(String accountNumber, String name, boolean active, String purchasingUrl, Long id) {
        super(id);
        this.accountNumber = accountNumber;
        this.name = name;
        this.active = active;
        this.purchasingUrl = purchasingUrl;
    }

    public Vendor(String accountNumber, String name, boolean active, String purchasingUrl, Date creationDate, Date lastUpdateDate) {
        super(creationDate, lastUpdateDate);
        this.accountNumber = accountNumber;
        this.name = name;
        this.active = active;
        this.purchasingUrl = purchasingUrl;
    }

    public Vendor(String accountNumber, String name, boolean active, String purchasingUrl, Date creationDate, Date lastUpdateDate, long version, Long id) {
        super(creationDate, lastUpdateDate, version, id);
        this.accountNumber = accountNumber;
        this.name = name;
        this.active = active;
        this.purchasingUrl = purchasingUrl;
    }

    @Basic(optional = false)
    @NotNull
    @Size(min = 1)
    @Column(name = "ACCOUNT_NUMBER", nullable = false)
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @Basic(optional = false)
    @NotNull
    @Size(min = 1)
    @Column(name = "NAME", nullable = false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    @Column(name = "IS_ACTIVE", nullable = false)
    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Column(name = "PURCHASING_URL")
    public String getPurchasingUrl() {
        return purchasingUrl;
    }

    public void setPurchasingUrl(String purchasingUrl) {
        this.purchasingUrl = purchasingUrl;
    }

}
