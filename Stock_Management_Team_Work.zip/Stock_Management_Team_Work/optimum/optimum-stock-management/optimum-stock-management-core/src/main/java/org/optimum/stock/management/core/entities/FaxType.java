package org.optimum.stock.management.core.entities;

public enum FaxType {
    BUSINESS,
    HOME,
    OTHER
}
