/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.DataType;
import org.optimum.persistence.Filter;
import org.optimum.stock.management.core.entities.ProductReceipt;
import org.optimum.persistence.Pageable;
import org.optimum.persistence.SearchCriteria;
import org.optimum.persistence.UpdateOperation;
import org.optimum.stock.management.core.entities.Document_;
import org.optimum.stock.management.core.entities.Identifiable_;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ProductInventoryId;
import org.optimum.stock.management.core.entities.ProductReceiptDetail;
import org.optimum.stock.management.core.exceptions.DuplicateProductReceiptReferenceNumberException;
import org.optimum.stock.management.core.exceptions.InsufficientInventoryException;
import org.optimum.stock.management.core.exceptions.ProductReceiptDetailsNullOrEmptyException;

/**
 *
 * @author Biya-Bi
 */
@Stateless
@Pageable(attributeName = "id")
public class ProductReceiptFacade extends CrudFacade<ProductReceipt> {

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    @EJB
    private LocationFacade locationFacade;

    @EJB
    private InventoryManager inventoryManager;

    @EJB
    private ProductFacade productFacade;

    private static final String REFERENCE_NUMBER_FIELD = "referenceNumber";
    private static final String LOCATION_NAME_FIELD = "location.name";

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductReceiptFacade() {
        super(ProductReceipt.class);
    }

    @Override
    protected void validate(ProductReceipt productReceipt, UpdateOperation operation) throws Exception {
        switch (operation) {
            case CREATE: {
                if (exists(productReceipt.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), null)) {
                    throw new DuplicateProductReceiptReferenceNumberException(productReceipt.getReferenceNumber());
                }
                break;
            }
            case UPDATE: {
                if (exists(productReceipt.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), productReceipt.getId())) {
                    throw new DuplicateProductReceiptReferenceNumberException(productReceipt.getReferenceNumber());
                }
                break;
            }
        }
    }

    @Override
    public void create(ProductReceipt productReceipt) throws Exception {
        Location location = locationFacade.getPersistent(productReceipt.getLocation());
        productReceipt.setLocation(location);
        Long locationId = location.getId();

        if (productReceipt.getDetails() == null || productReceipt.getDetails().isEmpty()) {
            throw new ProductReceiptDetailsNullOrEmptyException();
        }

        List<Long> productIds = new ArrayList<>();

        List<ProductReceiptDetail> details = productReceipt.getDetails();

        int detailId = 0;
        int noOfDetailsWithPositiveQuantities = 0;

        for (ProductReceiptDetail detail : details) {
            if (detail.getQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;

                detail.setProductReceipt(productReceipt);
                detail.setDetailId(++detailId);
                productIds.add(detail.getProduct().getId());
            }
        }

        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new ProductReceiptDetailsNullOrEmptyException();
        }

        List<ProductInventory> productInventories = inventoryManager.getProductInventories(location.getId(), productIds);

        List<Product> persistentProducts = getPersistentProducts(productIds);

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!persistentProducts.contains(detail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", productId));
            }
            detail.setProduct(persistentProducts.get(persistentProducts.indexOf(detail.getProduct())));

            Short receivedQuantity = detail.getQuantity();

            boolean found = false;
            for (ProductInventory productInventory : productInventories) {
                if (productInventory.getId().getProductId().equals(productId)) {
                    productInventory.setQuantity((short) (productInventory.getQuantity() + receivedQuantity));
                    em.merge(productInventory);
                    found = true;
                    break;
                }
            }
            if (!found) {
                ProductInventory productInventory = new ProductInventory();
                productInventory.setId(new ProductInventoryId(locationId, productId));
                productInventory.setQuantity(receivedQuantity);
                productInventories.add(productInventory);
                em.persist(productInventory);
            }
        }

        super.create(productReceipt);
    }

    private int getDetailId(List<ProductReceiptDetail> oldDetails, List<ProductReceiptDetail> newDetails) {
        List<Integer> detailIds = new ArrayList<>();
        for (ProductReceiptDetail oldDetail : oldDetails) {
            Integer detailId = oldDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        for (ProductReceiptDetail newDetail : newDetails) {
            Integer detailId = newDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        int detailId = 0;
        while (detailId++ < newDetails.size()) {
            if (!detailIds.contains(detailId)) {
                break;
            }
        }
        return detailId;
    }

    private Map<Long, Short> getProductIdsByQuantities(List<ProductReceiptDetail> details) {
        Map<Long, Short> result = new HashMap<>();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!result.containsKey(productId)) {
                result.put(productId, detail.getQuantity());
            }
            else {
                result.replace(productId, (short) (result.get(productId) + detail.getQuantity()));
            }
        }
        return result;
    }

    private List<Product> getPersistentProducts(List<Long> productIds) {
        SearchCriteria c = new SearchCriteria();
        c.setIds(productIds);
        return productFacade.find(c);
    }

    @Override
    public void edit(ProductReceipt productReceipt) throws Exception {

        Location newLocation = locationFacade.getPersistent(productReceipt.getLocation());

        productReceipt.setLocation(newLocation);
        Long newLocationId = newLocation.getId();

        if (productReceipt.getDetails() == null || productReceipt.getDetails().isEmpty()) {
            throw new ProductReceiptDetailsNullOrEmptyException();
        }

        List<Long> productIds = new ArrayList<>();

        List<ProductReceiptDetail> newDetails = productReceipt.getDetails();

        int noOfDetailsWithPositiveQuantities = 0;
        for (ProductReceiptDetail detail : newDetails) {
            if (detail.getQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;

                detail.setProductReceipt(productReceipt);
                productIds.add(detail.getProduct().getId());
            }
        }

        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new ProductReceiptDetailsNullOrEmptyException();
        }

        List<ProductInventory> newLocationProductInventories = inventoryManager.getProductInventories(newLocationId, productIds);

        ProductReceipt persistentProductReceipt = getPersistent(productReceipt);
        List<ProductReceiptDetail> oldDetails = persistentProductReceipt.getDetails();
        Location oldLocation = persistentProductReceipt.getLocation();

        Long oldLocationId = oldLocation.getId();

        List<ProductInventory> oldLocationProductInventories = !oldLocation.equals(newLocation) ? inventoryManager.getProductInventories(oldLocationId, productIds) : null;

        Map<Long, Short> productCountNotInInventory = new HashMap<>();

        for (ProductReceiptDetail oldDetail : oldDetails) {
            Long oldDetailProductId = oldDetail.getProduct().getId();
            if (!productCountNotInInventory.containsKey(oldDetailProductId)) {
                productCountNotInInventory.put(oldDetailProductId, oldDetail.getQuantity());
            }
            else {
                productCountNotInInventory.replace(oldDetailProductId, (short) (productCountNotInInventory.get(oldDetailProductId) + oldDetail.getQuantity()));
            }
        }
        //If oldLocationProductInventories == null, then the locations are the same. 
        if (oldLocationProductInventories == null) {
            for (ProductInventory productInventory : newLocationProductInventories) {
                Long inventoryProductId = productInventory.getId().getProductId();
                if (productCountNotInInventory.containsKey(inventoryProductId)) {
                    productCountNotInInventory.remove(inventoryProductId);
                }
            }
        }
        else {
            for (ProductInventory productInventory : oldLocationProductInventories) {
                Long inventoryProductId = productInventory.getId().getProductId();
                if (productCountNotInInventory.containsKey(inventoryProductId)) {
                    productCountNotInInventory.remove(inventoryProductId);
                }
            }
        }
        Map<Long, Short> oldProductIdsByQuantities = getProductIdsByQuantities(oldDetails);
        Map<Long, Short> newProductIdsByQuantities = getProductIdsByQuantities(newDetails);

        List<Long> processedProductId = new ArrayList<>();

        List<Product> persistentProducts = getPersistentProducts(productIds);

        for (ProductReceiptDetail newDetail : newDetails) {
            Long productId = newDetail.getProduct().getId();
            if (!persistentProducts.contains(newDetail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", productId));
            }
            newDetail.setProduct(persistentProducts.get(persistentProducts.indexOf(newDetail.getProduct())));

            if (!processedProductId.contains(productId)) {
                processedProductId.add(productId);

                short newQuantity = newProductIdsByQuantities.containsKey(productId) ? newProductIdsByQuantities.get(productId) : 0;

                short oldQuantity = oldProductIdsByQuantities.containsKey(productId) ? oldProductIdsByQuantities.get(productId) : 0;

                boolean found = false;
                // oldLocationProductInventories == null if the locations are the same.
                if (oldLocationProductInventories == null) {
                    for (ProductInventory productInventory : newLocationProductInventories) {
                        if (productInventory.getId().getProductId().equals(productId)) {
                            short availableQuantity = productInventory.getQuantity();
                            short remainingQuantity = (short) (availableQuantity - oldQuantity + newQuantity);
                            if (remainingQuantity < 0) {
                                throw new InsufficientInventoryException(newLocationId, productId, availableQuantity, (short) (oldQuantity - newQuantity));
                            }
                            productInventory.setQuantity(remainingQuantity);
                            if (remainingQuantity > 0) {
                                em.merge(productInventory);
                            }
                            else {
                                em.remove(productInventory);
                            }
                            found = true;
                            break;
                        }
                    }
                }
                else {
                    //First, we have to remove the products that were added to the inventory of the old location.
                    for (ProductInventory productInventory : oldLocationProductInventories) {
                        if (productInventory.getId().getProductId().equals(productId)) {
                            short availableQuantity = productInventory.getQuantity();
                            short remainingQuantity = (short) (availableQuantity - oldQuantity);
                            if (remainingQuantity < 0) {
                                throw new InsufficientInventoryException(oldLocationId, productId, availableQuantity, oldQuantity);
                            }
                            productInventory.setQuantity(remainingQuantity);
                            if (remainingQuantity > 0) {
                                em.merge(productInventory);
                            }
                            else {
                                em.remove(productInventory);
                            }
                        }
                    }
                    //Now, we have to add the products to the inventory of the new location.
                    for (ProductInventory productInventory : newLocationProductInventories) {
                        if (productInventory.getId().getProductId().equals(productId)) {
                            short availableQuantity = productInventory.getQuantity();
                            short remainingQuantity = (short) (availableQuantity + newQuantity);
                            productInventory.setQuantity(remainingQuantity);
                            if (remainingQuantity > 0) {
                                em.merge(productInventory);
                            }
                            else {
                                em.remove(productInventory);
                            }
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) {
                    ProductInventory productInventory = new ProductInventory();
                    productInventory.setId(new ProductInventoryId(newLocationId, productId));
                    productInventory.setQuantity(newDetail.getQuantity());
                    newLocationProductInventories.add(productInventory);
                    em.persist(productInventory);
                }
            }
            if (!oldDetails.contains(newDetail)) {
                newDetail.setDetailId(getDetailId(oldDetails, newDetails));
                em.persist(newDetail);
            }
            else {
                em.merge(newDetail);
            }
        }
        for (ProductReceiptDetail oldDetail : oldDetails) {
            if (!newDetails.contains(oldDetail)) {
                em.remove(oldDetail);
            }
        }

        // If a product in an old detail is not found in the old location inventory, we have to throw an exception.
        // If the locations are different, we must make sure that all products in the old details appear in the old location.
        if (!oldDetails.isEmpty() && !productCountNotInInventory.isEmpty()) {
            Long productId = productCountNotInInventory.keySet().iterator().next();
            throw new InsufficientInventoryException(oldLocationId, productId, (short) 0, productCountNotInInventory.get(productId));
        }
        super.edit(productReceipt);
    }

    @Override
    public void remove(ProductReceipt productReceipt) throws Exception {
        List<Long> productIds = new ArrayList<>();

        ProductReceipt persistentProductReceipt = getPersistent(productReceipt);
        Long locationId = persistentProductReceipt.getLocation().getId();
        List<ProductReceiptDetail> details = persistentProductReceipt.getDetails();

        int totalDetails = details.size();
        for (int i = 0; i < totalDetails; i++) {
            productIds.add(details.get(i).getProduct().getId());
        }

        List<ProductInventory> productInventories = inventoryManager.getProductInventories(locationId, productIds);

        Map<Long, Short> productCountNotInInventory = new HashMap<>();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!productCountNotInInventory.containsKey(productId)) {
                productCountNotInInventory.put(productId, detail.getQuantity());
            }
            else {
                productCountNotInInventory.replace(productId, (short) (productCountNotInInventory.get(productId) + detail.getQuantity()));
            }
        }

        for (ProductInventory productInventory : productInventories) {
            Long inventoryProductId = productInventory.getId().getProductId();
            if (productCountNotInInventory.containsKey(inventoryProductId)) {
                productCountNotInInventory.remove(inventoryProductId);
            }
        }
        Map<Long, Short> productIdsByQuantities = getProductIdsByQuantities(details);

        List<Long> processedProductId = new ArrayList<>();

        for (ProductReceiptDetail oldDetail : details) {
            Long productId = oldDetail.getProduct().getId();

            if (!processedProductId.contains(productId)) {
                processedProductId.add(productId);

                short oldQuantity = productIdsByQuantities.containsKey(productId) ? productIdsByQuantities.get(productId) : 0;

                //First, we have to remove the products that were added to the inventory of the location.
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        short availableQuantity = productInventory.getQuantity();
                        short receivedQuantity = (short) (availableQuantity - oldQuantity);
                        if (receivedQuantity < 0) {
                            throw new InsufficientInventoryException(locationId, productId, availableQuantity, oldQuantity);
                        }
                        productInventory.setQuantity(receivedQuantity);
                        if (receivedQuantity > 0) {
                            em.merge(productInventory);
                        }
                        else {
                            em.remove(productInventory);
                        }
                    }
                }
            }
            em.remove(oldDetail);
        }

        // If a product in an old detail is not found in the old location inventory, we have to throw an exception.
        // If the locations are different, we must make sure that all products in the old details appear in the location.
        if (!details.isEmpty() && !productCountNotInInventory.isEmpty()) {
            Long productId = productCountNotInInventory.keySet().iterator().next();
            throw new InsufficientInventoryException(locationId, productId, (short) 0, productCountNotInInventory.get(productId));
        }

        super.remove(productReceipt);
    }

    @Override
    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<ProductReceipt> rt, CriteriaQuery cq
    ) {
        List<Expression<Boolean>> expressions = new ArrayList<>();
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case LOCATION_NAME_FIELD:
                        expressions.add(getExpression(filter, DataType.STRING, cb, rt, cq));
                        break;
                    default:
                        break;
                }
            }
        }
        Expression[] expressionsArray = new Expression[expressions.size()];
        return super.and(cb, expressions.toArray(expressionsArray));
    }

    @Override
    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query
    ) {
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case LOCATION_NAME_FIELD:
                        setParameter(filter, query, DataType.STRING);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }

    @Override
    protected String getParameterName(Filter filter
    ) {
        if (null != filter.getFieldName()) {
            switch (filter.getFieldName()) {
                case REFERENCE_NUMBER_FIELD:
                    return "referenceNumber";
                case LOCATION_NAME_FIELD:
                    return "locationName";
                default:
                    break;
            }
        }
        return super.getParameterName(filter);
    }
}
