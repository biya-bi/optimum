/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

/**
 *
 * @author Biya-Bi
 */
final class PersistenceSettings {

    final static String PERSISTENCE_UNIT_NAME = "optimumStockManagementPU";
}
