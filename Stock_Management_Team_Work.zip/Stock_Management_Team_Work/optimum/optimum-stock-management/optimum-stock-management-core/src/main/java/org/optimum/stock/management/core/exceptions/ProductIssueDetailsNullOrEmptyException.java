/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.exceptions;

/**
 *
 * @author Biya-Bi
 */
public class ProductIssueDetailsNullOrEmptyException extends OptimumStockManagementException {

    public ProductIssueDetailsNullOrEmptyException() {
        super("A product issue's details cannot be null and must contain at least one product with a positive quantity.");
    }

    public ProductIssueDetailsNullOrEmptyException(String message) {
        super(message);
    }
}
