/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Biya-Bi
 * @param <T>
 */
@MappedSuperclass
public abstract class Trackable<T> extends Identifiable<T> {

    private Date creationDate;
    private Date lastUpdateDate;
    private long version;

    public Trackable() {
    }

    public Trackable(T id) {
        super(id);
    }

    public Trackable(Date creationDate, Date lastUpdateDate) {
        this.creationDate = creationDate;
        this.lastUpdateDate = lastUpdateDate;
    }

    public Trackable(Date creationDate, Date lastUpdateDate, long version, T id) {
        super(id);
        this.creationDate = creationDate;
        this.lastUpdateDate = lastUpdateDate;
        this.version = version;
    }

    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE", nullable = false)
    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATE_DATE", nullable = false)
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public long getVersion() {
        return this.version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @PrePersist
    private void onPersist() {
        lastUpdateDate = creationDate = new Date();
    }

    @PreUpdate
    private void onUpdate() {
        lastUpdateDate = new Date();
    }
}
