/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.DataType;
import org.optimum.persistence.Filter;
import org.optimum.stock.management.core.entities.ProductIssue;
import org.optimum.persistence.Pageable;
import org.optimum.persistence.SearchCriteria;
import org.optimum.persistence.UpdateOperation;
import org.optimum.stock.management.core.entities.Document_;
import org.optimum.stock.management.core.entities.Identifiable_;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ProductIssueDetail;
import org.optimum.stock.management.core.exceptions.DuplicateProductIssueReferenceNumberException;
import org.optimum.stock.management.core.exceptions.InsufficientInventoryException;
import org.optimum.stock.management.core.exceptions.ProductIssueDetailsNullOrEmptyException;

/**
 *
 * @author Biya-Bi
 */
@Stateless
@Pageable(attributeName = "id")
public class ProductIssueFacade extends CrudFacade<ProductIssue> {

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    @EJB
    private LocationFacade locationFacade;

    @EJB
    private InventoryManager inventoryManager;

    @EJB
    private ProductFacade productFacade;

    private static final String REFERENCE_NUMBER_FIELD = "referenceNumber";
    private static final String LOCATION_NAME_FIELD = "location.name";

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductIssueFacade() {
        super(ProductIssue.class);
    }

    @Override
    protected void validate(ProductIssue productIssue, UpdateOperation operation) throws Exception {
        switch (operation) {
            case CREATE: {
                if (exists(productIssue.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), null)) {
                    throw new DuplicateProductIssueReferenceNumberException(productIssue.getReferenceNumber());
                }
                break;
            }
            case UPDATE: {
                if (exists(productIssue.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), productIssue.getId())) {
                    throw new DuplicateProductIssueReferenceNumberException(productIssue.getReferenceNumber());
                }
                break;
            }
        }
    }

    @Override
    public void create(ProductIssue productIssue) throws Exception {
        Location location = locationFacade.getPersistent(productIssue.getLocation());
        productIssue.setLocation(location);
        Long locationId = location.getId();

        if (productIssue.getDetails() == null || productIssue.getDetails().isEmpty()) {
            throw new ProductIssueDetailsNullOrEmptyException();
        }

        List<Long> productIds = new ArrayList<>();

        List<ProductIssueDetail> details = productIssue.getDetails();

        int detailId = 0;
        int noOfDetailsWithPositiveQuantities = 0;

        for (ProductIssueDetail detail : details) {
            if (detail.getQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;

                detail.setProductIssue(productIssue);
                detail.setDetailId(++detailId);
                productIds.add(detail.getProduct().getId());
            }
        }

        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new ProductIssueDetailsNullOrEmptyException();
        }

        List<ProductInventory> productInventories = inventoryManager.getProductInventories(location.getId(), productIds);

        List<Product> persistentProducts = getPersistentProducts(productIds);

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!persistentProducts.contains(detail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", productId));
            }
            detail.setProduct(persistentProducts.get(persistentProducts.indexOf(detail.getProduct())));

            Short issuedQuantity = detail.getQuantity();

            if (issuedQuantity > 0) {
                boolean found = false;
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        short availableQuantity = productInventory.getQuantity();
                        short remainingQuantity = (short) (availableQuantity - issuedQuantity);
                        if (remainingQuantity < 0) {
                            throw new InsufficientInventoryException(locationId, productId, availableQuantity, issuedQuantity);
                        }
                        productInventory.setQuantity(remainingQuantity);
                        if (remainingQuantity > 0) {
                            em.merge(productInventory);
                        }
                        else {
                            em.remove(productInventory);
                        }
                        found = true;
                        break;
                    }
                }
                //If the product we are issuing is not found in the inventory, we complain.
                if (!found) {
                    throw new InsufficientInventoryException(locationId, productId, (short) 0, issuedQuantity);
                }
            }
        }
        super.create(productIssue);
    }

    private int getDetailId(List<ProductIssueDetail> oldDetails, List<ProductIssueDetail> newDetails) {
        List<Integer> detailIds = new ArrayList<>();
        for (ProductIssueDetail oldDetail : oldDetails) {
            Integer detailId = oldDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        for (ProductIssueDetail newDetail : newDetails) {
            Integer detailId = newDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        int detailId = 0;
        while (detailId++ < newDetails.size()) {
            if (!detailIds.contains(detailId)) {
                break;
            }
        }
        return detailId;
    }

    private Map<Long, Short> getProductIdsByQuantities(List<ProductIssueDetail> details) {
        Map<Long, Short> result = new HashMap<>();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!result.containsKey(productId)) {
                result.put(productId, detail.getQuantity());
            }
            else {
                result.replace(productId, (short) (result.get(productId) + detail.getQuantity()));
            }
        }
        return result;
    }

    private List<Product> getPersistentProducts(List<Long> productIds) {
        SearchCriteria c = new SearchCriteria();
        c.setIds(productIds);
        return productFacade.find(c);
    }

    @Override
    public void edit(ProductIssue productIssue) throws Exception {
        Location newLocation = locationFacade.getPersistent(productIssue.getLocation());

        productIssue.setLocation(newLocation);
        Long newLocationId = newLocation.getId();

        if (productIssue.getDetails() == null || productIssue.getDetails().isEmpty()) {
            throw new ProductIssueDetailsNullOrEmptyException();
        }

        List<Long> productIds = new ArrayList<>();

        List<ProductIssueDetail> newDetails = productIssue.getDetails();

        int noOfDetailsWithPositiveQuantities = 0;

        for (ProductIssueDetail detail : newDetails) {
            if (detail.getQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;

                detail.setProductIssue(productIssue);
                productIds.add(detail.getProduct().getId());
            }
        }

        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new ProductIssueDetailsNullOrEmptyException();
        }

        List<ProductInventory> newLocationProductInventories = inventoryManager.getProductInventories(newLocationId, productIds);

        ProductIssue persistentProductIssue = getPersistent(productIssue);
        List<ProductIssueDetail> oldDetails = persistentProductIssue.getDetails();
        Location oldLocation = persistentProductIssue.getLocation();

        Long oldLocationId = oldLocation.getId();

        List<ProductInventory> oldLocationProductInventories = !oldLocation.equals(newLocation) ? inventoryManager.getProductInventories(oldLocationId, productIds) : null;

        Map<Long, Short> productCountNotInInventory = new HashMap<>();

        for (ProductIssueDetail oldDetail : oldDetails) {
            Long oldDetailProductId = oldDetail.getProduct().getId();
            if (!productCountNotInInventory.containsKey(oldDetailProductId)) {
                productCountNotInInventory.put(oldDetailProductId, oldDetail.getQuantity());
            }
            else {
                productCountNotInInventory.replace(oldDetailProductId, (short) (productCountNotInInventory.get(oldDetailProductId) + oldDetail.getQuantity()));
            }
        }
        //If oldLocationProductInventories == null, then the locations are the same. 
        if (oldLocationProductInventories == null) {
            for (ProductInventory productInventory : newLocationProductInventories) {
                Long inventoryProductId = productInventory.getId().getProductId();
                if (productCountNotInInventory.containsKey(inventoryProductId)) {
                    productCountNotInInventory.remove(inventoryProductId);
                }
            }
        }
        else {
            for (ProductInventory productInventory : oldLocationProductInventories) {
                Long inventoryProductId = productInventory.getId().getProductId();
                if (productCountNotInInventory.containsKey(inventoryProductId)) {
                    productCountNotInInventory.remove(inventoryProductId);
                }
            }
        }
        Map<Long, Short> oldProductIdsByQuantities = getProductIdsByQuantities(oldDetails);
        Map<Long, Short> newProductIdsByQuantities = getProductIdsByQuantities(newDetails);

        List<Long> processedProductId = new ArrayList<>();

        List<Product> persistentProducts = getPersistentProducts(productIds);

        for (ProductIssueDetail newDetail : newDetails) {
            Long productId = newDetail.getProduct().getId();
            if (!persistentProducts.contains(newDetail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", productId));
            }
            newDetail.setProduct(persistentProducts.get(persistentProducts.indexOf(newDetail.getProduct())));

            if (!processedProductId.contains(productId)) {
                processedProductId.add(productId);

                short newQuantity = newProductIdsByQuantities.containsKey(productId) ? newProductIdsByQuantities.get(productId) : 0;

                short oldQuantity = oldProductIdsByQuantities.containsKey(productId) ? oldProductIdsByQuantities.get(productId) : 0;

                boolean found = false;
                // oldLocationProductInventories == null if the locations are the same.
                if (oldLocationProductInventories == null) {
                    for (ProductInventory productInventory : newLocationProductInventories) {
                        if (productInventory.getId().getProductId().equals(productId)) {
                            short availableQuantity = productInventory.getQuantity();
                            short remainingQuantity = (short) (availableQuantity + oldQuantity - newQuantity);
                            if (remainingQuantity < 0) {
                                throw new InsufficientInventoryException(newLocationId, productId, availableQuantity, (short) (newQuantity - oldQuantity));
                            }
                            productInventory.setQuantity(remainingQuantity);
                            if (remainingQuantity > 0) {
                                em.merge(productInventory);
                            }
                            else {
                                em.remove(productInventory);
                            }
                            found = true;
                            break;
                        }
                    }
                }
                else {
                    //First, we have to restitute the products that were removed from the inventory of the old location.
                    for (ProductInventory productInventory : oldLocationProductInventories) {
                        if (productInventory.getId().getProductId().equals(productId)) {
                            short availableQuantity = productInventory.getQuantity();
                            short remainingQuantity = (short) (availableQuantity + oldQuantity);
                            productInventory.setQuantity(remainingQuantity);
                            if (remainingQuantity > 0) {
                                em.merge(productInventory);
                            }
                            else {
                                em.remove(productInventory);
                            }
                        }
                    }
                    //Now, we have to remove the products from the inventory of the new location.
                    for (ProductInventory productInventory : newLocationProductInventories) {
                        if (productInventory.getId().getProductId().equals(productId)) {
                            short availableQuantity = productInventory.getQuantity();
                            short remainingQuantity = (short) (availableQuantity - newQuantity);
                            if (remainingQuantity < 0) {
                                throw new InsufficientInventoryException(newLocationId, productId, availableQuantity, newQuantity);
                            }
                            productInventory.setQuantity(remainingQuantity);
                            if (remainingQuantity > 0) {
                                em.merge(productInventory);
                            }
                            else {
                                em.remove(productInventory);
                            }
                            found = true;
                            break;
                        }
                    }
                }
                //If the product we are issuing is not found in the inventory, we complain.
                if (!found) {
                    throw new InsufficientInventoryException(newLocationId, productId, (short) 0, newQuantity);
                }
            }
            if (!oldDetails.contains(newDetail)) {
                newDetail.setDetailId(getDetailId(oldDetails, newDetails));
                em.persist(newDetail);
            }
            else {
                em.merge(newDetail);
            }
        }
        for (ProductIssueDetail oldDetail : oldDetails) {
            if (!newDetails.contains(oldDetail)) {
                em.remove(oldDetail);
            }
        }

        // If a product in an old detail is not found in the new location inventory, we have to throw an exception.
        // If the locations are different, we must make sure that all products in the old details appear in the new location.
        if (!oldDetails.isEmpty() && !productCountNotInInventory.isEmpty()) {
            Long productId = productCountNotInInventory.keySet().iterator().next();
            throw new InsufficientInventoryException(newLocationId, productId, (short) 0, productCountNotInInventory.get(productId));
        }
        super.edit(productIssue);
    }

    @Override
    public void remove(ProductIssue productIssue) throws Exception {
        List<Long> productIds = new ArrayList<>();

        ProductIssue persistentProductIssue = getPersistent(productIssue);
        Long locationId = persistentProductIssue.getLocation().getId();
        List<ProductIssueDetail> details = persistentProductIssue.getDetails();

        int totalDetails = details.size();
        for (int i = 0; i < totalDetails; i++) {
            productIds.add(details.get(i).getProduct().getId());
        }

        List<ProductInventory> productInventories = inventoryManager.getProductInventories(locationId, productIds);

        Map<Long, Short> productIdsByQuantities = getProductIdsByQuantities(details);

        List<Long> processedProductId = new ArrayList<>();

        for (ProductIssueDetail oldDetail : details) {
            Long productId = oldDetail.getProduct().getId();

            if (!processedProductId.contains(productId)) {
                processedProductId.add(productId);

                short oldQuantity = productIdsByQuantities.containsKey(productId) ? productIdsByQuantities.get(productId) : 0;

                //First, we have to remove the products that were added to the inventory of the location.
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        short availableQuantity = productInventory.getQuantity();
                        short remainingQuantity = (short) (availableQuantity + oldQuantity);
                        productInventory.setQuantity(remainingQuantity);
                        if (remainingQuantity > 0) {
                            em.merge(productInventory);
                        }
                        else {
                            em.remove(productInventory);
                        }
                    }
                }
            }
            em.remove(oldDetail);
        }

        super.remove(productIssue);
    }

    @Override
    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<ProductIssue> rt, CriteriaQuery cq
    ) {
        List<Expression<Boolean>> expressions = new ArrayList<>();
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case LOCATION_NAME_FIELD:
                        expressions.add(getExpression(filter, DataType.STRING, cb, rt, cq));
                        break;
                    default:
                        break;
                }
            }
        }
        Expression[] expressionsArray = new Expression[expressions.size()];
        return super.and(cb, expressions.toArray(expressionsArray));
    }

    @Override
    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query
    ) {
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case LOCATION_NAME_FIELD:
                        setParameter(filter, query, DataType.STRING);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }

    @Override
    protected String getParameterName(Filter filter
    ) {
        if (null != filter.getFieldName()) {
            switch (filter.getFieldName()) {
                case REFERENCE_NUMBER_FIELD:
                    return "referenceNumber";
                case LOCATION_NAME_FIELD:
                    return "locationName";
                default:
                    break;
            }
        }
        return super.getParameterName(filter);
    }
}
