/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.DataType;
import org.optimum.persistence.Filter;
import org.optimum.persistence.Pageable;
import org.optimum.persistence.SearchCriteria;
import org.optimum.persistence.UpdateOperation;
import static org.optimum.persistence.UpdateOperation.CREATE;
import static org.optimum.persistence.UpdateOperation.DELETE;
import static org.optimum.persistence.UpdateOperation.UPDATE;
import org.optimum.stock.management.core.entities.Document_;
import org.optimum.stock.management.core.entities.Identifiable_;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ProductInventoryId;
import org.optimum.stock.management.core.entities.ShippingOrder;
import org.optimum.stock.management.core.entities.ShippingOrderDetail;
import org.optimum.stock.management.core.entities.ShippingOrderStatus;
import org.optimum.stock.management.core.entities.ShippingOrder_;
import org.optimum.stock.management.core.exceptions.DuplicateShippingOrderReferenceNumberException;
import org.optimum.stock.management.core.exceptions.InsufficientInventoryException;
import org.optimum.stock.management.core.exceptions.ShippingOrderDeliveredQuantityTooLargeException;
import org.optimum.stock.management.core.exceptions.ShippingOrderDeliveredQuantityNegativeException;
import org.optimum.stock.management.core.exceptions.ShippingOrderDetailsNullOrEmptyException;
import org.optimum.stock.management.core.exceptions.ShippingOrderLocationException;
import org.optimum.stock.management.core.exceptions.ShippingOrderStatusTransitionException;
import org.optimum.stock.management.core.exceptions.ShippingOrderReadOnlyException;

/**
 *
 * @author Biya-Bi
 */
@Stateless
@Pageable(attributeName = "id")
public class ShippingOrderFacade extends CrudFacade<ShippingOrder> {
    
    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;
    
    @EJB
    private LocationFacade locationFacade;
    
    @EJB
    private InventoryManager inventoryManager;
    
    @EJB
    private ShipMethodFacade shipMethodFacade;
    
    @EJB
    private ProductFacade productFacade;
    
    private static final String REFERENCE_NUMBER_FIELD = "referenceNumber";
    private static final String SOURCE_LOCATION_NAME_FIELD = "sourceLocation.name";
    private static final String TARGET_LOCATION_NAME_FIELD = "targetLocation.name";
    private static final String SHIP_METHOD_NAME_FIELD = "shipMethod.name";
    private static final String STATUS_FIELD = "status";
    private static final String SHIP_DATE_FIELD = "shipDate";
    private static final String SHIP_DATE_NEXT_DAY = "shipDateNextDay";
    private static final String SHIP_DATE_PREVIOUS_DAY = "shipDatePreviousDay";
    private static final String DELIVERY_DATE_FIELD = "deliveryDate";
    private static final String DELIVERY_DATE_NEXT_DAY = "deliveryDateNextDay";
    private static final String DELIVERY_DATE_PREVIOUS_DAY = "deliveryDatePreviousDay";
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    public ShippingOrderFacade() {
        super(ShippingOrder.class);
    }
    
    private void validatePersistentStatus(ShippingOrderStatus status, UpdateOperation operation) throws ShippingOrderReadOnlyException {
        if (operation == UpdateOperation.UPDATE || operation == UpdateOperation.DELETE) {
            if (status != null && status != ShippingOrderStatus.PENDING) {
                throw new ShippingOrderReadOnlyException(status);
            }
        }
    }
    
    private void validateTransition(ShippingOrderStatus oldStatus, ShippingOrderStatus newStatus) throws ShippingOrderStatusTransitionException {
        if (null != oldStatus) {
            switch (oldStatus) {
                case PENDING:
                    if (newStatus == ShippingOrderStatus.PENDING || newStatus == ShippingOrderStatus.APPROVED || newStatus == ShippingOrderStatus.REJECTED) {
                        return;
                    }
                    break;
                case APPROVED:
                    if (newStatus == ShippingOrderStatus.IN_TRANSIT) {
                        return;
                    }
                    break;
                case IN_TRANSIT:
                    if (newStatus == ShippingOrderStatus.DELIVERED || newStatus == ShippingOrderStatus.RESTITUTED) {
                        return;
                    }
                    break;
                default:
                    break;
            }
        }
        throw new ShippingOrderStatusTransitionException(oldStatus, newStatus);
    }
    
    private ShippingOrderStatus getPersistentStatus(Long shippingOrderId) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery cq = cb.createTupleQuery();
        Root rt = cq.from(ShippingOrder.class);
        cq.select(cb.tuple(rt.get(ShippingOrder_.status.getName())));
        cq.where(cb.equal(rt.get(Identifiable_.id.getName()), shippingOrderId));
        TypedQuery tq = em.createQuery(cq);
        List<Tuple> results = tq.getResultList();
        if (!results.isEmpty()) {
            return (ShippingOrderStatus) results.get(0).get(0);
        }
        return null;
    }
    
    @Override
    protected void validate(ShippingOrder shippingOrder, UpdateOperation operation) throws Exception {
        switch (operation) {
            case CREATE: {
                if (exists(shippingOrder.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), null)) {
                    throw new DuplicateShippingOrderReferenceNumberException(shippingOrder.getReferenceNumber());
                }
                validateLocations(shippingOrder);
                break;
            }
            case UPDATE: {
                if (exists(shippingOrder.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), shippingOrder.getId())) {
                    throw new DuplicateShippingOrderReferenceNumberException(shippingOrder.getReferenceNumber());
                }
                validateLocations(shippingOrder);
                ShippingOrderStatus oldStatus = getPersistentStatus(shippingOrder.getId());
                validatePersistentStatus(oldStatus, operation); //If no exception is thrown at this point, then the old status is PENDING.
                break;
            }
            case DELETE: {
                ShippingOrderStatus oldStatus = getPersistentStatus(shippingOrder.getId());
                validatePersistentStatus(oldStatus, operation);
                break;
            }
        }
    }
    
    private void validateLocations(ShippingOrder shippingOrder) throws ShippingOrderLocationException, NonexistentEntityException {
        shippingOrder.setSourceLocation(locationFacade.getPersistent(shippingOrder.getSourceLocation()));
        shippingOrder.setTargetLocation(locationFacade.getPersistent(shippingOrder.getTargetLocation()));
        if (shippingOrder.getSourceLocation().equals(shippingOrder.getTargetLocation())) {
            throw new ShippingOrderLocationException(shippingOrder.getSourceLocation().getId());
        }
    }
    
    private List<Product> getPersistentProducts(List<Long> productIds) {
        SearchCriteria c = new SearchCriteria();
        c.setIds(productIds);
        return productFacade.find(c);
    }
    
    @Override
    public void create(ShippingOrder shippingOrder) throws Exception {
        shippingOrder.setStatus(ShippingOrderStatus.PENDING);
        shippingOrder.setShipDate(null);
        shippingOrder.setShipMethod(shipMethodFacade.getPersistent(shippingOrder.getShipMethod()));
        
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        if (details == null || details.isEmpty()) {
            throw new ShippingOrderDetailsNullOrEmptyException();
        }
        
        List<Long> productIds = new ArrayList<>();
        for (ShippingOrderDetail detail : details) {
            productIds.add(detail.getProduct().getId());
        }
        List<Product> persistentProducts = getPersistentProducts(productIds);
        
        int detailId = 0;
        int noOfDetailsWithPositiveQuantities = 0;
        
        for (ShippingOrderDetail detail : details) {
            if (!persistentProducts.contains(detail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", detail.getProduct().getId()));
            }
            detail.setProduct(persistentProducts.get(persistentProducts.indexOf(detail.getProduct())));
            
            if (detail.getShippedQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;
                
                detail.setShippingOrder(shippingOrder);
                detail.setDetailId(++detailId);
                detail.setReceivedQuantity((short) 0);
                detail.setRejectedQuantity((short) 0);
            }
        }
        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new ShippingOrderDetailsNullOrEmptyException();
        }
        super.create(shippingOrder);
    }
    
    private int getDetailId(List<ShippingOrderDetail> oldDetails, List<ShippingOrderDetail> newDetails) {
        List<Integer> detailIds = new ArrayList<>();
        for (ShippingOrderDetail oldDetail : oldDetails) {
            Integer detailId = oldDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        for (ShippingOrderDetail newDetail : newDetails) {
            Integer detailId = newDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        int detailId = 0;
        while (detailId++ < newDetails.size()) {
            if (!detailIds.contains(detailId)) {
                break;
            }
        }
        return detailId;
    }
    
    @Override
    public void edit(ShippingOrder shippingOrder) throws Exception {
        // We set the status of the purchase order to PENDING. This is because we do not want any status change to happen in the edit method.
        shippingOrder.setStatus(ShippingOrderStatus.PENDING);
        shippingOrder.setShipDate(null);
        shippingOrder.setShipMethod(shipMethodFacade.getPersistent(shippingOrder.getShipMethod()));
        
        List<ShippingOrderDetail> newDetails = shippingOrder.getDetails();
        if (newDetails == null || newDetails.isEmpty()) {
            throw new ShippingOrderDetailsNullOrEmptyException();
        }
        
        ShippingOrder persistentShippingOrder = getPersistent(shippingOrder);
        List<ShippingOrderDetail> oldDetails = persistentShippingOrder.getDetails();
        
        List<Long> productIds = new ArrayList<>();
        for (ShippingOrderDetail detail : newDetails) {
            productIds.add(detail.getProduct().getId());
        }
        List<Product> persistentProducts = getPersistentProducts(productIds);
        
        int noOfDetailsWithPositiveQuantities = 0;
        for (ShippingOrderDetail newDetail : newDetails) {
            if (!persistentProducts.contains(newDetail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", newDetail.getProduct().getId()));
            }
            newDetail.setProduct(persistentProducts.get(persistentProducts.indexOf(newDetail.getProduct())));
            
            newDetail.setShippingOrder(shippingOrder);
            newDetail.setReceivedQuantity((short) 0);
            newDetail.setRejectedQuantity((short) 0);
            if (!oldDetails.contains(newDetail)) {
                newDetail.setDetailId(getDetailId(oldDetails, newDetails));
                em.persist(newDetail);
            }
            else {
                em.merge(newDetail);
            }
            if (newDetail.getShippedQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;
            }
        }
        
        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new ShippingOrderDetailsNullOrEmptyException();
        }
        
        for (ShippingOrderDetail oldDetail : oldDetails) {
            if (!newDetails.contains(oldDetail)) {
                em.remove(oldDetail);
            }
        }
        super.edit(shippingOrder);
    }
    
    private ShippingOrder changeStatus(Long shippingOrderId, ShippingOrderStatus newStatus) throws ShippingOrderStatusTransitionException, NonexistentEntityException {
        ShippingOrder shippingOrder = getPersistent(new ShippingOrder(shippingOrderId));
        ShippingOrderStatus oldStatus = shippingOrder.getStatus();
        validateTransition(oldStatus, newStatus);
        shippingOrder.setStatus(newStatus);
        em.merge(shippingOrder);
        return shippingOrder;
    }
    
    public void approve(Long shippingOrderId) throws Exception {
        changeStatus(shippingOrderId, ShippingOrderStatus.APPROVED);
    }
    
    public void reject(Long shippingOrderId) throws Exception {
        changeStatus(shippingOrderId, ShippingOrderStatus.REJECTED);
    }

    /**
     * This method will decrement the inventory of the source location.
     *
     * @param shippingOrderId
     * @throws
     * org.optimum.stock.management.core.exceptions.ShippingOrderStatusTransitionException
     * @throws
     * org.optimum.stock.management.core.exceptions.InsufficientInventoryException
     * @throws org.optimum.persistence.exceptions.NonexistentEntityException
     */
    public void transit(Long shippingOrderId) throws ShippingOrderStatusTransitionException, InsufficientInventoryException, NonexistentEntityException {
        ShippingOrder shippingOrder = changeStatus(shippingOrderId, ShippingOrderStatus.IN_TRANSIT);
        shippingOrder.setShipDate(new Date());
        Location sourceLocation = shippingOrder.getSourceLocation();
        
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        Map<Long, Short> productCount = new HashMap<>();
        for (ShippingOrderDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!productCount.containsKey(productId)) {
                productCount.put(productId, (short) 0);
            }
            short shippedQuantity = detail.getShippedQuantity();
            if (shippedQuantity > 0) {
                productCount.replace(productId, (short) (productCount.get(productId) + shippedQuantity));
            }
        }
        ArrayList<Long> productIds = new ArrayList<>(productCount.keySet());
        List<ProductInventory> productInventories = inventoryManager.getProductInventories(sourceLocation.getId(), productIds);
        for (Long productId : productIds) {
            Short shippedQuantity = productCount.get(productId);
            if (shippedQuantity > 0) {
                boolean found = false;
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        Short availableQuantity = productInventory.getQuantity();
                        if (availableQuantity < shippedQuantity) {
                            throw new InsufficientInventoryException(sourceLocation.getId(), productId, availableQuantity, shippedQuantity);
                        }
                        short remainingQuantity = (short) (availableQuantity - shippedQuantity);
                        productInventory.setQuantity(remainingQuantity);
                        if (remainingQuantity > 0) {
                            em.merge(productInventory);
                        }
                        else {
                            em.remove(productInventory);
                        }
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    throw new InsufficientInventoryException(sourceLocation.getId(), productId, (short) 0, shippedQuantity);
                }
            }
        }
    }
    
    private void validateDelivery(ShippingOrder shippingOrder, Map<Long, Short> productsCount) throws ShippingOrderDeliveredQuantityNegativeException, ShippingOrderDeliveredQuantityTooLargeException {
        List<Long> productIds = new ArrayList<>(productsCount.keySet());
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        for (Long productId : productIds) {
            Short deliveredQuantity = productsCount.get(productId);
            if (deliveredQuantity < 0) {
                throw new ShippingOrderDeliveredQuantityNegativeException(shippingOrder.getId(), productId, deliveredQuantity);
            }
            short shippedQuantity = 0;
            for (ShippingOrderDetail detail : details) {
                if (detail.getProduct().getId().equals(productId)) {
                    shippedQuantity += detail.getShippedQuantity();
                }
            }
            if (deliveredQuantity > shippedQuantity) {
                throw new ShippingOrderDeliveredQuantityTooLargeException(shippingOrder.getId(), productId, shippedQuantity, deliveredQuantity);
            }
        }
    }

    /**
     * This method will increment the inventory of the target location.
     *
     * @param shippingOrderId
     * @param productCount
     * @throws
     * org.optimum.stock.management.core.exceptions.ShippingOrderStatusTransitionException
     * @throws
     * org.optimum.stock.management.core.exceptions.ShippingOrderDeliveredQuantityNegativeException
     * @throws
     * org.optimum.stock.management.core.exceptions.ShippingOrderDeliveredQuantityTooLargeException
     * @throws org.optimum.persistence.exceptions.NonexistentEntityException
     */
    public void deliver(Long shippingOrderId, Map<Long, Short> productCount) throws ShippingOrderStatusTransitionException, ShippingOrderDeliveredQuantityNegativeException, ShippingOrderDeliveredQuantityTooLargeException, NonexistentEntityException {
        ShippingOrder shippingOrder = changeStatus(shippingOrderId, ShippingOrderStatus.DELIVERED);
        validateDelivery(shippingOrder, productCount);
        Location targetLocation = shippingOrder.getTargetLocation();
        Long locationId = targetLocation.getId();
        shippingOrder.setDeliveryDate(new Date());
        
        List<Long> productIds = new ArrayList<>(productCount.keySet());
        List<ProductInventory> productInventories = inventoryManager.getProductInventories(targetLocation.getId(), productIds);
        for (Long productId : productIds) {
            Short deliveredQuantity = productCount.get(productId);
            if (deliveredQuantity > 0) {
                boolean found = false;
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        productInventory.setQuantity((short) (productInventory.getQuantity() + deliveredQuantity));
                        em.merge(productInventory);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    ProductInventory productInventory = new ProductInventory();
                    productInventory.setId(new ProductInventoryId(locationId, productId));
                    productInventory.setQuantity(deliveredQuantity);
                    productInventories.add(productInventory);
                    em.persist(productInventory);
                }
            }
        }
        
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        for (ShippingOrderDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (productCount.containsKey(productId)) {
                Short deliveredQuantity = productCount.get(productId);
                detail.setReceivedQuantity(deliveredQuantity);
                detail.setRejectedQuantity((short) (detail.getShippedQuantity() - deliveredQuantity));
                em.merge(detail);
            }
        }
    }

    /**
     * This method will restitute the inventory of the source location.
     *
     * @param shippingOrderId
     * @throws
     * org.optimum.stock.management.core.exceptions.ShippingOrderStatusTransitionException
     * @throws org.optimum.persistence.exceptions.NonexistentEntityException
     */
    public void restitute(Long shippingOrderId) throws ShippingOrderStatusTransitionException, NonexistentEntityException {
        ShippingOrder shippingOrder = changeStatus(shippingOrderId, ShippingOrderStatus.RESTITUTED);
        Location sourceLocation = shippingOrder.getSourceLocation();
        Long locationId = sourceLocation.getId();
        
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        Map<Long, Short> productCount = new HashMap<>();
        for (ShippingOrderDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!productCount.containsKey(productId)) {
                productCount.put(productId, (short) 0);
            }
            short shippedQuantity = detail.getShippedQuantity();
            if (shippedQuantity > 0) {
                productCount.replace(productId, (short) (productCount.get(productId) + shippedQuantity));
            }
        }
        ArrayList<Long> productIds = new ArrayList<>(productCount.keySet());
        List<ProductInventory> productInventories = inventoryManager.getProductInventories(sourceLocation.getId(), productIds);
        for (Long productId : productIds) {
            Short quantity = productCount.get(productId);
            if (quantity > 0) {
                boolean found = false;
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        productInventory.setQuantity((short) (productInventory.getQuantity() + quantity));
                        em.merge(productInventory);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    ProductInventory productInventory = new ProductInventory();
                    productInventory.setId(new ProductInventoryId(locationId, productId));
                    productInventory.setQuantity(quantity);
                    productInventories.add(productInventory);
                    em.persist(productInventory);
                }
            }
        }
    }
    
    @Override
    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<ShippingOrder> rt, CriteriaQuery cq) {
        List<Expression<Boolean>> expressions = new ArrayList<>();
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case SOURCE_LOCATION_NAME_FIELD:
                    case TARGET_LOCATION_NAME_FIELD:
                    case SHIP_METHOD_NAME_FIELD:
                    case STATUS_FIELD:
                        expressions.add(getExpression(filter, DataType.STRING, cb, rt, cq));
                        break;
                    case SHIP_DATE_FIELD:
                        expressions.add(getDayExpression(filter, cb, rt, cq, SHIP_DATE_PREVIOUS_DAY, SHIP_DATE_NEXT_DAY));
                        break;
                    case DELIVERY_DATE_FIELD:
                        expressions.add(getDayExpression(filter, cb, rt, cq, DELIVERY_DATE_PREVIOUS_DAY, DELIVERY_DATE_NEXT_DAY));
                        break;
                    default:
                        break;
                }
            }
        }
        Expression[] expressionsArray = new Expression[expressions.size()];
        return super.and(cb, expressions.toArray(expressionsArray));
    }
    
    @Override
    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query) {
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case SOURCE_LOCATION_NAME_FIELD:
                    case TARGET_LOCATION_NAME_FIELD:
                    case SHIP_METHOD_NAME_FIELD:
                    case STATUS_FIELD:
                        setParameter(filter, query, DataType.STRING);
                        break;
                    case SHIP_DATE_FIELD:
                        setDayParameters(filter, query, SHIP_DATE_PREVIOUS_DAY, SHIP_DATE_NEXT_DAY);
                        break;
                    case DELIVERY_DATE_FIELD:
                        setDayParameters(filter, query, DELIVERY_DATE_PREVIOUS_DAY, DELIVERY_DATE_NEXT_DAY);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }
    
    @Override
    protected String getParameterName(Filter filter
    ) {
        if (null != filter.getFieldName()) {
            switch (filter.getFieldName()) {
                case REFERENCE_NUMBER_FIELD:
                    return "referenceNumber";
                case SOURCE_LOCATION_NAME_FIELD:
                    return "sourceLocationName";
                case TARGET_LOCATION_NAME_FIELD:
                    return "targetLocationName";
                default:
                    break;
            }
        }
        return super.getParameterName(filter);
    }
    
}
