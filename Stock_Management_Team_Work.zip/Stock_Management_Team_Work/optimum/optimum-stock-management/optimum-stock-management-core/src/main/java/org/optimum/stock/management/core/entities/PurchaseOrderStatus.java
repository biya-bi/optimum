package org.optimum.stock.management.core.entities;

public enum PurchaseOrderStatus {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETE
}
