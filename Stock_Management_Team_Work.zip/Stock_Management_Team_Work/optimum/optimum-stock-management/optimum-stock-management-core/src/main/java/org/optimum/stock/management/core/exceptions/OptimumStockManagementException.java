/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.exceptions;

import javax.ejb.ApplicationException;

/**
 *
 * @author Biya-Bi
 */
@ApplicationException(rollback = true)
public class OptimumStockManagementException extends Exception {

    public OptimumStockManagementException() {
    }

    public OptimumStockManagementException(String message) {
        super(message);
    }

    public OptimumStockManagementException(String message, Throwable cause) {
        super(message, cause);
    }

    public OptimumStockManagementException(Throwable cause) {
        super(cause);
    }

    public OptimumStockManagementException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
