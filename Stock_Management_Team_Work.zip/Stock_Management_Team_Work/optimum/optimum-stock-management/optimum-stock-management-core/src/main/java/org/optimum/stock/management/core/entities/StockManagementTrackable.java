/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 *
 * @author Biya-Bi
 * @param <T> The type of the Id
 */
@MappedSuperclass
public abstract class StockManagementTrackable<T> extends Trackable<T> {

    private String creator;
    private String updater;

    public StockManagementTrackable() {
    }

    public StockManagementTrackable(T id) {
        super(id);
    }

    public StockManagementTrackable(Date creationDate, Date lastUpdateDate) {
        super(creationDate, lastUpdateDate);
    }

    public StockManagementTrackable(Date creationDate, Date lastUpdateDate, long version, T id) {
        super(creationDate, lastUpdateDate, version, id);
    }

    public StockManagementTrackable(String createdBy, String updatedBy, Date creationDate, Date lastUpdateDate) {
        super(creationDate, lastUpdateDate);
        this.creator = createdBy;
        this.updater = updatedBy;
    }

    public StockManagementTrackable(String createdBy, String updatedBy, Date creationDate, Date lastUpdateDate, long version, T id) {
        super(creationDate, lastUpdateDate, version, id);
        this.creator = createdBy;
        this.updater = updatedBy;
    }

    @Column(updatable = false)
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getUpdater() {
        return updater;
    }

    public void setUpdater(String updater) {
        this.updater = updater;
    }

}
