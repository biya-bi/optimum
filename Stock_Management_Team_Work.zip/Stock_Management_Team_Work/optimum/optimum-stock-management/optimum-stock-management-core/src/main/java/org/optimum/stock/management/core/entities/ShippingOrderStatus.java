package org.optimum.stock.management.core.entities;

public enum ShippingOrderStatus {
    PENDING,
    APPROVED,
    REJECTED,
    IN_TRANSIT,
    RESTITUTED,
    DELIVERED
}
