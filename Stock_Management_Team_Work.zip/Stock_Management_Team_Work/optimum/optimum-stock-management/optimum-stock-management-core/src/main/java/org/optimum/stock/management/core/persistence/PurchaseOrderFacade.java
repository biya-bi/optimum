/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.DataType;
import org.optimum.persistence.Filter;
import org.optimum.stock.management.core.entities.PurchaseOrder;
import org.optimum.persistence.Pageable;
import org.optimum.persistence.SearchCriteria;
import org.optimum.persistence.UpdateOperation;
import org.optimum.stock.management.core.entities.Document_;
import org.optimum.stock.management.core.entities.Identifiable_;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ProductInventoryId;
import org.optimum.stock.management.core.entities.PurchaseOrderDetail;
import org.optimum.stock.management.core.entities.PurchaseOrderStatus;
import org.optimum.stock.management.core.entities.PurchaseOrder_;
import org.optimum.stock.management.core.entities.ShipMethod;
import org.optimum.stock.management.core.entities.Vendor;
import org.optimum.stock.management.core.exceptions.DuplicatePurchaseOrderReferenceNumberException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderDetailsNullOrEmptyException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderStatusTransitionException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderReadOnlyException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderVendorException;

/**
 *
 * @author Biya-Bi
 */
@Stateless
@Pageable(attributeName = "id")
public class PurchaseOrderFacade extends CrudFacade<PurchaseOrder> {

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    @EJB
    private LocationFacade locationFacade;

    @EJB
    private VendorFacade vendorFacade;

    @EJB
    private InventoryManager inventoryManager;

    @EJB
    private ShipMethodFacade shipMethodFacade;

    @EJB
    private ProductFacade productFacade;

    private static final String REFERENCE_NUMBER_FIELD = "referenceNumber";
    private static final String VENDOR_NAME_FIELD = "vendor.name";
    private static final String FREIGHT_FIELD = "freight";
    private static final String REVISION_NUMBER_FIELD = "revisionNumber";
    private static final String STATUS_FIELD = "status";
    private static final String TAX_AMOUNT_FIELD = "taxAmount";
    private static final String LOCATION_NAME_FIELD = "location.name";
    private static final String SHIP_METHOD_NAME_FIELD = "shipMethod.name";
    private static final String SHIP_DATE_FIELD = "shipDate";
    private static final String SHIP_DATE_NEXT_DAY = "shipDateNextDay";
    private static final String SHIP_DATE_PREVIOUS_DAY = "shipDatePreviousDay";

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PurchaseOrderFacade() {
        super(PurchaseOrder.class);
    }

    private void validateVendor(PurchaseOrder purchaseOrder) throws PurchaseOrderVendorException, NonexistentEntityException {
        if (purchaseOrder.getVendor() != null && purchaseOrder.getVendor().getId() != null) {
            Vendor persistentVendor = vendorFacade.getPersistent(purchaseOrder.getVendor());

            if (!persistentVendor.isActive() && purchaseOrder.getStatus() != PurchaseOrderStatus.REJECTED) {
                throw new PurchaseOrderVendorException();
            }
            purchaseOrder.setVendor(persistentVendor);
        }
    }

    private void validatePersistentStatus(PurchaseOrderStatus status, UpdateOperation operation) throws PurchaseOrderReadOnlyException {
        if (operation == UpdateOperation.UPDATE || operation == UpdateOperation.DELETE) {
            if (status != null && status != PurchaseOrderStatus.PENDING) {
                throw new PurchaseOrderReadOnlyException(status);
            }
        }
    }

    private void validateTransition(PurchaseOrderStatus oldStatus, PurchaseOrderStatus newStatus) throws PurchaseOrderStatusTransitionException {
        if (oldStatus == PurchaseOrderStatus.PENDING) {
            if (newStatus == PurchaseOrderStatus.PENDING || newStatus == PurchaseOrderStatus.APPROVED || newStatus == PurchaseOrderStatus.REJECTED) {
                return;
            }
        }
        else if (oldStatus == PurchaseOrderStatus.APPROVED) {
            if (newStatus == PurchaseOrderStatus.COMPLETE) {
                return;
            }
        }
        throw new PurchaseOrderStatusTransitionException(oldStatus, newStatus);
    }

    private PurchaseOrderStatus getPersistentStatus(Long purchaseOrderId) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery cq = cb.createTupleQuery();
        Root rt = cq.from(PurchaseOrder.class);
        cq.select(cb.tuple(rt.get(PurchaseOrder_.status.getName())));
        cq.where(cb.equal(rt.get(Identifiable_.id.getName()), purchaseOrderId));
        TypedQuery tq = em.createQuery(cq);
        List<Tuple> results = tq.getResultList();
        if (!results.isEmpty()) {
            return (PurchaseOrderStatus) results.get(0).get(0);
        }
        return null;
    }

    @Override
    protected void validate(PurchaseOrder purchaseOrder, UpdateOperation operation) throws Exception {
        switch (operation) {
            case CREATE: {
                if (exists(purchaseOrder.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), null)) {
                    throw new DuplicatePurchaseOrderReferenceNumberException(purchaseOrder.getReferenceNumber());
                }
                validateVendor(purchaseOrder);
                break;
            }
            case UPDATE: {
                if (exists(purchaseOrder.getReferenceNumber(), Document_.referenceNumber.getName(), Identifiable_.id.getName(), purchaseOrder.getId())) {
                    throw new DuplicatePurchaseOrderReferenceNumberException(purchaseOrder.getReferenceNumber());
                }
                validateVendor(purchaseOrder);
                PurchaseOrderStatus oldStatus = getPersistentStatus(purchaseOrder.getId());
                validatePersistentStatus(oldStatus, operation); //If no exception is thrown at this point, then the old status is PENDING.
                break;
            }
            case DELETE: {
                PurchaseOrderStatus oldStatus = getPersistentStatus(purchaseOrder.getId());
                validatePersistentStatus(oldStatus, operation);
                break;
            }
        }
    }

    @Override
    public void create(PurchaseOrder purchaseOrder) throws Exception {
        purchaseOrder.setStatus(PurchaseOrderStatus.PENDING);

        ShipMethod shipMethod = purchaseOrder.getShipMethod();
        if (shipMethod != null) {
            purchaseOrder.setShipMethod(shipMethodFacade.getPersistent(shipMethod));
        }

        List<PurchaseOrderDetail> details = purchaseOrder.getDetails();
        if (details == null || details.isEmpty()) {
            throw new PurchaseOrderDetailsNullOrEmptyException();
        }
        List<Long> productIds = new ArrayList<>();
        for (PurchaseOrderDetail detail : details) {
            productIds.add(detail.getProduct().getId());
        }
        List<Product> persistentProducts = getPersistentProducts(productIds);

        int detailId = 0;
        int noOfDetailsWithPositiveQuantities = 0;

        for (PurchaseOrderDetail detail : details) {
            if (!persistentProducts.contains(detail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", detail.getProduct().getId()));
            }
            detail.setProduct(persistentProducts.get(persistentProducts.indexOf(detail.getProduct())));

            if (detail.getOrderedQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;

                detail.setPurchaseOrder(purchaseOrder);
                detail.setDetailId(++detailId);
                detail.setReceivedQuantity((short) 0);
                detail.setRejectedQuantity((short) 0);
            }
        }
        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new PurchaseOrderDetailsNullOrEmptyException();
        }

        super.create(purchaseOrder);
    }

    private int getDetailId(List<PurchaseOrderDetail> oldDetails, List<PurchaseOrderDetail> newDetails) {
        List<Integer> detailIds = new ArrayList<>();
        for (PurchaseOrderDetail oldDetail : oldDetails) {
            Integer detailId = oldDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        for (PurchaseOrderDetail newDetail : newDetails) {
            Integer detailId = newDetail.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        int detailId = 0;
        while (detailId++ < newDetails.size()) {
            if (!detailIds.contains(detailId)) {
                break;
            }
        }
        return detailId;
    }

    private List<Product> getPersistentProducts(List<Long> productIds) {
        SearchCriteria c = new SearchCriteria();
        c.setIds(productIds);
        return productFacade.find(c);
    }

    @Override
    public void edit(PurchaseOrder purchaseOrder) throws Exception {
        // We set the status of the purchase order to PENDING. This is because we do not want any status change to happen in the edit method.
        purchaseOrder.setStatus(PurchaseOrderStatus.PENDING);
        ShipMethod shipMethod = purchaseOrder.getShipMethod();
        if (shipMethod != null) {
            purchaseOrder.setShipMethod(shipMethodFacade.getPersistent(shipMethod));
        }

        List<PurchaseOrderDetail> newDetails = purchaseOrder.getDetails();
        if (newDetails == null || newDetails.isEmpty()) {
            throw new PurchaseOrderDetailsNullOrEmptyException();
        }
        PurchaseOrder persistentPurchaseOrder = getPersistent(purchaseOrder);
        List<PurchaseOrderDetail> oldDetails = persistentPurchaseOrder.getDetails();

        List<Long> productIds = new ArrayList<>();
        for (PurchaseOrderDetail detail : newDetails) {
            productIds.add(detail.getProduct().getId());
        }
        List<Product> persistentProducts = getPersistentProducts(productIds);

        int noOfDetailsWithPositiveQuantities = 0;
        for (PurchaseOrderDetail newDetail : newDetails) {
            if (!persistentProducts.contains(newDetail.getProduct())) {
                throw new NonexistentEntityException(String.format("The product with ID '%s' does not exist.", newDetail.getProduct().getId()));
            }
            newDetail.setProduct(persistentProducts.get(persistentProducts.indexOf(newDetail.getProduct())));

            newDetail.setPurchaseOrder(purchaseOrder);
            newDetail.setReceivedQuantity((short) 0);
            newDetail.setRejectedQuantity((short) 0);
            if (!oldDetails.contains(newDetail)) {
                newDetail.setDetailId(getDetailId(oldDetails, newDetails));
                em.persist(newDetail);
            }
            else {
                em.merge(newDetail);
            }
            if (newDetail.getOrderedQuantity() > 0) {
                noOfDetailsWithPositiveQuantities++;
            }
        }

        if (noOfDetailsWithPositiveQuantities == 0) {
            throw new PurchaseOrderDetailsNullOrEmptyException();
        }

        for (PurchaseOrderDetail oldDetail : oldDetails) {
            if (!newDetails.contains(oldDetail)) {
                em.remove(oldDetail);
            }
        }
        super.edit(purchaseOrder);
    }

    private PurchaseOrder changeStatus(Long purchaseOrderId, PurchaseOrderStatus newStatus) throws Exception {
        PurchaseOrder purchaseOrder = getPersistent(new PurchaseOrder(purchaseOrderId));
        PurchaseOrderStatus oldStatus = purchaseOrder.getStatus();
        validateTransition(oldStatus, newStatus);
        purchaseOrder.setStatus(newStatus);
        validateVendor(purchaseOrder);
        em.merge(purchaseOrder);
        return purchaseOrder;
    }

    public void approve(Long purchaseOrderId) throws Exception {
        changeStatus(purchaseOrderId, PurchaseOrderStatus.APPROVED);
    }

    public void reject(Long purchaseOrderId) throws Exception {
        changeStatus(purchaseOrderId, PurchaseOrderStatus.REJECTED);
    }

    public void complete(Long purchaseOrderId, Long locationId, Map<Long, Short> productCount) throws Exception {
        Location location = locationFacade.getPersistent(new Location(locationId));
        PurchaseOrder purchaseOrder = changeStatus(purchaseOrderId, PurchaseOrderStatus.COMPLETE);
        purchaseOrder.setLocation(location);
        em.merge(purchaseOrder);

        List<Long> productIds = new ArrayList<>(productCount.keySet());
        List<ProductInventory> productInventories = inventoryManager.getProductInventories(locationId, productIds);
        for (Long productId : productIds) {
            Short receivedQuantity = productCount.get(productId);
            if (receivedQuantity > 0) {
                boolean found = false;
                for (ProductInventory productInventory : productInventories) {
                    if (productInventory.getId().getProductId().equals(productId)) {
                        productInventory.setQuantity((short) (productInventory.getQuantity() + receivedQuantity));
                        em.merge(productInventory);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    ProductInventory productInventory = new ProductInventory();
                    productInventory.setId(new ProductInventoryId(locationId, productId));
                    productInventory.setQuantity(receivedQuantity);
                    productInventories.add(productInventory);
                    em.persist(productInventory);
                }
            }
        }
        List<PurchaseOrderDetail> details = purchaseOrder.getDetails();
        for (PurchaseOrderDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (productCount.containsKey(productId)) {
                Short receivedQuantity = productCount.get(productId);
                detail.setReceivedQuantity(receivedQuantity);
                detail.setRejectedQuantity((short) (detail.getOrderedQuantity() - receivedQuantity));
                em.merge(detail);
            }
        }
    }

    @Override
    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<PurchaseOrder> rt, CriteriaQuery cq) {
        List<Expression<Boolean>> expressions = new ArrayList<>();
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case VENDOR_NAME_FIELD:
                    case LOCATION_NAME_FIELD:
                    case SHIP_METHOD_NAME_FIELD:
                    case STATUS_FIELD:
                        expressions.add(getExpression(filter, DataType.STRING, cb, rt, cq));
                        break;
                    case FREIGHT_FIELD:
                    case TAX_AMOUNT_FIELD:
                        expressions.add(getExpression(filter, DataType.DOUBLE, cb, rt, cq));
                        break;
                    case REVISION_NUMBER_FIELD:
                        expressions.add(getExpression(filter, DataType.BYTE, cb, rt, cq));
                        break;
                    case SHIP_DATE_FIELD:
                        expressions.add(getDayExpression(filter, cb, rt, cq, SHIP_DATE_PREVIOUS_DAY, SHIP_DATE_NEXT_DAY));
                        break;
                    default:
                        break;
                }
            }
        }
        Expression[] expressionsArray = new Expression[expressions.size()];
        return super.and(cb, expressions.toArray(expressionsArray));
    }

    @Override
    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query) {
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case REFERENCE_NUMBER_FIELD:
                    case VENDOR_NAME_FIELD:
                    case LOCATION_NAME_FIELD:
                    case SHIP_METHOD_NAME_FIELD:
                    case STATUS_FIELD:
                        setParameter(filter, query, DataType.STRING);
                        break;
                    case FREIGHT_FIELD:
                    case TAX_AMOUNT_FIELD:
                        setParameter(filter, query, DataType.DOUBLE);
                        break;
                    case REVISION_NUMBER_FIELD:
                        setParameter(filter, query, DataType.BYTE);
                        break;
                    case SHIP_DATE_FIELD:
                        setDayParameters(filter, query, SHIP_DATE_PREVIOUS_DAY, SHIP_DATE_NEXT_DAY);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }

    @Override
    protected String getParameterName(Filter filter) {
        if (null != filter.getFieldName()) {
            switch (filter.getFieldName()) {
                case REFERENCE_NUMBER_FIELD:
                    return "referenceNumber";
                case VENDOR_NAME_FIELD:
                    return "vendorName";
                case LOCATION_NAME_FIELD:
                    return "locationName";
                case SHIP_METHOD_NAME_FIELD:
                    return "shipMethodName";
                default:
                    break;
            }
        }
        return super.getParameterName(filter);
    }

}
