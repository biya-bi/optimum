/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.exceptions;

/**
 *
 * @author Biya-Bi
 */
public class DuplicateProductNameException extends OptimumStockManagementException {

    private final String name;

    public DuplicateProductNameException(String name) {
        this(name, String.format("A product with name '%s' already exists.", name));
    }

    public DuplicateProductNameException(String name,  String message) {
        super(message);
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
