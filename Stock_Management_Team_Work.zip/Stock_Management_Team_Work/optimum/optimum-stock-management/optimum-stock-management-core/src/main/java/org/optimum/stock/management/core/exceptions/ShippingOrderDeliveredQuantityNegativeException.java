/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.exceptions;

/**
 * This exception is thrown whenever an attempt is made to deliver a negative
 * quantity for a shipping order.
 *
 * @author Biya-Bi
 */
public class ShippingOrderDeliveredQuantityNegativeException extends OptimumStockManagementException {

    private final Long shippingOrderId;
    private final Long productId;
    private final Short deliveredQuantity;

    public ShippingOrderDeliveredQuantityNegativeException(Long shippingOrderId, Long productId, Short deliveredQuantity) {
        this(shippingOrderId, productId, deliveredQuantity, String.format("The shipping order with ID '%s' has '%s' products with ID '%s' in the delivered. The delivered quantity cannot be negative.", shippingOrderId, deliveredQuantity, productId));
    }

    public ShippingOrderDeliveredQuantityNegativeException(Long shippingOrderId, Long productId, Short deliveredQuantity, String message) {
        super(message);
        this.shippingOrderId = shippingOrderId;
        this.productId = productId;
        this.deliveredQuantity = deliveredQuantity;
    }

    public Long getShippingOrderId() {
        return shippingOrderId;
    }

    public Long getProductId() {
        return productId;
    }

    public Short getDeliveredQuantity() {
        return deliveredQuantity;
    }

}
