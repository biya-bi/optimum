/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.DataType;
import org.optimum.persistence.Filter;
import org.optimum.stock.management.core.entities.ShipMethod;
import org.optimum.persistence.Pageable;
import org.optimum.persistence.UpdateOperation;
import org.optimum.stock.management.core.entities.Identifiable_;
import org.optimum.stock.management.core.entities.ShipMethod_;
import org.optimum.stock.management.core.exceptions.DuplicateShipMethodNameException;

/**
 *
 * @author Biya-Bi
 */
@Stateless
@Pageable(attributeName = "id")
public class ShipMethodFacade extends CrudFacade<ShipMethod> {

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    private static final String NAME_FIELD = "name";

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ShipMethodFacade() {
        super(ShipMethod.class);
    }

    @Override
    protected void validate(ShipMethod shipMethod, UpdateOperation operation) throws Exception {
        switch (operation) {
            case CREATE:
                if (exists(shipMethod.getName(), ShipMethod_.name.getName(), Identifiable_.id.getName(), null)) {
                    throw new DuplicateShipMethodNameException(shipMethod.getName());
                }
                break;
            case UPDATE:
                if (exists(shipMethod.getName(), ShipMethod_.name.getName(), Identifiable_.id.getName(), shipMethod.getId())) {
                    throw new DuplicateShipMethodNameException(shipMethod.getName());
                }
                break;
        }
    }

    @Override
    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<ShipMethod> rt, CriteriaQuery cq) {
        List<Expression<Boolean>> expressions = new ArrayList<>();
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case NAME_FIELD:
                        expressions.add(getExpression(filter, DataType.STRING, cb, rt, cq));
                        break;
                    default:
                        break;
                }
            }
        }
        Expression[] expressionsArray = new Expression[expressions.size()];
        return super.and(cb, expressions.toArray(expressionsArray));
    }

    @Override
    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query) {
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case NAME_FIELD:
                        setParameter(filter, query, DataType.STRING);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }

    @Override
    protected String getParameterName(Filter filter) {
        if (null != filter.getFieldName()) {
            switch (filter.getFieldName()) {
                case NAME_FIELD:
                    return "name";
                default:
                    break;
            }
        }
        return super.getParameterName(filter);
    }

}
