/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Biya-Bi
 */
@Entity
@Table(name = "PRODUCT_ISSUE")
public class ProductIssue extends Document {

    private List<ProductIssueDetail> details;
    private Location location;

    public ProductIssue() {
    }

    public ProductIssue(Long id) {
        super(id);
    }

    public ProductIssue(Location location, String referenceNumber, String createdBy, String updatedBy, Date creationDate, Date lastUpdateDate) {
        super(referenceNumber, createdBy, updatedBy, creationDate, lastUpdateDate);
        this.location = location;
    }

    public ProductIssue(Location location, String referenceNumber, String createdBy, String updatedBy, Date creationDate, Date lastUpdateDate, long version, Long id) {
        super(referenceNumber, createdBy, updatedBy, creationDate, lastUpdateDate, version, id);
        this.location = location;
    }

    @OneToMany(mappedBy = "productIssue", cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    public List<ProductIssueDetail> getDetails() {
        return details;
    }

    public void setDetails(List<ProductIssueDetail> details) {
        this.details = details;
    }

    @NotNull
    @JoinColumn(name = "LOCATION_ID", nullable = false)
    @ManyToOne
    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

}
