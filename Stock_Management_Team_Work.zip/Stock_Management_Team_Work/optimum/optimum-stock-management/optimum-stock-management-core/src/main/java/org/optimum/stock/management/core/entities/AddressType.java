package org.optimum.stock.management.core.entities;

public enum AddressType {
    BUSINESS,
    HOME,
    BILLING,
    SHIPPING,
    OTHER
}
