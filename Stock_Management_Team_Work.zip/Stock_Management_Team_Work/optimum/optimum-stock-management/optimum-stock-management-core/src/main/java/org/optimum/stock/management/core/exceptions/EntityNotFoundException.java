package org.optimum.stock.management.core.exceptions;

public class EntityNotFoundException extends OptimumStockManagementException {

    public EntityNotFoundException(String message) {
        super(message);
    }

    public EntityNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
