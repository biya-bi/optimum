/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import javax.persistence.Entity;

/**
 *
 * @author Biya-Bi
 */
@Entity
public class Contact extends Person {

}
