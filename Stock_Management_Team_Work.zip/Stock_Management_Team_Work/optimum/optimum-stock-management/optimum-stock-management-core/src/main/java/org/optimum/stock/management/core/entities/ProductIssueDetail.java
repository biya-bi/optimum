/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Biya-Bi
 */
@Entity
@Table(name = "PRODUCT_ISSUE_DETAIL")
public class ProductIssueDetail implements Serializable {

    private Integer detailId;
    private ProductIssue productIssue;
    private Product product;
    private Short quantity;

    public ProductIssueDetail() {
    }

    @NotNull
    @Id
    @Column(name = "DETAIL_ID", nullable = false)
    public Integer getDetailId() {
        return detailId;
    }

    public void setDetailId(Integer detailId) {
        this.detailId = detailId;
    }

    @NotNull
    @Id
    @ManyToOne
    @JoinColumn(name = "PRODUCT_ISSUE_ID", nullable = false)
    public ProductIssue getProductIssue() {
        return productIssue;
    }

    public void setProductIssue(ProductIssue productIssue) {
        this.productIssue = productIssue;
    }

    @NotNull
    @ManyToOne
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @NotNull
    @Min(1)
    @Column(name = "QUANTITY", nullable = false)
    public Short getQuantity() {
        return quantity;
    }

    public void setQuantity(Short quantity) {
        this.quantity = quantity;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.detailId);
        hash = 59 * hash + Objects.hashCode(this.productIssue);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ProductIssueDetail other = (ProductIssueDetail) obj;
        if (!Objects.equals(this.detailId, other.detailId)) {
            return false;
        }
        if (!Objects.equals(this.productIssue, other.productIssue)) {
            return false;
        }
        return true;
    }



}
