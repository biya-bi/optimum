package org.optimum.stock.management.core.entities;

public enum Gender {
    MALE,
    FEMALE
}
