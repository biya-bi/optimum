/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.optimum.stock.management.core.entities.ProductInventory;

/**
 *
 * @author Biya-Bi
 */
@Stateless
public class InventoryManager {

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    public List<ProductInventory> getProductInventories(Long locationId) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery();
        Root rt = cq.from(ProductInventory.class);
        cq.select(rt);
        Predicate p = cb.equal(rt.get("id").get("locationId"), locationId);
        cq.where(p);
        TypedQuery tq = em.createQuery(cq);
        return (List<ProductInventory>) tq.getResultList();
    }

    public List<ProductInventory> getProductInventories(Long locationId, List<Long> productIds) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery();
        Root rt = cq.from(ProductInventory.class);
        cq.select(rt);
        Predicate p1 = cb.equal(rt.get("id").get("locationId"), locationId);
        Predicate p2 = rt.get("id").get("productId").in(productIds);
        cq.where(cb.and(p1, p2));
        TypedQuery tq = em.createQuery(cq);
        return (List<ProductInventory>) tq.getResultList();
    }
}
