/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Biya-Bi
 */
@Entity
@Table(name = "PRODUCT_INVENTORY")
@XmlRootElement
public class ProductInventory extends StockManagementTrackable<ProductInventoryId>{
    private Short quantity;

    @Override
    @EmbeddedId
    public ProductInventoryId getId() {
        return super.getId();
    }

    @Override
    public void setId(ProductInventoryId id) {
        super.setId(id);
    }

    
    @Min(0)
    @NotNull
    @Column(name = "QUANTITY", nullable = false)
    public Short getQuantity() {
        return quantity;
    }

    public void setQuantity(Short quantity) {
        this.quantity = quantity;
    }

}
