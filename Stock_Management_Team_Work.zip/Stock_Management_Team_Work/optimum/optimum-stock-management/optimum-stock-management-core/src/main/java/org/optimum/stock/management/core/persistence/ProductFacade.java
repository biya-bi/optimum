/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.DataType;
import org.optimum.persistence.Filter;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.exceptions.DuplicateProductNameException;
import org.optimum.persistence.Pageable;
import org.optimum.persistence.UpdateOperation;
import org.optimum.stock.management.core.entities.Identifiable_;
import org.optimum.stock.management.core.entities.Product_;
import org.optimum.stock.management.core.exceptions.DuplicateProductNumberException;

/**
 *
 * @author Biya-Bi
 */
@Stateless
@Pageable(attributeName = "id")
public class ProductFacade extends CrudFacade<Product> {

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    private static final String NAME_FIELD = "name";
    private static final String NUMBER_FIELD = "number";
    private static final String SAFETY_STOCK_LEVEL_FIELD = "safetyStockLevel";
    private static final String STOCK_COVER_FIELD = "stockCover";
    private static final String REORDER_POINT_FIELD = "reorderPoint";

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductFacade() {
        super(Product.class);
    }

    @Override
    protected void validate(Product product, UpdateOperation operation) throws DuplicateProductNumberException, DuplicateProductNameException {
        switch (operation) {
            case CREATE:
                if (exists(product.getNumber(), Product_.number.getName(), null, null)) {
                    throw new DuplicateProductNumberException(product.getName());
                }
                if (exists(product.getName(), Product_.name.getName(), null, null)) {
                    throw new DuplicateProductNameException(product.getName());
                }
                break;
            case UPDATE:
                if (exists(product.getNumber(), Product_.number.getName(), Identifiable_.id.getName(), product.getId())) {
                    throw new DuplicateProductNumberException(product.getNumber());
                }
                if (exists(product.getName(), Product_.name.getName(), Identifiable_.id.getName(), product.getId())) {
                    throw new DuplicateProductNameException(product.getName());
                }
                break;
        }
    }

    @Override
    protected Expression<Boolean> getExpression(List<Filter> filters, CriteriaBuilder cb, Root<Product> rt, CriteriaQuery cq) {
        List<Expression<Boolean>> expressions = new ArrayList<>();
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case NAME_FIELD:
                    case NUMBER_FIELD:
                        expressions.add(getExpression(filter, DataType.STRING, cb, rt, cq));
                        break;
                    case SAFETY_STOCK_LEVEL_FIELD:
                    case STOCK_COVER_FIELD:
                    case REORDER_POINT_FIELD:
                        expressions.add(getExpression(filter, DataType.SHORT, cb, rt, cq));
                        break;
                    default:
                        break;
                }
            }
        }
        Expression[] expressionsArray = new Expression[expressions.size()];
        return super.and(cb, expressions.toArray(expressionsArray));
    }

    @Override
    protected TypedQuery setParameters(List<Filter> filters, TypedQuery query) {
        for (Filter filter : filters) {
            if (null != filter.getFieldName()) {
                switch (filter.getFieldName()) {
                    case NAME_FIELD:
                    case NUMBER_FIELD:
                        setParameter(filter, query, DataType.STRING);
                        break;
                    case SAFETY_STOCK_LEVEL_FIELD:
                    case STOCK_COVER_FIELD:
                    case REORDER_POINT_FIELD:
                        setParameter(filter, query, DataType.SHORT);
                        break;
                    default:
                        break;
                }
            }
        }
        return query;
    }

    @Override
    protected String getParameterName(Filter filter) {
        if (null != filter.getFieldName()) {
            switch (filter.getFieldName()) {
                case NAME_FIELD:
                    return "productName";
                case NUMBER_FIELD:
                    return "productNumber";
                default:
                    break;
            }
        }
        return super.getParameterName(filter);
    }

}
