/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.exceptions;

/**
 *
 * @author Biya-Bi
 */
public class DuplicateVendorAccountNumberException extends OptimumStockManagementException {

    private final String accountNumber;

    public DuplicateVendorAccountNumberException(String accountNumber) {
        this(accountNumber, String.format("A vendor with account number '%s' already exists.", accountNumber));
    }

    public DuplicateVendorAccountNumberException(String accountNumber,  String message) {
        super(message);
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
}
