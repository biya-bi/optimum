package org.optimum.stock.management.core.entities;

public enum PhoneType {
    BUSINESS,
    HOME,
    MOBILE,
    OTHER
}
