insert into location(id,name,creation_date,last_update_date) values (100,'Location 100',current_timestamp(),current_timestamp());
insert into location(id,name,creation_date,last_update_date) values (101,'Location 101',current_timestamp(),current_timestamp());
insert into location(id,name,creation_date,last_update_date) values (102,'Location 102',current_timestamp(),current_timestamp());
insert into location(id,name,creation_date,last_update_date) values (103,'Location 103',current_timestamp(),current_timestamp());
insert into location(id,name,creation_date,last_update_date) values (104,'Location 104',current_timestamp(),current_timestamp());
commit;