insert into ship_method(id,name,creation_date,last_update_date) values (100,'Ship Method 100',current_timestamp(),current_timestamp());
insert into ship_method(id,name,creation_date,last_update_date) values (101,'Ship Method 101',current_timestamp(),current_timestamp());
insert into ship_method(id,name,creation_date,last_update_date) values (102,'Ship Method 102',current_timestamp(),current_timestamp());
insert into ship_method(id,name,creation_date,last_update_date) values (103,'Ship Method 103',current_timestamp(),current_timestamp());
insert into ship_method(id,name,creation_date,last_update_date) values (104,'Ship Method 104',current_timestamp(),current_timestamp());
commit;