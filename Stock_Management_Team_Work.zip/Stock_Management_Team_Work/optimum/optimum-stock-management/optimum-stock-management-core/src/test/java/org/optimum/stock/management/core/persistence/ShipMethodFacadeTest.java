/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.ShipMethod;
import org.optimum.stock.management.core.exceptions.DuplicateShipMethodNameException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class ShipMethodFacadeTest {

    @EJB
    private ShipMethodFacade shipMethodFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/ShipMethodFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void create_ShipMethodIsValid_ShipMethodCreated() throws Exception {
        ShipMethod expected = new ShipMethod("VDR-NEW-ACC1");

        shipMethodFacade.create(expected);

        ShipMethod actual = em.getReference(ShipMethod.class, expected.getId());
        actual.getId();  // If no exception is thrown, then the create was successful.
    }

    @Test(expected = DuplicateShipMethodNameException.class)
    public void create_NameAlreadyExists_ThrowDuplicateShipMethodNameException() throws Exception {
        ShipMethod shipMethod = new ShipMethod("Ship Method 100");

        try {
            shipMethodFacade.create(shipMethod);
        } catch (DuplicateShipMethodNameException e) {
            Assert.assertEquals(shipMethod.getName(), e.getName());
            throw e;
        }
    }

    @Test
    public void remove_ShipMethodExists_ShipMethodDeleted() throws Exception {
        final ShipMethod shipMethod = new ShipMethod(101L);
        boolean deleted = false;

        shipMethodFacade.remove(shipMethod);

        try {
            em.getReference(ShipMethod.class, shipMethod.getId());
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_ShipMethodDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final ShipMethod shipMethod = new ShipMethod(5000L);
        shipMethodFacade.remove(shipMethod);
    }

    @Test
    public void edit_ShipMethodIsValid_ShipMethodEdited() throws Exception {
        ShipMethod expected = em.getReference(ShipMethod.class, 102L);
        expected.setName(expected.getName() + " Renamed");

        em.clear();

        shipMethodFacade.edit(expected);

        ShipMethod actual = em.getReference(ShipMethod.class, expected.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
    }

    @Test(expected = DuplicateShipMethodNameException.class)
    public void edit_NameAlreadyExists_ThrowDuplicateShipMethodNameException() throws Exception {
        ShipMethod shipMethod = em.getReference(ShipMethod.class, 104L);
        shipMethod.setName("Ship Method 103");

        try {
            shipMethodFacade.edit(shipMethod);
        } catch (DuplicateShipMethodNameException e) {
            Assert.assertEquals(shipMethod.getName(), e.getName());
            throw e;
        }
    }
}
