/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ShippingOrder;
import org.optimum.stock.management.core.entities.ShippingOrderDetail;
import org.optimum.stock.management.core.entities.ShippingOrderStatus;
import org.optimum.stock.management.core.entities.ShipMethod;
import org.optimum.stock.management.core.exceptions.DuplicateShippingOrderReferenceNumberException;
import org.optimum.stock.management.core.exceptions.ShippingOrderDetailsNullOrEmptyException;
import org.optimum.stock.management.core.exceptions.ShippingOrderLocationException;
import org.optimum.stock.management.core.exceptions.ShippingOrderReadOnlyException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class ShippingOrderFacadeTest {
    
    @EJB
    private ShippingOrderFacade shippingOrderFacade;
    
    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;
    
    @EJB
    private InventoryManager inventoryManager;
    
    private static final MySqlDatabase DATABASE = new MySqlDatabase();
    
    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/ShippingOrderFacadeTestSetup.sql");
    }
    
    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }
    
    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }
    
    @Test
    public void create_ShippingOrderIsValid_ShippingOrderCreated() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("NEW-SPO-REF");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(101L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(100L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        shippingOrderFacade.create(expected);
        
        em.clear();
        
        ShippingOrder actual = em.getReference(ShippingOrder.class, expected.getId());
        actual.getId(); // If no exception is thrown, then the create was successful.
        Assert.assertEquals(ShippingOrderStatus.PENDING, actual.getStatus());
        Assert.assertEquals(expected.getDetails().size(), actual.getDetails().size());
    }
    
    @Test(expected = DuplicateShippingOrderReferenceNumberException.class)
    public void create_ReferenceNumberAlreadyExists_ThrowDuplicateShippingOrderReferenceNumberException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("SPO-100");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(101L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(100L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        try {
            shippingOrderFacade.create(expected);
        } catch (DuplicateShippingOrderReferenceNumberException e) {
            Assert.assertEquals(expected.getReferenceNumber(), e.getReferenceNumber());
            throw e;
        }
    }
    
    @Test(expected = DuplicateShippingOrderReferenceNumberException.class)
    public void edit_ReferenceNumberAlreadyExists_ThrowDuplicateShippingOrderReferenceNumberException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 102L);
        expected.setReferenceNumber("SPO-101");
        
        try {
            shippingOrderFacade.edit(expected);
        } catch (DuplicateShippingOrderReferenceNumberException e) {
            Assert.assertEquals(expected.getReferenceNumber(), e.getReferenceNumber());
            throw e;
        }
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void create_SourceLocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("SPO-SOURCE-LOC-MIS");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(5000L));
        expected.setTargetLocation(new Location(101L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(100L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void create_TargetLocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("SPO-TARGET-LOC-MIS");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(5000L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(100L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void edit_SourceLocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 103L);
        expected.setSourceLocation(new Location(5000L));
        
        shippingOrderFacade.edit(expected);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void edit_TargetLocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 103L);
        expected.setTargetLocation(new Location(5000L));
        
        shippingOrderFacade.edit(expected);
    }
    
    @Test(expected = ShippingOrderLocationException.class)
    public void create_SourceAndTargetLocationsAreEqual_ThrowShippingOrderLocationException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("NEW-SPO-SAM-LOC");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(100L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(100L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        try {
            shippingOrderFacade.create(expected);
        } catch (ShippingOrderLocationException e) {
            Assert.assertEquals(expected.getSourceLocation().getId(), e.getLocationId());
            Assert.assertEquals(expected.getTargetLocation().getId(), e.getLocationId());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderLocationException.class)
    public void edit_SourceAndTargetLocationsAreEqual_ThrowShippingOrderLocationException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 103L);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(100L));
        
        try {
            shippingOrderFacade.edit(expected);
        } catch (ShippingOrderLocationException e) {
            Assert.assertEquals(expected.getSourceLocation().getId(), e.getLocationId());
            Assert.assertEquals(expected.getTargetLocation().getId(), e.getLocationId());
            throw e;
        }
    }
    
    @Test
    public void approve_ShippingOrderIsPending_ShippingOrderApproved() throws Exception {
        Long id = 104L;
        
        shippingOrderFacade.approve(id);
        
        em.clear();
        ShippingOrder actual = em.getReference(ShippingOrder.class, id);
        Assert.assertEquals(ShippingOrderStatus.APPROVED, actual.getStatus());
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void approve_ShippingOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        shippingOrderFacade.approve(5000L);
    }
    
    @Test
    public void reject_ShippingOrderIsPending_ShippingOrderRejected() throws Exception {
        Long id = 105L;
        
        shippingOrderFacade.reject(id);
        
        em.clear();
        ShippingOrder actual = em.getReference(ShippingOrder.class, id);
        Assert.assertEquals(ShippingOrderStatus.REJECTED, actual.getStatus());
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void reject_ShippingOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        shippingOrderFacade.reject(5000L);
    }
    
    @Test
    public void transit_ShippingOrderIsApproved_ShippingOrderInTransit() throws Exception {
        Long shippingOrderId = 106L;
        Long locationId = 102L;
        
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);
        
        ShippingOrder shippingOrder = em.getReference(ShippingOrder.class, shippingOrderId);
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        
        em.clear();
        
        shippingOrderFacade.transit(shippingOrderId);
        
        ShippingOrder actual = em.getReference(ShippingOrder.class, shippingOrderId);
        Assert.assertEquals(ShippingOrderStatus.IN_TRANSIT, actual.getStatus());
        
        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);
        
        int matches = 0;
        for (ProductInventory pib : inventoryBefore) {
            for (ProductInventory pia : inventoryAfter) {
                if (pib.getId().getProductId().equals(pia.getId().getProductId())) {
                    Short shippedQuantity = 0;
                    for (ShippingOrderDetail detail : details) {
                        if (detail.getProduct().getId().equals(pia.getId().getProductId())) {
                            shippedQuantity = (short) (shippedQuantity + detail.getShippedQuantity());
                        }
                    }
                    if (pib.getQuantity() - shippedQuantity == pia.getQuantity()) {
                        matches++;
                    }
                    break;
                }
            }
        }
        
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryBefore.size());
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void transit_ShippingOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        shippingOrderFacade.transit(5000L);
    }
    
    @Test
    public void restitute_ShippingOrderIsApproved_ShippingOrderRestituted() throws Exception {
        Long shippingOrderId = 107L;
        Long locationId = 104L;
        
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);
        ShippingOrder shippingOrder = em.getReference(ShippingOrder.class, shippingOrderId);
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        
        em.clear();
        
        shippingOrderFacade.restitute(shippingOrderId);
        
        ShippingOrder actual = em.getReference(ShippingOrder.class, shippingOrderId);
        Assert.assertEquals(ShippingOrderStatus.RESTITUTED, actual.getStatus());
        
        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);
        
        int matches = 0;
        for (ProductInventory pib : inventoryBefore) {
            for (ProductInventory pia : inventoryAfter) {
                if (pib.getId().getProductId().equals(pia.getId().getProductId())) {
                    Short shippedQuantity = 0;
                    for (ShippingOrderDetail detail : details) {
                        if (detail.getProduct().getId().equals(pia.getId().getProductId())) {
                            shippedQuantity = (short) (shippedQuantity + detail.getShippedQuantity());
                        }
                    }
                    if (pib.getQuantity() + shippedQuantity == pia.getQuantity()) {
                        matches++;
                    }
                    break;
                }
            }
        }
        
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryBefore.size());
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void restitute_ShippingOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        shippingOrderFacade.restitute(5000L);
        
    }
    
    @Test
    public void deliver_ShippingOrderIsPending_ShippingOrderDelivered() throws Exception {
        Long shippingOrderId = 108L;
        Long locationId = 107L;
        
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);
        
        ShippingOrder shippingOrder = em.getReference(ShippingOrder.class, shippingOrderId);
        List<ShippingOrderDetail> details = shippingOrder.getDetails();
        
        em.clear();
        
        Map<Long, Short> productCount = new HashMap<>();
        productCount.put(100L, (short) 1400);
        shippingOrderFacade.deliver(shippingOrderId, productCount);
        
        ShippingOrder actual = em.getReference(ShippingOrder.class, shippingOrderId);
        Assert.assertEquals(ShippingOrderStatus.DELIVERED, actual.getStatus());
        
        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);
        
        int matches = 0;
        
        Map<Long, Short> ivb = new HashMap<>();
        for (ShippingOrderDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (ivb.get(productId) + detail.getReceivedQuantity() == pia.getQuantity() && detail.getShippedQuantity() == detail.getReceivedQuantity() + detail.getRejectedQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }
    
    @Test
    public void remove_ShippingOrderExists_ShippingOrderDeleted() throws Exception {
        final ShippingOrder shippingOrder = new ShippingOrder(109L);
        boolean deleted = false;
        
        shippingOrderFacade.remove(shippingOrder);
        
        try {
            em.getReference(ShippingOrder.class, shippingOrder.getId());
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void remove_ShippingOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final ShippingOrder shippingOrder = new ShippingOrder(5000L);
        shippingOrderFacade.remove(shippingOrder);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void create_ShipMethodDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("SPO-SHIP_METHOD-MIS");
        expected.setShipMethod(new ShipMethod(5000L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(100L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(100L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void edit_ShipMethodDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 110L);
        expected.setShipMethod(new ShipMethod(5000L));
        
        shippingOrderFacade.edit(expected);
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void edit_ShippingOrderIsApproved_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 111L);
        
        try {
            shippingOrderFacade.edit(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.APPROVED, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void edit_ShippingOrderIsRejected_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 112L);
        
        try {
            shippingOrderFacade.edit(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.REJECTED, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void edit_ShippingOrderIsInTransit_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 113L);
        
        try {
            shippingOrderFacade.edit(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.IN_TRANSIT, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void edit_ShippingOrderIsDelivered_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 114L);
        
        try {
            shippingOrderFacade.edit(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.DELIVERED, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void remove_ShippingOrderIsApproved_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 111L);
        
        try {
            shippingOrderFacade.remove(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.APPROVED, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void remove_ShippingOrderIsRejected_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 112L);
        
        try {
            shippingOrderFacade.remove(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.REJECTED, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void remove_ShippingOrderIsInTransit_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 113L);
        
        try {
            shippingOrderFacade.remove(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.IN_TRANSIT, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderReadOnlyException.class)
    public void remove_ShippingOrderIsDelivered_ThrowShippingOrderReadOnlyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 114L);
        
        try {
            shippingOrderFacade.remove(expected);
        } catch (ShippingOrderReadOnlyException e) {
            Assert.assertEquals(ShippingOrderStatus.DELIVERED, e.getStatus());
            throw e;
        }
    }
    
    @Test(expected = ShippingOrderDetailsNullOrEmptyException.class)
    public void create_DetailsIsNull_ThrowShippingOrderDetailsNullOrEmptyException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("NEW-SPO-DETAILS-NULL");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(101L));
        
        expected.setDetails(null);
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = ShippingOrderDetailsNullOrEmptyException.class)
    public void create_DetailsIsEmpty_ThrowShippingOrderDetailsNullOrEmptyException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("NEW-SPO-DETAILS-EMPTY");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(101L));
        
        expected.setDetails(new ArrayList<ShippingOrderDetail>());
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = ShippingOrderDetailsNullOrEmptyException.class)
    public void create_TheOnlyDetailHasZeroShippedQuantity_ThrowShippingOrderDetailsNullOrEmptyException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("NEW-SPO-ZERO-QTY-DETAIL");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        
        ShippingOrderDetail detail = new ShippingOrderDetail();
        detail.setShippedQuantity((short) 0);
        detail.setProduct(new Product(100L));
        
        details.add(detail);
        expected.setDetails(details);
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = ShippingOrderDetailsNullOrEmptyException.class)
    public void edit_DetailsIsNull_ThrowShippingOrderDetailsNullOrEmptyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 115L);
        expected.setDetails(null);
        
        shippingOrderFacade.edit(expected);
    }

    
    @Test(expected = ShippingOrderDetailsNullOrEmptyException.class)
    public void edit_DetailsIsEmpty_ThrowShippingOrderDetailsNullOrEmptyException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 115L);
        expected.getDetails().clear();
        
        shippingOrderFacade.edit(expected);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void create_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();
        
        ShippingOrder expected = new ShippingOrder();
        expected.setReferenceNumber("NEW-SPO-PRODUCT-MISSING");
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setSourceLocation(new Location(100L));
        expected.setTargetLocation(new Location(101L));
        
        ShippingOrderDetail detail1 = new ShippingOrderDetail();
        detail1.setShippedQuantity((short) 2500);
        detail1.setProduct(new Product(5000L));
        
        ShippingOrderDetail detail2 = new ShippingOrderDetail();
        detail2.setShippedQuantity((short) 3000);
        detail2.setProduct(new Product(101L));
        
        List<ShippingOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);
        
        expected.setDetails(details);
        
        shippingOrderFacade.create(expected);
    }
    
    @Test(expected = NonexistentEntityException.class)
    public void edit_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        ShippingOrder expected = em.getReference(ShippingOrder.class, 116L);
        
        ShippingOrderDetail detail = new ShippingOrderDetail();
        detail.setShippedQuantity((short) 3000);
        detail.setProduct(new Product(5000L));
        
        expected.getDetails().add(detail);
        
        shippingOrderFacade.edit(expected);
    }
}
