/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.PurchaseOrder;
import org.optimum.stock.management.core.entities.PurchaseOrderDetail;
import org.optimum.stock.management.core.entities.PurchaseOrderStatus;
import org.optimum.stock.management.core.entities.ShipMethod;
import org.optimum.stock.management.core.entities.Vendor;
import org.optimum.stock.management.core.exceptions.DuplicatePurchaseOrderReferenceNumberException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderDetailsNullOrEmptyException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderStatusTransitionException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderReadOnlyException;
import org.optimum.stock.management.core.exceptions.PurchaseOrderVendorException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class PurchaseOrderFacadeTest {

    @EJB
    private PurchaseOrderFacade purchaseOrderFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    @EJB
    private InventoryManager inventoryManager;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/PurchaseOrderFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void create_PurchaseOrderIsValid_PurchaseOrderCreated() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("NEW-PO-REF");
        expected.setVendor(new Vendor(100L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        PurchaseOrderDetail detail1 = new PurchaseOrderDetail();
        detail1.setOrderedQuantity((short) 2500);
        detail1.setUnitPrice(10D);
        detail1.setProduct(new Product(100L));
        detail1.setDueDate(now);

        PurchaseOrderDetail detail2 = new PurchaseOrderDetail();
        detail2.setOrderedQuantity((short) 3000);
        detail2.setUnitPrice(25D);
        detail2.setProduct(new Product(101L));
        detail2.setDueDate(now);

        List<PurchaseOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        purchaseOrderFacade.create(expected);

        em.clear();

        PurchaseOrder actual = em.getReference(PurchaseOrder.class, expected.getId());
        actual.getId(); // If no exception is thrown, then the create was successful.
        Assert.assertEquals(PurchaseOrderStatus.PENDING, actual.getStatus());
        Assert.assertEquals(expected.getDetails().size(), actual.getDetails().size());
    }

    @Test(expected = DuplicatePurchaseOrderReferenceNumberException.class)
    public void create_ReferenceNumberAlreadyExists_ThrowDuplicatePurchaseOrderReferenceNumberException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("PO-100");
        expected.setVendor(new Vendor(100L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        PurchaseOrderDetail detail1 = new PurchaseOrderDetail();
        detail1.setOrderedQuantity((short) 2500);
        detail1.setUnitPrice(10D);
        detail1.setProduct(new Product(100L));
        detail1.setDueDate(now);

        PurchaseOrderDetail detail2 = new PurchaseOrderDetail();
        detail2.setOrderedQuantity((short) 3000);
        detail2.setUnitPrice(25D);
        detail2.setProduct(new Product(101L));
        detail2.setDueDate(now);

        List<PurchaseOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        try {
            purchaseOrderFacade.create(expected);
        } catch (DuplicatePurchaseOrderReferenceNumberException e) {
            Assert.assertEquals(expected.getReferenceNumber(), e.getReferenceNumber());
            throw e;
        }
    }

    @Test(expected = DuplicatePurchaseOrderReferenceNumberException.class)
    public void edit_ReferenceNumberAlreadyExists_ThrowDuplicatePurchaseOrderReferenceNumberException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 102L);
        expected.setReferenceNumber("PO-101");

        try {
            purchaseOrderFacade.edit(expected);
        } catch (DuplicatePurchaseOrderReferenceNumberException e) {
            Assert.assertEquals(expected.getReferenceNumber(), e.getReferenceNumber());
            throw e;
        }
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_VendorDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("PO-5000");
        expected.setVendor(new Vendor(5000L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        PurchaseOrderDetail detail1 = new PurchaseOrderDetail();
        detail1.setOrderedQuantity((short) 2500);
        detail1.setUnitPrice(10D);
        detail1.setProduct(new Product(100L));
        detail1.setDueDate(now);

        PurchaseOrderDetail detail2 = new PurchaseOrderDetail();
        detail2.setOrderedQuantity((short) 3000);
        detail2.setUnitPrice(25D);
        detail2.setProduct(new Product(101L));
        detail2.setDueDate(now);

        List<PurchaseOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        purchaseOrderFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_VendorDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 103L);
        expected.setVendor(new Vendor(5000L));

        purchaseOrderFacade.edit(expected);
    }

    @Test(expected = PurchaseOrderVendorException.class)
    public void create_VendorInactiveExist_ThrowPurchaseOrderVendorException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("PO-VDR-INA-101");
        expected.setVendor(new Vendor(101L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        PurchaseOrderDetail detail1 = new PurchaseOrderDetail();
        detail1.setOrderedQuantity((short) 2500);
        detail1.setUnitPrice(10D);
        detail1.setProduct(new Product(100L));
        detail1.setDueDate(now);

        PurchaseOrderDetail detail2 = new PurchaseOrderDetail();
        detail2.setOrderedQuantity((short) 3000);
        detail2.setUnitPrice(25D);
        detail2.setProduct(new Product(101L));
        detail2.setDueDate(now);

        List<PurchaseOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        purchaseOrderFacade.create(expected);
    }

    @Test(expected = PurchaseOrderVendorException.class)
    public void edit_VendorInactiveExist_ThrowPurchaseOrderVendorException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 104L);
        expected.setVendor(new Vendor(101L));

        purchaseOrderFacade.edit(expected);
    }

    @Test
    public void approve_PurchaseOrderIsPending_PurchaseOrderApproved() throws Exception {
        Long id = 105L;

        purchaseOrderFacade.approve(id);

        em.clear();
        PurchaseOrder actual = em.getReference(PurchaseOrder.class, id);
        Assert.assertEquals(PurchaseOrderStatus.APPROVED, actual.getStatus());
    }

    @Test(expected = NonexistentEntityException.class)
    public void approve_PurchaseOrderDoesNotExist_ThrowNonexistentEntityExceptionException() throws Exception {
        purchaseOrderFacade.approve(5000L);
    }

    @Test
    public void reject_PurchaseOrderIsPending_PurchaseOrderRejected() throws Exception {
        Long id = 106L;

        purchaseOrderFacade.reject(id);

        em.clear();
        PurchaseOrder actual = em.getReference(PurchaseOrder.class, id);
        Assert.assertEquals(PurchaseOrderStatus.REJECTED, actual.getStatus());
    }

    @Test(expected = NonexistentEntityException.class)
    public void reject_PurchaseOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        purchaseOrderFacade.reject(5000L);
    }

    @Test
    public void complete_PurchaseOrderIsApproved_PurchaseOrderComplete() throws Exception {
        Long purchaseOrderId = 107L;
        Long locationId = 100L;

        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        PurchaseOrder purchaseOrder = em.getReference(PurchaseOrder.class, purchaseOrderId);
        List<PurchaseOrderDetail> details = purchaseOrder.getDetails();

        em.clear();

        Map<Long, Short> productCount = new HashMap<>();
        productCount.put(100L, (short) 1000);
        productCount.put(102L, (short) 500);
        purchaseOrderFacade.complete(purchaseOrderId, locationId, productCount);

        PurchaseOrder actual = em.getReference(PurchaseOrder.class, purchaseOrderId);
        Assert.assertEquals(PurchaseOrderStatus.COMPLETE, actual.getStatus());

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();
        for (PurchaseOrderDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (ivb.get(productId) + detail.getReceivedQuantity() == pia.getQuantity() && detail.getOrderedQuantity() == detail.getReceivedQuantity() + detail.getRejectedQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test(expected = NonexistentEntityException.class)
    public void complete_PurchaseOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Long purchaseOrderId = 5000L;

        Map<Long, Short> productCount = new HashMap<>();
        productCount.put(100L, (short) 1000);
        purchaseOrderFacade.complete(purchaseOrderId, 100L, productCount);
    }

    @Test(expected = PurchaseOrderStatusTransitionException.class)
    public void complete_PurchaseOrderIsNotApproved_ThrowPurchaseOrderStatusTransitionException() throws Exception {
        Long id = 108L;

        try {
            Map<Long, Short> productCount = new HashMap<>();
            productCount.put(100L, (short) 1000);
            purchaseOrderFacade.complete(id, 100L, productCount);
        } catch (PurchaseOrderStatusTransitionException e) {
            Assert.assertEquals(PurchaseOrderStatus.PENDING, e.getSourceStatus());
            Assert.assertEquals(PurchaseOrderStatus.COMPLETE, e.getTargetStatus());
            throw e;
        }
    }

    @Test(expected = NonexistentEntityException.class)
    public void complete_LocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Long locationId = 5000L;
        Long purchaseOrderId = 109L;

        Map<Long, Short> productCount = new HashMap<>();
        productCount.put(100L, (short) 1000);
        purchaseOrderFacade.complete(purchaseOrderId, locationId, productCount);
    }

    @Test
    public void remove_PurchaseOrderExists_PurchaseOrderDeleted() throws Exception {
        final PurchaseOrder purchaseOrder = new PurchaseOrder(110L);
        boolean deleted = false;

        purchaseOrderFacade.remove(purchaseOrder);

        try {
            em.getReference(PurchaseOrder.class, purchaseOrder.getId());
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_PurchaseOrderDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final PurchaseOrder purchaseOrder = new PurchaseOrder(5000L);
        purchaseOrderFacade.remove(purchaseOrder);
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_ShipMethodDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("PO-SHM-MIS");
        expected.setVendor(new Vendor(100L));
        expected.setShipMethod(new ShipMethod(5000L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        PurchaseOrderDetail detail1 = new PurchaseOrderDetail();
        detail1.setOrderedQuantity((short) 2500);
        detail1.setUnitPrice(10D);
        detail1.setProduct(new Product(100L));
        detail1.setDueDate(now);

        PurchaseOrderDetail detail2 = new PurchaseOrderDetail();
        detail2.setOrderedQuantity((short) 3000);
        detail2.setUnitPrice(25D);
        detail2.setProduct(new Product(101L));
        detail2.setDueDate(now);

        List<PurchaseOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        purchaseOrderFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_ShipMethodDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 111L);
        expected.setShipMethod(new ShipMethod(5000L));

        purchaseOrderFacade.edit(expected);
    }

    @Test(expected = PurchaseOrderReadOnlyException.class)
    public void edit_PurchaseOrderIsApproved_ThrowPurchaseOrderReadOnlyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 112L);

        try {
            purchaseOrderFacade.edit(expected);
        } catch (PurchaseOrderReadOnlyException e) {
            Assert.assertEquals(PurchaseOrderStatus.APPROVED, e.getStatus());
            throw e;
        }
    }

    @Test(expected = PurchaseOrderReadOnlyException.class)
    public void edit_PurchaseOrderIsRejected_ThrowPurchaseOrderReadOnlyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 113L);

        try {
            purchaseOrderFacade.edit(expected);
        } catch (PurchaseOrderReadOnlyException e) {
            Assert.assertEquals(PurchaseOrderStatus.REJECTED, e.getStatus());
            throw e;
        }
    }

    @Test(expected = PurchaseOrderReadOnlyException.class)
    public void edit_PurchaseOrderIsComplete_ThrowPurchaseOrderReadOnlyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 114L);

        try {
            purchaseOrderFacade.edit(expected);
        } catch (PurchaseOrderReadOnlyException e) {
            Assert.assertEquals(PurchaseOrderStatus.COMPLETE, e.getStatus());
            throw e;
        }
    }

    @Test(expected = PurchaseOrderReadOnlyException.class)
    public void remove_PurchaseOrderIsApproved_ThrowPurchaseOrderReadOnlyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 112L);

        try {
            purchaseOrderFacade.remove(expected);
        } catch (PurchaseOrderReadOnlyException e) {
            Assert.assertEquals(PurchaseOrderStatus.APPROVED, e.getStatus());
            throw e;
        }
    }

    @Test(expected = PurchaseOrderReadOnlyException.class)
    public void remove_PurchaseOrderIsRejected_ThrowPurchaseOrderReadOnlyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 113L);

        try {
            purchaseOrderFacade.remove(expected);
        } catch (PurchaseOrderReadOnlyException e) {
            Assert.assertEquals(PurchaseOrderStatus.REJECTED, e.getStatus());
            throw e;
        }
    }

    @Test(expected = PurchaseOrderReadOnlyException.class)
    public void remove_PurchaseOrderIsComplete_ThrowPurchaseOrderReadOnlyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 114L);

        try {
            purchaseOrderFacade.remove(expected);
        } catch (PurchaseOrderReadOnlyException e) {
            Assert.assertEquals(PurchaseOrderStatus.COMPLETE, e.getStatus());
            throw e;
        }
    }

    @Test(expected = PurchaseOrderDetailsNullOrEmptyException.class)
    public void create_DetailsIsNull_ThrowPurchaseOrderDetailsNullOrEmptyException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("NEW-PO-DETAILS-NULL");
        expected.setVendor(new Vendor(100L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        expected.setDetails(null);
        purchaseOrderFacade.create(expected);

        em.clear();
    }

    @Test(expected = PurchaseOrderDetailsNullOrEmptyException.class)
    public void create_DetailsIsEmpty_ThrowPurchaseOrderDetailsNullOrEmptyException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("NEW-PO-DETAILS-EMPTY");
        expected.setVendor(new Vendor(100L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        expected.setDetails(new ArrayList<PurchaseOrderDetail>());
        purchaseOrderFacade.create(expected);

        em.clear();
    }

    @Test(expected = PurchaseOrderDetailsNullOrEmptyException.class)
    public void edit_DetailsIsNull_ThrowPurchaseOrderDetailsNullOrEmptyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 115L);
        expected.setDetails(null);

        purchaseOrderFacade.edit(expected);
    }

    @Test(expected = PurchaseOrderDetailsNullOrEmptyException.class)
    public void edit_DetailsIsEmpty_ThrowPurchaseOrderDetailsNullOrEmptyException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 115L);
        expected.getDetails().clear();

        purchaseOrderFacade.edit(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        Date now = new Date();

        PurchaseOrder expected = new PurchaseOrder();
        expected.setReferenceNumber("NEW-PO-PRODUCT-MISSING");
        expected.setVendor(new Vendor(100L));
        expected.setShipMethod(new ShipMethod(100L));
        expected.setShipDate(now);
        expected.setCreationDate(now);
        expected.setLastUpdateDate(now);
        expected.setFreight(150D);
        expected.setTaxAmount(5D);

        PurchaseOrderDetail detail1 = new PurchaseOrderDetail();
        detail1.setOrderedQuantity((short) 2500);
        detail1.setUnitPrice(10D);
        detail1.setProduct(new Product(5000L));
        detail1.setDueDate(now);

        PurchaseOrderDetail detail2 = new PurchaseOrderDetail();
        detail2.setOrderedQuantity((short) 3000);
        detail2.setUnitPrice(25D);
        detail2.setProduct(new Product(101L));
        detail2.setDueDate(now);

        List<PurchaseOrderDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        purchaseOrderFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        PurchaseOrder expected = em.getReference(PurchaseOrder.class, 116L);
        PurchaseOrderDetail detail = new PurchaseOrderDetail();
        detail.setOrderedQuantity((short) 3000);
        detail.setUnitPrice(25D);
        detail.setProduct(new Product(5000L));
        detail.setDueDate(new Date());
        expected.getDetails().add(detail);

        purchaseOrderFacade.edit(expected);
    }
}
