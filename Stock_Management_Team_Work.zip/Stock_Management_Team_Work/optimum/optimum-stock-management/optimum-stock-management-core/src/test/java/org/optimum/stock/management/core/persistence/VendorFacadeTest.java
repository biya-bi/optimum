/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Vendor;
import org.optimum.stock.management.core.exceptions.DuplicateVendorAccountNumberException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class VendorFacadeTest {

    @EJB
    private VendorFacade vendorFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/VendorFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void create_VendorIsValid_VendorCreated() throws Exception {
        Vendor expected = new Vendor("VDR-NEW-ACC1", "New Vendor", true, "www.optimum.org");

        vendorFacade.create(expected);

        Vendor actual = em.getReference(Vendor.class, expected.getId());
        actual.getId();  // If no exception is thrown, then the create was successful.
    }

    @Test(expected = DuplicateVendorAccountNumberException.class)
    public void create_AccountNumberAlreadyExists_ThrowDuplicateVendorAccountNumberException() throws Exception {
        Vendor vendor = new Vendor("VDR-100", "New Duplicate Account Vendor", true, "www.optimum.org");

        try {
            vendorFacade.create(vendor);
        } catch (DuplicateVendorAccountNumberException e) {
            Assert.assertEquals(vendor.getAccountNumber(), e.getAccountNumber());
            throw e;
        }
    }

    @Test
    public void remove_VendorExists_VendorDeleted() throws Exception {
        final Vendor vendor = new Vendor(101L);
        boolean deleted = false;

        vendorFacade.remove(vendor);

        try {
            em.getReference(Vendor.class, vendor.getId());
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_VendorDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final Vendor vendor = new Vendor(5000L);
        vendorFacade.remove(vendor);
    }

    @Test
    public void edit_VendorIsValid_VendorEdited() throws Exception {
        Vendor expected = em.getReference(Vendor.class, 102L);
        expected.setName(expected.getName() + " Renamed");

        em.clear();

        vendorFacade.edit(expected);

        Vendor actual = em.getReference(Vendor.class, expected.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
    }

    @Test(expected = DuplicateVendorAccountNumberException.class)
    public void edit_VendorAccountNumberAlreadyExists_ThrowDuplicateVendorAccountNumberException() throws Exception {
        Vendor vendor = em.getReference(Vendor.class, 104L);
        vendor.setAccountNumber("VDR-103");

        try {
            vendorFacade.edit(vendor);
        } catch (DuplicateVendorAccountNumberException e) {
            Assert.assertEquals(vendor.getAccountNumber(), e.getAccountNumber());
            throw e;
        }
    }
}
