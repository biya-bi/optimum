/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ProductIssue;
import org.optimum.stock.management.core.entities.ProductIssueDetail;
import org.optimum.stock.management.core.exceptions.DuplicateProductIssueReferenceNumberException;
import org.optimum.stock.management.core.exceptions.InsufficientInventoryException;
import org.optimum.stock.management.core.exceptions.ProductIssueDetailsNullOrEmptyException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class ProductIssueFacadeTest {

    @EJB
    private ProductIssueFacade productIssueFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    @EJB
    private InventoryManager inventoryManager;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/ProductIssueFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        //DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void create_ProductIssueIsValid_ProductIssueCreated() throws Exception {
        long locationId = 100L;

        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("NEW-PI-1");
        expected.setLocation(new Location(locationId));

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity((short) 75);
        detail1.setProduct(new Product(100L));

        List<ProductIssueDetail> details = new ArrayList<>();
        details.add(detail1);

        expected.setDetails(details);

        Map<Long, Short> productQuantities = new HashMap<>();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!productQuantities.containsKey(productId)) {
                productQuantities.put(productId, detail.getQuantity());
            }
            else {
                productQuantities.replace(productId, (short) (productQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productIssueFacade.create(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (productQuantities.containsKey(productId)) {
                        if (ivb.get(productId) - productQuantities.get(productId) == pia.getQuantity()) {
                            matches++;
                            productQuantities.remove(productId);
                        }
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test(expected = ProductIssueDetailsNullOrEmptyException.class)
    public void create_DetailsIsNull_ThrowProductIssueDetailsNullOrEmptyException() throws Exception {
        long locationId = 100L;

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("NEW-PI-DETAILS-NULL");
        expected.setLocation(new Location(locationId));

        productIssueFacade.create(expected);
    }

    @Test(expected = ProductIssueDetailsNullOrEmptyException.class)
    public void create_DetailsIsEmpty_ThrowProductIssueDetailsNullOrEmptyException() throws Exception {
        long locationId = 100L;

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("NEW-PI-DETAILS-EMPTY");
        expected.setLocation(new Location(locationId));
        expected.setDetails(new ArrayList<ProductIssueDetail>());

        productIssueFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_LocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        long locationId = 5000L;

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("NEW-PI-LOC-MISSING");
        expected.setLocation(new Location(locationId));

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity((short) 1800);
        detail1.setProduct(new Product(100L));

        ProductIssueDetail detail2 = new ProductIssueDetail();
        detail2.setQuantity((short) 1950);
        detail2.setProduct(new Product(101L));

        List<ProductIssueDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        productIssueFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        long locationId = 100L;

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("NEW-PI-PRODUCT-MISSING");
        expected.setLocation(new Location(locationId));

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity((short) 500);
        detail1.setProduct(new Product(5000L));

        ProductIssueDetail detail2 = new ProductIssueDetail();
        detail2.setQuantity((short) 600);
        detail2.setProduct(new Product(101L));

        List<ProductIssueDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        productIssueFacade.create(expected);
    }

    @Test
    public void edit_ProductIssueIsValid_ProductIssueEdited() throws Exception {
        long locationId = 101L;
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductIssue expected = em.getReference(ProductIssue.class, 100L);

        Map<Long, Short> oldProductQuantities = new HashMap<>();

        List<ProductIssueDetail> details = expected.getDetails();

        for (ProductIssueDetail detail : details) {
            oldProductQuantities.put(detail.getProduct().getId(), detail.getQuantity());
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 500);
            }
            else if (detail.getDetailId() == 2) {
                detail.setQuantity((short) 400);
            }
        }

        productIssueFacade.edit(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();
        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (ivb.get(productId) + oldProductQuantities.get(productId) - detail.getQuantity() == pia.getQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test
    public void edit_NewDetailsAdded_ProductIssueEdited() throws Exception {
        long locationId = 102L;
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductIssue expected = em.getReference(ProductIssue.class, 101L);

        Map<Long, Short> oldProductQuantities = new HashMap<>();
        Map<Long, Short> newProductQuantities = new HashMap<>();

        List<ProductIssueDetail> details = expected.getDetails();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!oldProductQuantities.containsKey(productId)) {
                oldProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                oldProductQuantities.replace(productId, (short) (oldProductQuantities.get(productId) + detail.getQuantity()));
            }
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 425);
            }
            else if (detail.getDetailId() == 2) {
                detail.setQuantity((short) 129);
            }
        }

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setDetailId(0);
        detail1.setQuantity((short) 500);
        detail1.setProduct(new Product(100L));
        details.add(detail1);

        ProductIssueDetail detail2 = new ProductIssueDetail();
        detail2.setDetailId(0);
        detail2.setQuantity((short) 600);
        detail2.setProduct(new Product(102L));
        details.add(detail2);

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!newProductQuantities.containsKey(productId)) {
                newProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                newProductQuantities.replace(productId, (short) (newProductQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productIssueFacade.edit(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();

            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }

            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {

                    short newQuantity = newProductQuantities.containsKey(productId) ? newProductQuantities.get(productId) : 0;
                    short oldQuantity = oldProductQuantities.containsKey(productId) ? oldProductQuantities.get(productId) : 0;

                    if (ivb.get(productId) + oldQuantity - newQuantity == pia.getQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test(expected = ProductIssueDetailsNullOrEmptyException.class)
    public void edit_DetailsIsNull_ThrowProductIssueDetailsNullOrEmptyException() throws Exception {
        ProductIssue expected = em.getReference(ProductIssue.class, 102L);

        expected.setDetails(null);

        productIssueFacade.edit(expected);
    }

    @Test(expected = ProductIssueDetailsNullOrEmptyException.class)
    public void edit_DetailsIsEmpty_ThrowProductIssueDetailsNullOrEmptyException() throws Exception {
        ProductIssue expected = em.getReference(ProductIssue.class, 102L);

        expected.getDetails().clear();

        productIssueFacade.edit(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_LocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        ProductIssue expected = em.getReference(ProductIssue.class, 103L);
        expected.setLocation(new Location(5000L));

        productIssueFacade.edit(expected);
    }

    @Test(expected = InsufficientInventoryException.class)
    public void edit_NewQuantityGreaterThanInventoryQuantity_ThrowInsufficientInventoryException() throws Exception {
        Long locationId = 105L;
        Long productIssueId = 104L;
        Short availableQuantity = 2000;
        Short requestedQuantity = 2700;
        Long productId = 100L;

        ProductIssue expected = em.getReference(ProductIssue.class, productIssueId);

        Map<Long, Short> oldProductQuantities = new HashMap<>();

        List<ProductIssueDetail> details = expected.getDetails();

        for (ProductIssueDetail detail : details) {
            oldProductQuantities.put(detail.getProduct().getId(), detail.getQuantity());
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 5000);
            }
        }
        try {
            productIssueFacade.edit(expected);
        } catch (InsufficientInventoryException e) {
            Assert.assertEquals(locationId, e.getLocationId());
            Assert.assertEquals(availableQuantity, e.getAvailableQuantity());
            Assert.assertEquals(requestedQuantity, e.getRequestedQuantity());
            Assert.assertEquals(productId, e.getProductId());
            throw e;
        }
    }

    @Test(expected = InsufficientInventoryException.class)
    public void edit_NewQuantityNotInInventory_ThrowInsufficientInventoryException() throws Exception {
        Long locationId = 106L;
        Long productIssueId = 105L;
        Short availableQuantity = 0;
        Short requestedQuantity = 400;
        Long productId = 102L;

        ProductIssue expected = em.getReference(ProductIssue.class, productIssueId);

        List<ProductIssueDetail> details = expected.getDetails();

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity(requestedQuantity);
        detail1.setProduct(new Product(productId));
        details.add(detail1);

        try {
            productIssueFacade.edit(expected);
        } catch (InsufficientInventoryException e) {
            Assert.assertEquals(locationId, e.getLocationId());
            Assert.assertEquals(availableQuantity, e.getAvailableQuantity());
            Assert.assertEquals(requestedQuantity, e.getRequestedQuantity());
            Assert.assertEquals(productId, e.getProductId());
            throw e;
        }
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_ProductChangedToNonexistentProduct_ThrowNonexistentEntityException() throws Exception {
        ProductIssue expected = em.getReference(ProductIssue.class, 106L);
        expected.getDetails().get(0).setProduct(new Product(5000L));

        productIssueFacade.edit(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_NonexistentProductAddedInDetails_ThrowNonexistentEntityException() throws Exception {
        ProductIssue expected = em.getReference(ProductIssue.class, 106L);

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity((short) 400);
        detail1.setProduct(new Product(5000L));
        expected.getDetails().add(detail1);

        productIssueFacade.edit(expected);
    }

    @Test
    public void edit_LocationChanged_OldLocationAndNewLocationInventoriesAdjusted() throws Exception {
        long oldLocationId = 108L;
        long newLocationId = 109L;
        List<ProductInventory> oldLocationInventoryBefore = inventoryManager.getProductInventories(oldLocationId);
        List<ProductInventory> newLocationInventoryBefore = inventoryManager.getProductInventories(newLocationId);

        ProductIssue expected = em.getReference(ProductIssue.class, 107L);
        expected.setLocation(new Location(newLocationId));

        Map<Long, Short> oldProductQuantities = new HashMap<>();
        Map<Long, Short> newProductQuantities = new HashMap<>();

        List<ProductIssueDetail> details = expected.getDetails();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!oldProductQuantities.containsKey(productId)) {
                oldProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                oldProductQuantities.replace(productId, (short) (oldProductQuantities.get(productId) + detail.getQuantity()));
            }
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 400);
            }
            else if (detail.getDetailId() == 2) {
                detail.setQuantity((short) 275);
            }
            if (!newProductQuantities.containsKey(productId)) {
                newProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                newProductQuantities.replace(productId, (short) (newProductQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productIssueFacade.edit(expected);

        List<ProductInventory> oldLocationInventoryAfter = inventoryManager.getProductInventories(oldLocationId);
        List<ProductInventory> newLocationInventoryAfter = inventoryManager.getProductInventories(newLocationId);

        int oldLocationInventoryMatches = 0;
        int newLocationInventoryMatches = 0;

        Map<Long, Short> ivb = new HashMap<>();
        Map<Long, Short> ivb1 = new HashMap<>();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            if (!ivb1.containsKey(productId)) {
                ivb1.put(productId, (short) 0);
            }
            for (ProductInventory pib : oldLocationInventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pib : newLocationInventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb1.replace(productId, (short) (ivb1.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : oldLocationInventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (oldProductQuantities.containsKey(productId)) {
                        if (ivb.get(productId) + oldProductQuantities.get(productId) == pia.getQuantity()) {
                            oldLocationInventoryMatches++;
                            oldProductQuantities.remove(productId);
                        }
                    }
                }
            }
            for (ProductInventory pia : newLocationInventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (newProductQuantities.containsKey(productId)) {
                        if (ivb1.get(productId) - newProductQuantities.get(productId) == pia.getQuantity()) {
                            newLocationInventoryMatches++;
                            newProductQuantities.remove(productId);
                        }
                    }
                }
            }
        }
        Assert.assertTrue(oldLocationInventoryMatches > 0);
        Assert.assertEquals(oldLocationInventoryMatches, oldLocationInventoryAfter.size());
        Assert.assertTrue(newLocationInventoryMatches > 0);
        Assert.assertEquals(newLocationInventoryMatches, newLocationInventoryAfter.size());
    }

    @Test
    public void remove_ProductIssueExists_ProductIssueDeletedAndLocationInventoryAdjusted() throws Exception {
        long locationId = 110L;
        long productIssueId = 109L;

        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductIssue expected = em.getReference(ProductIssue.class, productIssueId);

        Map<Long, Short> productQuantities = new HashMap<>();

        List<ProductIssueDetail> details = expected.getDetails();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!productQuantities.containsKey(productId)) {
                productQuantities.put(productId, detail.getQuantity());
            }
            else {
                productQuantities.replace(productId, (short) (productQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productIssueFacade.remove(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();

        for (ProductIssueDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (productQuantities.containsKey(productId)) {
                        if (ivb.get(productId) + productQuantities.get(productId) == pia.getQuantity()) {
                            matches++;
                            productQuantities.remove(productId);
                        }
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());

        em.clear();

        boolean deleted = false;
        try {
            em.getReference(ProductIssue.class, productIssueId);
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_ProductIssueDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final ProductIssue productIssue = new ProductIssue(5000L);
        productIssueFacade.remove(productIssue);
    }

    @Test(expected = InsufficientInventoryException.class)
    public void create_LocationDoesNotHaveSufficientInventory_ThrowInsufficientInventoryException() throws Exception {
        Long locationId = 111L;
        Short availableQuantity = 50;
        Short requestedQuantity = 75;
        Long productId = 100L;

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("NEW-PI-INS-INV");
        expected.setLocation(new Location(locationId));

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity(requestedQuantity);
        detail1.setProduct(new Product(productId));

        List<ProductIssueDetail> details = new ArrayList<>();
        details.add(detail1);

        expected.setDetails(details);

        try {
            productIssueFacade.create(expected);
        } catch (InsufficientInventoryException e) {
            Assert.assertEquals(locationId, e.getLocationId());
            Assert.assertEquals(availableQuantity, e.getAvailableQuantity());
            Assert.assertEquals(requestedQuantity, e.getRequestedQuantity());
            Assert.assertEquals(productId, e.getProductId());
            throw e;
        }
    }

    @Test(expected = DuplicateProductIssueReferenceNumberException.class)
    public void create_ReferenceNumberAlreadyExists_ThrowDuplicateProductIssueReferenceNumberException() throws Exception {
        long locationId = 100L;

        ProductIssue expected = new ProductIssue();
        expected.setReferenceNumber("PI-110");
        expected.setLocation(new Location(locationId));

        ProductIssueDetail detail1 = new ProductIssueDetail();
        detail1.setQuantity((short) 75);
        detail1.setProduct(new Product(100L));

        List<ProductIssueDetail> details = new ArrayList<>();
        details.add(detail1);

        expected.setDetails(details);

        try {
            productIssueFacade.create(expected);
        } catch (DuplicateProductIssueReferenceNumberException e) {
            Assert.assertEquals(expected.getReferenceNumber(), e.getReferenceNumber());
            throw e;
        }
    }
}
