/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.exceptions.DuplicateLocationNameException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class LocationFacadeTest {

    @EJB
    private LocationFacade locationFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/LocationFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void create_LocationIsValid_LocationCreated() throws Exception {
        Location expected = new Location("LOC-NEW-ACC1");

        locationFacade.create(expected);

        Location actual = em.getReference(Location.class, expected.getId());
        actual.getId();  // If no exception is thrown, then the create was successful.
    }

    @Test(expected = DuplicateLocationNameException.class)
    public void create_NameAlreadyExists_ThrowDuplicateLocationNameException() throws Exception {
        Location location = new Location("Location 100");

        try {
            locationFacade.create(location);
        } catch (DuplicateLocationNameException e) {
            Assert.assertEquals(location.getName(), e.getName());
            throw e;
        }
    }

    @Test
    public void remove_LocationExists_LocationDeleted() throws Exception {
        final Location location = new Location(101L);
        boolean deleted = false;

        locationFacade.remove(location);

        try {
            em.getReference(Location.class, location.getId());
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_LocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final Location location = new Location(5000L);
        locationFacade.remove(location);
    }

    @Test
    public void edit_LocationIsValid_LocationEdited() throws Exception {
        Location expected = em.getReference(Location.class, 102L);
        expected.setName(expected.getName() + " Renamed");

        em.clear();

        locationFacade.edit(expected);

        Location actual = em.getReference(Location.class, expected.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
    }

    @Test(expected = DuplicateLocationNameException.class)
    public void edit_NameAlreadyExists_ThrowDuplicateLocationNameException() throws Exception {
        Location location = em.getReference(Location.class, 104L);
        location.setName("Location 103");

        try {
            locationFacade.edit(location);
        } catch (DuplicateLocationNameException e) {
            Assert.assertEquals(location.getName(), e.getName());
            throw e;
        }
    }
}
