/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.exceptions.DuplicateProductNameException;
import org.optimum.stock.management.core.exceptions.DuplicateProductNumberException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class ProductFacadeTest {

    @EJB
    private ProductFacade productFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/ProductFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    /**
     * Test of create method, of class ProductFacade.
     *
     * @throws java.lang.Exception
     */
    @Test
    public void create_ProductIsValid_ProductCreated() throws Exception {
        Date now = new Date();
        Product expected = new Product("PDT-1500", "New Product 1", (short) 1000, (short) 750, (short) 3, "", now, now);

        productFacade.create(expected);

        Product actual = em.getReference(Product.class, expected.getId());
        actual.getId();  // If no exception is thrown, then the create was successful.
    }

    /**
     * Test of create method, of class ProductFacade.
     *
     * @throws java.lang.Exception
     */
    @Test(expected = DuplicateProductNameException.class)
    public void create_ProductNameAlreadyExists_ThrowDuplicateProductNameException() throws Exception {
        Date now = new Date();
        Product product = new Product("PDT-1501", "Sample Product 1", (short) 1000, (short) 750, (short) 3, "", now, now);

        try {
            productFacade.create(product);
        } catch (DuplicateProductNameException e) {
            Assert.assertEquals(product.getName(), e.getName());
            throw e;
        }
    }

    @Test
    public void remove_ProductExists_ProductDeleted() throws Exception {
        // The below product represents Sample Product 2
        final Product product = new Product(101L);
        boolean deleted = false;

        productFacade.remove(product);

        try {
            em.getReference(Product.class, product.getId());
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final Product product = new Product(5000L);
        productFacade.remove(product);
    }

    @Test
    public void edit_ProductIsValid_ProductEdited() throws Exception {
        // Get Sample Product 3
        Product expected = em.getReference(Product.class, 102L);
        expected.setName(expected.getName() + " Renamed");

        em.clear();

        productFacade.edit(expected);

        Product actual = em.getReference(Product.class, expected.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
    }

    @Test(expected = DuplicateProductNameException.class)
    public void edit_ProductNameAlreadyExists_ThrowDuplicateProductNameException() throws Exception {
        // Get  Sample Product 5
        Product product = em.getReference(Product.class, 104L);
        product.setName("Sample Product 4");

        try {
            productFacade.edit(product);
        } catch (DuplicateProductNameException e) {
            Assert.assertEquals(product.getName(), e.getName());
            throw e;
        }
    }

    @Test(expected = DuplicateProductNumberException.class)
    public void create_ProductNumberAlreadyExists_ThrowDuplicateProductNumberException() throws Exception {
        Date now = new Date();
        Product product = new Product("PDT-105", "Product with duplicate number", (short) 1000, (short) 750, (short) 3, "", now, now);

        try {
            productFacade.create(product);
        } catch (DuplicateProductNumberException e) {
            Assert.assertEquals(product.getName(), e.getNumber());
            throw e;
        }
    }

    @Test(expected = DuplicateProductNumberException.class)
    public void edit_ProductNumberAlreadyExists_ThrowDuplicateProductNumberException() throws Exception {
        // Get  Sample Product 8
        Product product = em.getReference(Product.class, 107L);
        product.setNumber("PDT-106");

        try {
            productFacade.edit(product);
        } catch (DuplicateProductNumberException e) {
            Assert.assertEquals(product.getNumber(), e.getNumber());
            throw e;
        }
    }
}
