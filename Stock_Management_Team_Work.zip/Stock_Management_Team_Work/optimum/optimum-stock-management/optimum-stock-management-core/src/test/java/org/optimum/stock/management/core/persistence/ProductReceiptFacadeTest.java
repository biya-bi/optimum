/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.core.persistence;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.optimum.persistence.exceptions.NonexistentEntityException;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.Product;
import org.optimum.stock.management.core.entities.ProductInventory;
import org.optimum.stock.management.core.entities.ProductReceipt;
import org.optimum.stock.management.core.entities.ProductReceiptDetail;
import org.optimum.stock.management.core.exceptions.DuplicateProductReceiptReferenceNumberException;
import org.optimum.stock.management.core.exceptions.InsufficientInventoryException;
import org.optimum.stock.management.core.exceptions.ProductReceiptDetailsNullOrEmptyException;

/**
 *
 * @author Biya-Bi
 */
@RunWith(Arquillian.class)
public class ProductReceiptFacadeTest {

    @EJB
    private ProductReceiptFacade productReceiptFacade;

    @PersistenceContext(unitName = PersistenceSettings.PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    @EJB
    private InventoryManager inventoryManager;

    private static final MySqlDatabase DATABASE = new MySqlDatabase();

    @BeforeClass
    public static void setUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
        DATABASE.execute("src/test/resources/ProductReceiptFacadeTestSetup.sql");
    }

    @AfterClass
    public static void cleanUpClass() throws SQLException, IOException {
        DATABASE.execute("src/test/resources/Cleanup.sql");
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class, "optimum-stock-management.jar")
                .addPackage("org.optimum.stock.management.core.entities")
                .addPackage("org.optimum.stock.management.core.persistence")
                .addAsResource("META-INF/persistence.xml")
                .addAsResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void create_ProductReceiptIsValid_ProductReceiptCreated() throws Exception {
        long locationId = 100L;
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductReceipt expected = new ProductReceipt();
        expected.setReferenceNumber("NEW-PR-1");
        expected.setLocation(new Location(locationId));

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setQuantity((short) 2500);
        detail1.setProduct(new Product(100L));

        ProductReceiptDetail detail2 = new ProductReceiptDetail();
        detail2.setQuantity((short) 3000);
        detail2.setProduct(new Product(101L));

        List<ProductReceiptDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        productReceiptFacade.create(expected);

        ProductReceipt actual = em.getReference(ProductReceipt.class, expected.getId());
        actual.getId();  // If no exception is thrown, then the create was successful.

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();
        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (ivb.get(productId) + detail.getQuantity() == pia.getQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test(expected = ProductReceiptDetailsNullOrEmptyException.class)
    public void create_DetailsIsNull_ThrowProductReceiptDetailsNullOrEmptyException() throws Exception {
        long locationId = 100L;

        ProductReceipt expected = new ProductReceipt();
        expected.setReferenceNumber("NEW-PR-DETAILS-NULL");
        expected.setLocation(new Location(locationId));

        productReceiptFacade.create(expected);
    }

    @Test(expected = ProductReceiptDetailsNullOrEmptyException.class)
    public void create_DetailsIsEmpty_ThrowProductReceiptDetailsNullOrEmptyException() throws Exception {
        long locationId = 100L;

        ProductReceipt expected = new ProductReceipt();
        expected.setReferenceNumber("NEW-PR-DETAILS-EMPTY");
        expected.setLocation(new Location(locationId));
        expected.setDetails(new ArrayList<ProductReceiptDetail>());

        productReceiptFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_LocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        long locationId = 5000L;

        ProductReceipt expected = new ProductReceipt();
        expected.setReferenceNumber("NEW-PR-LOC-MISSING");
        expected.setLocation(new Location(locationId));

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setQuantity((short) 2500);
        detail1.setProduct(new Product(100L));

        ProductReceiptDetail detail2 = new ProductReceiptDetail();
        detail2.setQuantity((short) 3000);
        detail2.setProduct(new Product(101L));

        List<ProductReceiptDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        productReceiptFacade.create(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void create_ProductDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        long locationId = 100L;

        ProductReceipt expected = new ProductReceipt();
        expected.setReferenceNumber("NEW-PR-PRODUCT-MISSING");
        expected.setLocation(new Location(locationId));

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setQuantity((short) 2500);
        detail1.setProduct(new Product(5000L));

        ProductReceiptDetail detail2 = new ProductReceiptDetail();
        detail2.setQuantity((short) 3000);
        detail2.setProduct(new Product(101L));

        List<ProductReceiptDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        productReceiptFacade.create(expected);
    }

    @Test
    public void edit_ProductReceiptIsValid_ProductReceiptEdited() throws Exception {
        long locationId = 101L;
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductReceipt expected = em.getReference(ProductReceipt.class, 101L);

        Map<Long, Short> oldProductQuantities = new HashMap<>();

        List<ProductReceiptDetail> details = expected.getDetails();

        for (ProductReceiptDetail detail : details) {
            oldProductQuantities.put(detail.getProduct().getId(), detail.getQuantity());
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 1500);
            }
            else if (detail.getDetailId() == 2) {
                detail.setQuantity((short) 1750);
            }
        }

        productReceiptFacade.edit(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();
        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (ivb.get(productId) - oldProductQuantities.get(productId) + detail.getQuantity() == pia.getQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test
    public void edit_NewDetailsAdded_ProductReceiptEdited() throws Exception {
        long locationId = 102L;
        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductReceipt expected = em.getReference(ProductReceipt.class, 102L);

        Map<Long, Short> oldProductQuantities = new HashMap<>();
        Map<Long, Short> newProductQuantities = new HashMap<>();

        List<ProductReceiptDetail> details = expected.getDetails();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!oldProductQuantities.containsKey(productId)) {
                oldProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                oldProductQuantities.replace(productId, (short) (oldProductQuantities.get(productId) + detail.getQuantity()));
            }
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 425);
            }
            else if (detail.getDetailId() == 2) {
                detail.setQuantity((short) 129);
            }
        }

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setDetailId(0);
        detail1.setQuantity((short) 500);
        detail1.setProduct(new Product(100L));
        details.add(detail1);

        ProductReceiptDetail detail2 = new ProductReceiptDetail();
        detail2.setDetailId(0);
        detail2.setQuantity((short) 600);
        detail2.setProduct(new Product(102L));
        details.add(detail2);

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!newProductQuantities.containsKey(productId)) {
                newProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                newProductQuantities.replace(productId, (short) (newProductQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productReceiptFacade.edit(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();

            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }

            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {

                    short newQuantity = newProductQuantities.containsKey(productId) ? newProductQuantities.get(productId) : 0;
                    short oldQuantity = oldProductQuantities.containsKey(productId) ? oldProductQuantities.get(productId) : 0;

                    if (ivb.get(productId) - oldQuantity + newQuantity == pia.getQuantity()) {
                        matches++;
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());
    }

    @Test(expected = ProductReceiptDetailsNullOrEmptyException.class)
    public void edit_DetailsIsNull_ThrowProductReceiptDetailsNullOrEmptyException() throws Exception {
        ProductReceipt expected = em.getReference(ProductReceipt.class, 103L);

        expected.setDetails(null);

        productReceiptFacade.edit(expected);
    }

    @Test(expected = ProductReceiptDetailsNullOrEmptyException.class)
    public void edit_DetailsIsEmpty_ThrowProductReceiptDetailsNullOrEmptyException() throws Exception {
        ProductReceipt expected = em.getReference(ProductReceipt.class, 103L);

        expected.getDetails().clear();

        productReceiptFacade.edit(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_LocationDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        ProductReceipt expected = em.getReference(ProductReceipt.class, 104L);
        expected.setLocation(new Location(5000L));

        productReceiptFacade.edit(expected);
    }

    @Test(expected = InsufficientInventoryException.class)
    public void edit_NewQuantityGreaterThanInventoryQuantity_ThrowInsufficientInventoryException() throws Exception {
        Long locationId = 105L;
        Long productReceiptId = 105L;
        Short availableQuantity = 2000;
        Short requestedQuantity = 2200;
        Long productId = 100L;

        ProductReceipt expected = em.getReference(ProductReceipt.class, productReceiptId);

        Map<Long, Short> oldProductQuantities = new HashMap<>();

        List<ProductReceiptDetail> details = expected.getDetails();

        for (ProductReceiptDetail detail : details) {
            oldProductQuantities.put(detail.getProduct().getId(), detail.getQuantity());
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 100);
            }
        }
        try {
            productReceiptFacade.edit(expected);
        } catch (InsufficientInventoryException e) {
            Assert.assertEquals(locationId, e.getLocationId());
            Assert.assertEquals(availableQuantity, e.getAvailableQuantity());
            Assert.assertEquals(requestedQuantity, e.getRequestedQuantity());
            Assert.assertEquals(productId, e.getProductId());
            throw e;
        }
    }

    @Test(expected = InsufficientInventoryException.class)
    public void edit_NewQuantityNotInInventory_ThrowInsufficientInventoryException() throws Exception {
        Long locationId = 106L;
        Long productReceiptId = 106L;
        Short availableQuantity = 0;
        Short requestedQuantity = 400;
        Long productId = 102L;

        ProductReceipt expected = em.getReference(ProductReceipt.class, productReceiptId);

        List<ProductReceiptDetail> details = expected.getDetails();

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setQuantity((short) 2000);
        detail1.setProduct(new Product(productId));
        details.add(detail1);

        try {
            productReceiptFacade.edit(expected);
        } catch (InsufficientInventoryException e) {
            Assert.assertEquals(locationId, e.getLocationId());
            Assert.assertEquals(availableQuantity, e.getAvailableQuantity());
            Assert.assertEquals(requestedQuantity, e.getRequestedQuantity());
            Assert.assertEquals(productId, e.getProductId());
            throw e;
        }
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_ProductChangedToNonexistentProduct_ThrowNonexistentEntityException() throws Exception {
        ProductReceipt expected = em.getReference(ProductReceipt.class, 107L);
        expected.getDetails().get(0).setProduct(new Product(5000L));

        productReceiptFacade.edit(expected);
    }

    @Test(expected = NonexistentEntityException.class)
    public void edit_NonexistentProductAddedInDetails_ThrowNonexistentEntityException() throws Exception {
        ProductReceipt expected = em.getReference(ProductReceipt.class, 107L);

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setQuantity((short) 2000);
        detail1.setProduct(new Product(5000L));
        expected.getDetails().add(detail1);

        productReceiptFacade.edit(expected);
    }

    @Test
    public void edit_LocationChanged_OldLocationAndNewLocationInventoriesAdjusted() throws Exception {
        long oldLocationId = 108L;
        long newLocationId = 109L;
        List<ProductInventory> oldLocationInventoryBefore = inventoryManager.getProductInventories(oldLocationId);
        List<ProductInventory> newLocationInventoryBefore = inventoryManager.getProductInventories(newLocationId);

        ProductReceipt expected = em.getReference(ProductReceipt.class, 108L);
        expected.setLocation(new Location(newLocationId));

        Map<Long, Short> oldProductQuantities = new HashMap<>();
        Map<Long, Short> newProductQuantities = new HashMap<>();

        List<ProductReceiptDetail> details = expected.getDetails();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!oldProductQuantities.containsKey(productId)) {
                oldProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                oldProductQuantities.replace(productId, (short) (oldProductQuantities.get(productId) + detail.getQuantity()));
            }
            if (detail.getDetailId() == 1) {
                detail.setQuantity((short) 400);
            }
            else if (detail.getDetailId() == 2) {
                detail.setQuantity((short) 275);
            }
            if (!newProductQuantities.containsKey(productId)) {
                newProductQuantities.put(productId, detail.getQuantity());
            }
            else {
                newProductQuantities.replace(productId, (short) (newProductQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productReceiptFacade.edit(expected);

        List<ProductInventory> oldLocationInventoryAfter = inventoryManager.getProductInventories(oldLocationId);
        List<ProductInventory> newLocationInventoryAfter = inventoryManager.getProductInventories(newLocationId);

        int oldLocationInventoryMatches = 0;
        int newLocationInventoryMatches = 0;

        Map<Long, Short> ivb = new HashMap<>();
        Map<Long, Short> ivb1 = new HashMap<>();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            if (!ivb1.containsKey(productId)) {
                ivb1.put(productId, (short) 0);
            }
            for (ProductInventory pib : oldLocationInventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pib : newLocationInventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb1.replace(productId, (short) (ivb1.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : oldLocationInventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (oldProductQuantities.containsKey(productId)) {
                        if (ivb.get(productId) - oldProductQuantities.get(productId) == pia.getQuantity()) {
                            oldLocationInventoryMatches++;
                            oldProductQuantities.remove(productId);
                        }
                    }
                }
            }
            for (ProductInventory pia : newLocationInventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (newProductQuantities.containsKey(productId)) {
                        if (ivb1.get(productId) + newProductQuantities.get(productId) == pia.getQuantity()) {
                            newLocationInventoryMatches++;
                            newProductQuantities.remove(productId);
                        }
                    }
                }
            }
        }
        Assert.assertTrue(oldLocationInventoryMatches > 0);
        Assert.assertEquals(oldLocationInventoryMatches, oldLocationInventoryAfter.size());
        Assert.assertTrue(newLocationInventoryMatches > 0);
        Assert.assertEquals(newLocationInventoryMatches, newLocationInventoryAfter.size());
    }

    @Test
    public void remove_ProductReceiptExists_ProductReceiptDeletedAndLocationInventoryAdjusted() throws Exception {
        long locationId = 110L;
        long productReceiptId = 109L;

        List<ProductInventory> inventoryBefore = inventoryManager.getProductInventories(locationId);

        ProductReceipt expected = em.getReference(ProductReceipt.class, productReceiptId);

        Map<Long, Short> productQuantities = new HashMap<>();

        List<ProductReceiptDetail> details = expected.getDetails();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!productQuantities.containsKey(productId)) {
                productQuantities.put(productId, detail.getQuantity());
            }
            else {
                productQuantities.replace(productId, (short) (productQuantities.get(productId) + detail.getQuantity()));
            }
        }

        productReceiptFacade.remove(expected);

        List<ProductInventory> inventoryAfter = inventoryManager.getProductInventories(locationId);

        int matches = 0;

        Map<Long, Short> ivb = new HashMap<>();

        for (ProductReceiptDetail detail : details) {
            Long productId = detail.getProduct().getId();
            if (!ivb.containsKey(productId)) {
                ivb.put(productId, (short) 0);
            }
            for (ProductInventory pib : inventoryBefore) {
                if (productId.equals(pib.getId().getProductId())) {
                    ivb.replace(productId, (short) (ivb.get(productId) + pib.getQuantity()));
                }
            }
            for (ProductInventory pia : inventoryAfter) {
                if (productId.equals(pia.getId().getProductId())) {
                    if (productQuantities.containsKey(productId)) {
                        if (ivb.get(productId) - productQuantities.get(productId) == pia.getQuantity()) {
                            matches++;
                            productQuantities.remove(productId);
                        }
                    }
                }
            }
        }
        Assert.assertTrue(matches > 0);
        Assert.assertEquals(matches, inventoryAfter.size());

        em.clear();

        boolean deleted = false;
        try {
            em.getReference(ProductReceipt.class, productReceiptId);
        } catch (EntityNotFoundException e) {
            deleted = true;
        }
        Assert.assertTrue(deleted);
    }

    @Test(expected = NonexistentEntityException.class)
    public void remove_ProductReceiptDoesNotExist_ThrowNonexistentEntityException() throws Exception {
        final ProductReceipt productReceipt = new ProductReceipt(5000L);
        productReceiptFacade.remove(productReceipt);
    }

    @Test(expected = InsufficientInventoryException.class)
    public void remove_LocationDoesNotHaveSufficientInventory_ThrowInsufficientInventoryException() throws Exception {
        final ProductReceipt productReceipt = new ProductReceipt(110L);
        Long locationId = 111L;
        Short availableQuantity = 0;
        Short requestedQuantity = 200;
        Long productId = 100L;

        try {
            productReceiptFacade.remove(productReceipt);
        } catch (InsufficientInventoryException e) {
            Assert.assertEquals(locationId, e.getLocationId());
            Assert.assertEquals(availableQuantity, e.getAvailableQuantity());
            Assert.assertEquals(requestedQuantity, e.getRequestedQuantity());
            Assert.assertEquals(productId, e.getProductId());
            throw e;
        }
    }

    @Test(expected = DuplicateProductReceiptReferenceNumberException.class)
    public void create_ReferenceNumberAlreadyExists_ThrowDuplicateProductReceiptReferenceNumberException() throws Exception {
        long locationId = 112L;

        ProductReceipt expected = new ProductReceipt();
        expected.setReferenceNumber("PR-111");
        expected.setLocation(new Location(locationId));

        ProductReceiptDetail detail1 = new ProductReceiptDetail();
        detail1.setQuantity((short) 2500);
        detail1.setProduct(new Product(100L));

        ProductReceiptDetail detail2 = new ProductReceiptDetail();
        detail2.setQuantity((short) 3000);
        detail2.setProduct(new Product(101L));

        List<ProductReceiptDetail> details = new ArrayList<>();
        details.add(detail1);
        details.add(detail2);

        expected.setDetails(details);

        try {
            productReceiptFacade.create(expected);
        } catch (DuplicateProductReceiptReferenceNumberException e) {
            Assert.assertEquals(expected.getReferenceNumber(), e.getReferenceNumber());
            throw e;
        }
    }
}
