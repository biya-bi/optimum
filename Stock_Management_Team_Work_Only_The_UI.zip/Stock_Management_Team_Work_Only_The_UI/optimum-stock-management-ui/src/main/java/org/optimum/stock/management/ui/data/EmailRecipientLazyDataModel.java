/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.EmailRecipient;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.persistence.EmailRecipientFacade;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class EmailRecipientLazyDataModel extends IntegerIdLazyDataModel<EmailRecipient> {

    @EJB
    private EmailRecipientFacade emailRecipientFacade;

    private static final String NAME_FILTER = "name";
    private static final String EMAIL_FILTER = "email";
    private static final String LOCALE_NAME_FILTER = "locale.name";

    private final List<Filter> filters;

    private final Filter nameFilter;

    private final Filter emailFilter;
    private final Filter localeNameFilter;

    public EmailRecipientLazyDataModel() {
        nameFilter = new Filter(NAME_FILTER, RelationalOperator.CONTAINS, "");
        emailFilter = new Filter(EMAIL_FILTER, RelationalOperator.CONTAINS, "");
        localeNameFilter = new Filter(LOCALE_NAME_FILTER, RelationalOperator.CONTAINS, "");

        filters = new ArrayList<>();
        filters.add(nameFilter);
        filters.add(emailFilter);
        filters.add(localeNameFilter);
    }

    @Override
    protected CrudFacade<EmailRecipient> getFacade() {
        return emailRecipientFacade;
    }

    public Filter getNameFilter() {
        return nameFilter;
    }

    public Filter getEmailFilter() {
        return emailFilter;
    }

    public Filter getLocaleNameFilter() {
        return localeNameFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<EmailRecipient> list) {
        if (sortField == null) {
            sortField = EMAIL_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<EmailRecipient>() {
                        @Override
                        public int compare(EmailRecipient one, EmailRecipient other) {
                            int result = comparator.compare(one.getName(), other.getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case EMAIL_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<EmailRecipient>() {
                        @Override
                        public int compare(EmailRecipient one, EmailRecipient other) {
                            int result = comparator.compare(one.getEmail(), other.getEmail());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case LOCALE_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<EmailRecipient>() {
                        @Override
                        public int compare(EmailRecipient one, EmailRecipient other) {
                            int result = comparator.compare(one.getLocale().getName(), other.getLocale().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
