/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

/**
 *
 * @author Biya-Bi
 * @param <TModel>
 */
public abstract class LongIdLazyDataModel<TModel> extends AbstractLazyDataModel<TModel, Long> {

    @Override
    protected Long toModelId(String rowKey) {
        return Long.valueOf(rowKey);
    }
}
