/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.Alert;
import org.optimum.stock.management.core.entities.EmailRecipient;
import org.optimum.stock.management.core.entities.EmailTemplate;
import org.optimum.stock.management.core.entities.Schedule;
import org.optimum.stock.management.core.persistence.AlertFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class AlertController extends Controller<Alert> {

    @EJB
    private AlertFacade alertFacade;

    private List<EmailRecipient> selectedEmailRecipients;
    private List<EmailTemplate> selectedEmailTemplates;

    public AlertController() {
        super(Alert.class);
    }

    @Override
    protected CrudFacade<Alert> getFacade() {
        return alertFacade;
    }

    @Override
    public Alert prepareCreate() {
        Alert alert = super.prepareCreate();
        alert.setEnabled(true);
        alert.setImmediate(true);

        Schedule schedule = new Schedule();
        schedule.setHour((byte) 0);
        schedule.setMinute((byte) 0);
        schedule.setSecond((byte) 0);
        schedule.setDayOfMonth("*");
        schedule.setTimezone("GMT");
        schedule.setYear("*");

        alert.setSchedule(schedule);
        return alert;
    }

    public List<EmailRecipient> getSelectedEmailRecipients() {
        return selectedEmailRecipients;
    }

    public void setSelectedEmailRecipients(List<EmailRecipient> selectedEmailRecipients) {
        this.selectedEmailRecipients = selectedEmailRecipients;
    }

    public void addEmailRecipients() throws Exception {
        if (this.getCurrent() != null && this.selectedEmailRecipients != null) {
            List<EmailRecipient> emailRecipients = this.getCurrent().getEmailRecipients();
            if (emailRecipients == null) {
                emailRecipients = new ArrayList<>();
                this.getCurrent().setEmailRecipients(emailRecipients);
            }
            for (EmailRecipient emailRecipient : selectedEmailRecipients) {
                if (!emailRecipients.contains(emailRecipient)) {
                    emailRecipients.add(emailRecipient);
                }
            }
            this.edit();
        }
    }

    public void removeEmailRecipients() throws Exception {
        if (this.getCurrent() != null && this.selectedEmailRecipients != null) {
            List<EmailRecipient> emailRecipients = this.getCurrent().getEmailRecipients();
            if (emailRecipients == null) {
                emailRecipients = new ArrayList<>();
                this.getCurrent().setEmailRecipients(emailRecipients);
            }
            for (EmailRecipient emailRecipient : selectedEmailRecipients) {
                if (emailRecipients.contains(emailRecipient)) {
                    emailRecipients.remove(emailRecipient);
                }
            }
            this.edit();
        }
    }

    public List<EmailTemplate> getSelectedEmailTemplates() {
        return selectedEmailTemplates;
    }

    public void setSelectedEmailTemplates(List<EmailTemplate> selectedEmailTemplates) {
        this.selectedEmailTemplates = selectedEmailTemplates;
    }

    public void addEmailTemplates() throws Exception {
        if (this.getCurrent() != null && this.selectedEmailTemplates != null) {
            List<EmailTemplate> emailTemplates = this.getCurrent().getEmailTemplates();
            if (emailTemplates == null) {
                emailTemplates = new ArrayList<>();
                this.getCurrent().setEmailTemplates(emailTemplates);
            }
            for (EmailTemplate emailTemplate : selectedEmailTemplates) {
                if (!emailTemplates.contains(emailTemplate)) {
                    emailTemplates.add(emailTemplate);
                }
            }
            this.edit();
        }
    }

    public void removeEmailTemplates() throws Exception {
        if (this.getCurrent() != null && this.selectedEmailTemplates != null) {
            List<EmailTemplate> emailTemplates = this.getCurrent().getEmailTemplates();
            if (emailTemplates == null) {
                emailTemplates = new ArrayList<>();
                this.getCurrent().setEmailTemplates(emailTemplates);
            }
            for (EmailTemplate emailTemplate : selectedEmailTemplates) {
                if (emailTemplates.contains(emailTemplate)) {
                    emailTemplates.remove(emailTemplate);
                }
            }
            this.edit();
        }
    }

}
