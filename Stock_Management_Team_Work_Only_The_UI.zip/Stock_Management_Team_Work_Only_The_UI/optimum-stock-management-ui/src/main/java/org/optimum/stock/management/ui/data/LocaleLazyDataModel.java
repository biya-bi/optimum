/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.Locale;
import org.optimum.stock.management.core.persistence.LocaleFacade;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class LocaleLazyDataModel extends IntegerIdLazyDataModel<Locale> {

    @EJB
    private LocaleFacade localeFacade;

    private static final String NAME_FILTER = "name";
    private static final String LANGUAGE_CODE_FILTER = "languageCode";
    private static final String LCID_FILTER = "lcid";

    private final List<Filter> filters;

    private final Filter nameFilter;
    private final Filter languageCodeFilter;
    private final Filter lcidFilter;

    public LocaleLazyDataModel() {
        nameFilter = new Filter(NAME_FILTER, RelationalOperator.CONTAINS, "");
        languageCodeFilter = new Filter(LANGUAGE_CODE_FILTER, RelationalOperator.CONTAINS, "");
        lcidFilter = new Filter(LCID_FILTER, RelationalOperator.CONTAINS, "");

        filters = new ArrayList<>();
        filters.add(nameFilter);
        filters.add(languageCodeFilter);
        filters.add(lcidFilter);
    }

    @Override
    protected CrudFacade<Locale> getFacade() {
        return localeFacade;
    }

    public Filter getNameFilter() {
        return nameFilter;
    }

    public Filter getLanguageCodeFilter() {
        return languageCodeFilter;
    }

    public Filter getLcidFilter() {
        return lcidFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<Locale> list) {
        if (sortField == null) {
            sortField = NAME_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Locale>() {
                        @Override
                        public int compare(Locale one, Locale other) {
                            int result = comparator.compare(one.getName(), other.getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case LANGUAGE_CODE_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Locale>() {
                        @Override
                        public int compare(Locale one, Locale other) {
                            int result = comparator.compare(one.getLanguageCode(), other.getLanguageCode());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case LCID_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Locale>() {
                        @Override
                        public int compare(Locale one, Locale other) {
                            int result = comparator.compare(one.getLcid(), other.getLcid());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
