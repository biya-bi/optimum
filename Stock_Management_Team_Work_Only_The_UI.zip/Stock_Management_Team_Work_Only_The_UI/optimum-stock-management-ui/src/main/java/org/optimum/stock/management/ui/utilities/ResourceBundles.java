/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.utilities;

/**
 *
 * @author Biya-Bi
 */
public class ResourceBundles {

    public static final String CRUD_MESSAGES = "org.optimum.stock.management.ui.CrudMessages";
    public static final String LABELS = "org.optimum.stock.management.ui.Labels";
    public static final String NOTIFICATIONS = "org.optimum.stock.management.ui.Notifications";
}
