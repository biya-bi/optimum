/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.entities.PurchaseOrder;
import org.optimum.stock.management.core.entities.PurchaseOrderDetail;
import org.optimum.stock.management.core.entities.PurchaseOrderStatus;
import org.optimum.stock.management.core.persistence.PurchaseOrderFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class PurchaseOrderController extends Controller<PurchaseOrder> {

    @EJB
    private PurchaseOrderFacade purchaseOrderFacade;

    private PurchaseOrderDetail detail;

    private List<PurchaseOrderDetail> receivedDetails;

    private Location receiptLocation;

    public PurchaseOrderController() {
        super(PurchaseOrder.class);
    }

    @Override
    protected CrudFacade<PurchaseOrder> getFacade() {
        return purchaseOrderFacade;
    }

    @Override
    public PurchaseOrder prepareCreate() {
        PurchaseOrder purchaseOrder = super.prepareCreate();
        purchaseOrder.setStatus(PurchaseOrderStatus.PENDING);
        return purchaseOrder;
    }

    public PurchaseOrderDetail getDetail() {
        return detail;
    }

    public void setDetail(PurchaseOrderDetail detail) {
        this.detail = detail;
    }

    public List<PurchaseOrderDetail> getReceivedDetails() {
        return receivedDetails;
    }

    public void setReceivedDetails(List<PurchaseOrderDetail> receivedDetails) {
        this.receivedDetails = receivedDetails;
    }

    public Location getReceiptLocation() {
        return receiptLocation;
    }

    public void setReceiptLocation(Location receiptLocation) {
        this.receiptLocation = receiptLocation;
    }

    private int getDetailId() {
        List<Integer> detailIds = new ArrayList<>();
        for (PurchaseOrderDetail d : receivedDetails) {
            Integer detailId = d.getDetailId();
            if (!detailIds.contains(detailId)) {
                detailIds.add(detailId);
            }
        }
        int detailId = 0;
        while (detailId++ < receivedDetails.size()) {
            if (!detailIds.contains(detailId)) {
                break;
            }
        }
        return detailId;
    }

    public void addDetail() {
        PurchaseOrder purchaseOrder = this.getCurrent();
        if (purchaseOrder != null) {
            List<PurchaseOrderDetail> details = purchaseOrder.getDetails();
            if (details == null) {
                details = new ArrayList<>();
                purchaseOrder.setDetails(details);
            }
            detail.setDetailId(getDetailId());
            details.add(detail);
        }
    }

    public void removeDetail(PurchaseOrderDetail detail) {
        if (detail != null) {
            PurchaseOrder purchaseOrder = this.getCurrent();
            if (purchaseOrder != null) {
                List<PurchaseOrderDetail> details = purchaseOrder.getDetails();
                if (details != null) {
                    details.remove(detail);
                }
            }
        }
    }

    public void prepareDetail() {
        detail = new PurchaseOrderDetail();
        detail.setReceivedQuantity((short) 0);
        detail.setRejectedQuantity((short) 0);
    }

    public boolean canBeApproved() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == PurchaseOrderStatus.PENDING;
    }

    public boolean canBeRejected() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == PurchaseOrderStatus.PENDING;
    }

    public boolean canBeCompleted() {
        return this.getCurrent() != null && this.getCurrent().getStatus() == PurchaseOrderStatus.APPROVED;
    }

    public void approve() throws Exception {
        purchaseOrderFacade.approve(this.getCurrent().getId());
    }

    public void reject() throws Exception {
        purchaseOrderFacade.reject(this.getCurrent().getId());
    }

    public void complete() throws Exception {
        Map<Long, Short> productByQuantities = new HashMap<>();
        for (PurchaseOrderDetail receivedDetail : receivedDetails) {
            Long productId = receivedDetail.getProduct().getId();
            if (!productByQuantities.containsKey(productId)) {
                productByQuantities.put(productId, receivedDetail.getReceivedQuantity());
            }
            else {
                productByQuantities.replace(productId, (short) (productByQuantities.get(productId) + receivedDetail.getReceivedQuantity()));
            }
        }
        purchaseOrderFacade.complete(this.getCurrent().getId(), this.getReceiptLocation().getId(), productByQuantities);
    }

    public void addReceivedDetail() {
        if (detail != null) {
            if (receivedDetails == null) {
                receivedDetails = new ArrayList<>();
            }
            receivedDetails.add(detail);
        }
    }

    public void removeReceivedDetail(PurchaseOrderDetail detail) {
        if (detail != null) {
            if (receivedDetails != null) {
                receivedDetails.remove(detail);
            }
        }
    }

    public void prepareComplete() {
        receiptLocation = this.getCurrent().getLocation();
        receivedDetails = new ArrayList<>();
        for (PurchaseOrderDetail d : this.getCurrent().getDetails()) {
            PurchaseOrderDetail receivedDetail = new PurchaseOrderDetail();
            receivedDetail.setDetailId(d.getDetailId());
            receivedDetail.setProduct(d.getProduct());
            receivedDetail.setReceivedQuantity(d.getOrderedQuantity());
            receivedDetails.add(receivedDetail);
        }
    }
}
