/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

/**
 *
 * @author Biya-Bi
 * @param <TModel>
 */
public abstract class IntegerIdLazyDataModel<TModel> extends AbstractLazyDataModel<TModel, Integer> {

    @Override
    protected Integer toModelId(String rowKey) {
        return Integer.valueOf(rowKey);
    }
}
