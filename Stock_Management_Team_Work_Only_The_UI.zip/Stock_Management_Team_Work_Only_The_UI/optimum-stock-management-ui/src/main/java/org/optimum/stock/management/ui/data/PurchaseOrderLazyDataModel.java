/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.PurchaseOrder;
import org.optimum.stock.management.core.persistence.PurchaseOrderFacade;
import org.optimum.stock.management.ui.translation.EnumTranslator;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class PurchaseOrderLazyDataModel extends LongIdLazyDataModel<PurchaseOrder> {

    @EJB
    private PurchaseOrderFacade purchaseOrderFacade;

    private final EnumTranslator translator;

    private static final String REFERENCE_NUMBER_FILTER = "referenceNumber";
    private static final String VENDOR_NAME_FILTER = "vendor.name";
    private static final String LOCATION_NAME_FILTER = "location.name";
    private static final String SHIP_METHOD_NAME_FILTER = "shipMethod.name";
    private static final String STATUS_FILTER = "status";
    private static final String TAX_AMOUNT_FILTER = "taxAmount";
    private static final String REVISION_NUMBER_FILTER = "revisionNumber";
    private static final String FREIGHT_FILTER = "freight";
    private static final String SHIP_DATE_FILTER = "shipDate";

    private final List<Filter> filters;

    private final Filter referenceNumberFilter;
    private final Filter vendorNameFilter;
    private final Filter locationNameFilter;
    private final Filter shipMethodNameFilter;
    private final Filter statusFilter;
    private final Filter taxAmountFilter;
    private final Filter revisionNumberFilter;
    private final Filter freightFilter;
    private final Filter shipDateFilter;

    public PurchaseOrderLazyDataModel() {
        translator = new EnumTranslator();

        referenceNumberFilter = new Filter(REFERENCE_NUMBER_FILTER, RelationalOperator.CONTAINS, "");
        vendorNameFilter = new Filter(VENDOR_NAME_FILTER, RelationalOperator.CONTAINS, "");
        locationNameFilter = new Filter(LOCATION_NAME_FILTER);
        shipMethodNameFilter = new Filter(SHIP_METHOD_NAME_FILTER);
        statusFilter = new Filter(STATUS_FILTER);
        taxAmountFilter = new Filter(TAX_AMOUNT_FILTER);
        revisionNumberFilter = new Filter(REVISION_NUMBER_FILTER);
        freightFilter = new Filter(FREIGHT_FILTER);
        shipDateFilter = new Filter(SHIP_DATE_FILTER, RelationalOperator.EQUAL, null);

        filters = new ArrayList<>();
        filters.add(referenceNumberFilter);
        filters.add(vendorNameFilter);
        filters.add(locationNameFilter);
        filters.add(shipMethodNameFilter);
        filters.add(statusFilter);
        filters.add(taxAmountFilter);
        filters.add(revisionNumberFilter);
        filters.add(freightFilter);
        filters.add(shipDateFilter);
    }

    @Override
    protected CrudFacade<PurchaseOrder> getFacade() {
        return purchaseOrderFacade;
    }

    public Filter getReferenceNumberFilter() {
        return referenceNumberFilter;
    }

    public Filter getVendorNameFilter() {
        return vendorNameFilter;
    }

    public Filter getTaxAmountFilter() {
        return taxAmountFilter;
    }

    public Filter getRevisionNumberFilter() {
        return revisionNumberFilter;
    }

    public Filter getFreightFilter() {
        return freightFilter;
    }

    public Filter getLocationNameFilter() {
        return locationNameFilter;
    }

    public Filter getShipMethodNameFilter() {
        return shipMethodNameFilter;
    }

    public Filter getStatusFilter() {
        return statusFilter;
    }

    public Filter getShipDateFilter() {
        return shipDateFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<PurchaseOrder> list) {
        if (sortField == null) {
            sortField = REFERENCE_NUMBER_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case REFERENCE_NUMBER_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(one.getReferenceNumber(), other.getReferenceNumber());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case VENDOR_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(one.getVendor().getName(), other.getVendor().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case LOCATION_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            if (one.getLocation() == null && other.getLocation() == null) {
                                return 0;
                            }
                            if (one.getLocation() == null) {
                                return order == SortOrder.DESCENDING ? 1 : -1;
                            }
                            if (other.getLocation() == null) {
                                return order == SortOrder.DESCENDING ? -1 : 1;
                            }
                            int result = comparator.compare(one.getLocation().getName(), other.getLocation().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SHIP_METHOD_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            if (one.getShipMethod() == null && other.getShipMethod() == null) {
                                return 0;
                            }
                            if (one.getShipMethod() == null) {
                                return order == SortOrder.DESCENDING ? 1 : -1;
                            }
                            if (other.getShipMethod() == null) {
                                return order == SortOrder.DESCENDING ? -1 : 1;
                            }
                            int result = comparator.compare(one.getShipMethod().getName(), other.getShipMethod().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case TAX_AMOUNT_FILTER: {
                    final Comparator<Double> comparator = DefaultComparator.<Double>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(one.getTaxAmount(), other.getTaxAmount());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case REVISION_NUMBER_FILTER: {
                    final Comparator<Byte> comparator = DefaultComparator.<Byte>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(one.getRevisionNumber(), other.getRevisionNumber());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case FREIGHT_FILTER: {
                    final Comparator<Double> comparator = DefaultComparator.<Double>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(one.getFreight(), other.getFreight());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SHIP_DATE_FILTER: {
                    final Comparator<Date> comparator = DefaultComparator.<Date>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(one.getShipDate(), other.getShipDate());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case STATUS_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<PurchaseOrder>() {
                        @Override
                        public int compare(PurchaseOrder one, PurchaseOrder other) {
                            int result = comparator.compare(translator.translate(one.getStatus()), translator.translate(other.getStatus()));
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
