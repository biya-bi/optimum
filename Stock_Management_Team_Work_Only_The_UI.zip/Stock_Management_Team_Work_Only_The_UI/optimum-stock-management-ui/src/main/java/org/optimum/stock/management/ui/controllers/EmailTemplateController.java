/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.AddressType;
import org.optimum.stock.management.core.entities.BusinessEntityAddress;
import org.optimum.stock.management.core.entities.BusinessEntityEmail;
import org.optimum.stock.management.core.entities.BusinessEntityFax;
import org.optimum.stock.management.core.entities.BusinessEntityPhone;
import org.optimum.stock.management.core.entities.EmailType;
import org.optimum.stock.management.core.entities.FaxType;
import org.optimum.stock.management.core.entities.PhoneType;
import org.optimum.stock.management.core.entities.EmailTemplate;
import org.optimum.stock.management.core.persistence.EmailTemplateFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class EmailTemplateController extends Controller<EmailTemplate> {

    @EJB
    private EmailTemplateFacade emailTemplateFacade;

    public EmailTemplateController() {
        super(EmailTemplate.class);
    }

    @Override
    protected CrudFacade<EmailTemplate> getFacade() {
        return emailTemplateFacade;
    }
}
