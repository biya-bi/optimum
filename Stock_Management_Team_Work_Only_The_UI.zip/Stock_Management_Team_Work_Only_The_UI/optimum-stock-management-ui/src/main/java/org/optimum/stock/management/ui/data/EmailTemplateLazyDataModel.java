/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.EmailTemplate;
import org.optimum.stock.management.core.persistence.EmailTemplateFacade;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class EmailTemplateLazyDataModel extends IntegerIdLazyDataModel<EmailTemplate> {

    @EJB
    private EmailTemplateFacade emailTemplateFacade;

    private static final String NAME_FILTER = "name";
    private static final String SUBJECT_FILTER = "subject";
    private static final String LOCALE_NAME_FILTER = "locale.name";

    private final List<Filter> filters;

    private final Filter nameFilter;
    private final Filter subjectFilter;
    private final Filter localeNameFilter;

    public EmailTemplateLazyDataModel() {
        nameFilter = new Filter(NAME_FILTER, RelationalOperator.CONTAINS, "");
        subjectFilter = new Filter(SUBJECT_FILTER, RelationalOperator.CONTAINS, "");
        localeNameFilter = new Filter(LOCALE_NAME_FILTER, RelationalOperator.CONTAINS, "");

        filters = new ArrayList<>();
        filters.add(nameFilter);
        filters.add(subjectFilter);
        filters.add(localeNameFilter);
    }

    @Override
    protected CrudFacade<EmailTemplate> getFacade() {
        return emailTemplateFacade;
    }

    public Filter getNameFilter() {
        return nameFilter;
    }

    public Filter getSubjectFilter() {
        return subjectFilter;
    }

    public Filter getLocaleNameFilter() {
        return localeNameFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<EmailTemplate> list) {
        if (sortField == null) {
            sortField = NAME_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<EmailTemplate>() {
                        @Override
                        public int compare(EmailTemplate one, EmailTemplate other) {
                            int result = comparator.compare(one.getName(), other.getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SUBJECT_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<EmailTemplate>() {
                        @Override
                        public int compare(EmailTemplate one, EmailTemplate other) {
                            int result = comparator.compare(one.getSubject(), other.getSubject());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case LOCALE_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<EmailTemplate>() {
                        @Override
                        public int compare(EmailTemplate one, EmailTemplate other) {
                            int result = comparator.compare(one.getLocale().getName(), other.getLocale().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
