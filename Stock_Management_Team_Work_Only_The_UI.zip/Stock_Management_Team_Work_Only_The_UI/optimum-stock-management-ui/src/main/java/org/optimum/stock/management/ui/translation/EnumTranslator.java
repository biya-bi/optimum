/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.translation;

import java.util.ResourceBundle;
import org.optimum.stock.management.core.entities.AlertCategory;
import org.optimum.stock.management.core.entities.AlertType;
import org.optimum.stock.management.core.entities.PurchaseOrderStatus;
import org.optimum.stock.management.core.entities.ShippingOrderStatus;
import org.optimum.stock.management.ui.utilities.ResourceBundles;

/**
 *
 * @author Biya-Bi
 */
public class EnumTranslator {

    private final ResourceBundle resourceBundle;

    public EnumTranslator() {
        resourceBundle = ResourceBundle.getBundle(ResourceBundles.LABELS);
    }

    public String translate(PurchaseOrderStatus status) {
        if (status == null) {
            return null;
        }
        switch (status) {
            case PENDING:
                return resourceBundle.getString("Pending");
            case APPROVED:
                return resourceBundle.getString("Approved");
            case REJECTED:
                return resourceBundle.getString("Rejected");
            case COMPLETE:
                return resourceBundle.getString("Complete");
            default:
                return null;
        }
    }

    public String translate(ShippingOrderStatus status) {
        if (status == null) {
            return null;
        }
        switch (status) {
            case PENDING:
                return resourceBundle.getString("Pending");
            case APPROVED:
                return resourceBundle.getString("Approved");
            case REJECTED:
                return resourceBundle.getString("Rejected");
            case IN_TRANSIT:
                return resourceBundle.getString("InTransit");
            case RESTITUTED:
                return resourceBundle.getString("Restituted");
            case DELIVERED:
                return resourceBundle.getString("Delivered");
            default:
                return null;
        }
    }

    public String translate(AlertCategory alertCategory) {
        if (alertCategory == null) {
            return null;
        }
        switch (alertCategory) {
            case STOCK_LEVEL:
                return resourceBundle.getString("StockLevel");
            default:
                return null;
        }
    }
    
      public String translate(AlertType alertType) {
        if (alertType == null) {
            return null;
        }
        switch (alertType) {
            case RECOVERY:
                return resourceBundle.getString("Recovery");
            case WARNING:
                return resourceBundle.getString("Warning");
            default:
                return null;
        }
    }
}
