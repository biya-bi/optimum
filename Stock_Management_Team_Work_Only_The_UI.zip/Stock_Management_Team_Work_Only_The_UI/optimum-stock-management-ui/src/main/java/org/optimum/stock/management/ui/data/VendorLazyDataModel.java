/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.Vendor;
import org.optimum.stock.management.core.persistence.VendorFacade;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class VendorLazyDataModel extends LongIdLazyDataModel<Vendor> {

    @EJB
    private VendorFacade vendorFacade;

    private static final String NAME_FILTER = "name";
    private static final String ACCOUNT_NUMBER_FILTER = "accountNumber";
    private static final String PURCHASING_URL_FILTER = "purchasingUrl";
    private static final String ACTIVE_FILTER = "active";

    private final List<Filter> filters;

    private final Filter nameFilter;
    private final Filter accountNumberFilter;
    private final Filter purchasingUrlFilter;
    private final Filter activeFilter;

    public VendorLazyDataModel() {
        nameFilter = new Filter(NAME_FILTER, RelationalOperator.CONTAINS, "");
        accountNumberFilter = new Filter(ACCOUNT_NUMBER_FILTER, RelationalOperator.CONTAINS, "");
        purchasingUrlFilter = new Filter(PURCHASING_URL_FILTER, RelationalOperator.CONTAINS, "");
        activeFilter = new Filter(ACTIVE_FILTER);

        filters = new ArrayList<>();
        filters.add(nameFilter);
        filters.add(accountNumberFilter);
        filters.add(purchasingUrlFilter);
        filters.add(activeFilter);
    }

    @Override
    protected CrudFacade<Vendor> getFacade() {
        return vendorFacade;
    }

    public Filter getNameFilter() {
        return nameFilter;
    }

    public Filter getAccountNumberFilter() {
        return accountNumberFilter;
    }

    public Filter getPurchasingUrlFilter() {
        return purchasingUrlFilter;
    }

    public Filter getActiveFilter() {
        return activeFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<Vendor> list) {
        if (sortField == null) {
            sortField = NAME_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Vendor>() {
                        @Override
                        public int compare(Vendor one, Vendor other) {
                            int result = comparator.compare(one.getName(), other.getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case ACCOUNT_NUMBER_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Vendor>() {
                        @Override
                        public int compare(Vendor one, Vendor other) {
                            int result = comparator.compare(one.getAccountNumber(), other.getAccountNumber());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case PURCHASING_URL_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Vendor>() {
                        @Override
                        public int compare(Vendor one, Vendor other) {
                            int result = comparator.compare(one.getPurchasingUrl(), other.getPurchasingUrl());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case ACTIVE_FILTER: {
                    final Comparator<Boolean> comparator = DefaultComparator.<Boolean>getInstance();
                    Collections.sort(list, new Comparator<Vendor>() {
                        @Override
                        public int compare(Vendor one, Vendor other) {
                            int result = comparator.compare(one.isActive(), other.isActive());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
