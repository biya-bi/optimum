/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.Alert;
import org.optimum.stock.management.core.persistence.AlertFacade;
import org.optimum.stock.management.ui.translation.EnumTranslator;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class AlertLazyDataModel extends IntegerIdLazyDataModel<Alert> {

    @EJB
    private AlertFacade alertFacade;

    private final EnumTranslator translator;

    private static final String ALERT_TYPE_FILTER = "alertType";
    private static final String ALERT_CATEGORY_FILTER = "alertCategory";
    private static final String ENABLED_FILTER = "enabled";
    private static final String IMMEDIATE_FILTER = "immediate";

    private final List<Filter> filters;

    private final Filter alertTypeFilter;
    private final Filter alertCategoryFilter;
    private final Filter enabledFilter;
    private final Filter immediateFilter;

    public AlertLazyDataModel() {
        translator = new EnumTranslator();

        alertTypeFilter = new Filter(ALERT_TYPE_FILTER, RelationalOperator.CONTAINS, "");
        alertCategoryFilter = new Filter(ALERT_CATEGORY_FILTER, RelationalOperator.CONTAINS, "");
        enabledFilter = new Filter(ENABLED_FILTER);
        immediateFilter = new Filter(IMMEDIATE_FILTER);

        filters = new ArrayList<>();
        filters.add(alertTypeFilter);
        filters.add(alertCategoryFilter);
        filters.add(enabledFilter);
        filters.add(immediateFilter);
    }

    @Override
    protected CrudFacade<Alert> getFacade() {
        return alertFacade;
    }

    public Filter getAlertTypeFilter() {
        return alertTypeFilter;
    }

    public Filter getAlertCategoryFilter() {
        return alertCategoryFilter;
    }

    public Filter getEnabledFilter() {
        return enabledFilter;
    }

    public Filter getImmediateFilter() {
        return immediateFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<Alert> list) {
        if (sortField == null) {
            sortField = ALERT_TYPE_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case ALERT_TYPE_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Alert>() {
                        @Override
                        public int compare(Alert one, Alert other) {
                            int result = comparator.compare(translator.translate(one.getAlertType()), translator.translate(other.getAlertType()));
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case ALERT_CATEGORY_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<Alert>() {
                        @Override
                        public int compare(Alert one, Alert other) {
                            int result = comparator.compare(translator.translate(one.getAlertCategory()), translator.translate(other.getAlertCategory()));
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case ENABLED_FILTER: {
                    final Comparator<Boolean> comparator = DefaultComparator.<Boolean>getInstance();
                    Collections.sort(list, new Comparator<Alert>() {
                        @Override
                        public int compare(Alert one, Alert other) {
                            int result = comparator.compare(one.isEnabled(), other.isEnabled());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case IMMEDIATE_FILTER: {
                    final Comparator<Boolean> comparator = DefaultComparator.<Boolean>getInstance();
                    Collections.sort(list, new Comparator<Alert>() {
                        @Override
                        public int compare(Alert one, Alert other) {
                            int result = comparator.compare(one.isImmediate(), other.isImmediate());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
