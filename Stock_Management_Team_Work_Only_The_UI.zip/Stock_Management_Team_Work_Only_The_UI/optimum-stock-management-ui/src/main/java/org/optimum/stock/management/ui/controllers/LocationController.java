/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.controllers;

import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.persistence.CrudFacade;
import org.optimum.stock.management.core.entities.Location;
import org.optimum.stock.management.core.persistence.LocationFacade;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class LocationController extends Controller<Location> {

    @EJB
    private LocationFacade locationFacade;

    public LocationController() {
        super(Location.class);
    }

    @Override
    protected CrudFacade<Location> getFacade() {
        return locationFacade;
    }
    
    
}
