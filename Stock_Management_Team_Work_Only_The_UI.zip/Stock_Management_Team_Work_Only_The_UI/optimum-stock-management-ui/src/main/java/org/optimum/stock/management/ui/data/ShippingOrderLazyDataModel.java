/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.optimum.stock.management.ui.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.optimum.common.utilities.DefaultComparator;
import org.optimum.persistence.CrudFacade;
import org.optimum.persistence.Filter;
import org.optimum.persistence.RelationalOperator;
import org.optimum.stock.management.core.entities.ShippingOrder;
import org.optimum.stock.management.core.persistence.ShippingOrderFacade;
import org.optimum.stock.management.ui.translation.EnumTranslator;
import org.primefaces.model.SortOrder;

/**
 *
 * @author Biya-Bi
 */
@Named
@ViewScoped
public class ShippingOrderLazyDataModel extends LongIdLazyDataModel<ShippingOrder> {

    @EJB
    private ShippingOrderFacade shippingOrderFacade;

    private final EnumTranslator translator;

    private static final String REFERENCE_NUMBER_FILTER = "referenceNumber";
    private static final String SOURCE_LOCATION_NAME_FILTER = "sourceLocation.name";
    private static final String TARGET_LOCATION_NAME_FILTER = "targetLocation.name";
    private static final String SHIP_METHOD_NAME_FILTER = "shipMethod.name";
    private static final String STATUS_FILTER = "status";
    private static final String DELIVERY_DATE_FILTER = "deliveryDate";
    private static final String SHIP_DATE_FILTER = "shipDate";

    private final List<Filter> filters;

    private final Filter referenceNumberFilter;
    private final Filter sourceLocationNameFilter;
    private final Filter targetLocationNameFilter;
    private final Filter shipMethodNameFilter;
    private final Filter statusFilter;
    private final Filter deliveryDateFilter;
    private final Filter shipDateFilter;

    public ShippingOrderLazyDataModel() {
        translator = new EnumTranslator();

        referenceNumberFilter = new Filter(REFERENCE_NUMBER_FILTER, RelationalOperator.CONTAINS, "");
        sourceLocationNameFilter = new Filter(SOURCE_LOCATION_NAME_FILTER, RelationalOperator.CONTAINS, "");
        targetLocationNameFilter = new Filter(TARGET_LOCATION_NAME_FILTER, RelationalOperator.CONTAINS, "");
        shipMethodNameFilter = new Filter(SHIP_METHOD_NAME_FILTER);
        statusFilter = new Filter(STATUS_FILTER);
        deliveryDateFilter = new Filter(DELIVERY_DATE_FILTER, RelationalOperator.EQUAL, null);
        shipDateFilter = new Filter(SHIP_DATE_FILTER, RelationalOperator.EQUAL, null);

        filters = new ArrayList<>();
        filters.add(referenceNumberFilter);
        filters.add(sourceLocationNameFilter);
        filters.add(targetLocationNameFilter);
        filters.add(shipMethodNameFilter);
        filters.add(statusFilter);
        filters.add(deliveryDateFilter);
        filters.add(shipDateFilter);
    }

    @Override
    protected CrudFacade<ShippingOrder> getFacade() {
        return shippingOrderFacade;
    }

    public Filter getReferenceNumberFilter() {
        return referenceNumberFilter;
    }

    public Filter getSourceLocationNameFilter() {
        return sourceLocationNameFilter;
    }

    public Filter getDeliveryDateFilter() {
        return deliveryDateFilter;
    }

    public Filter getTargetLocationNameFilter() {
        return targetLocationNameFilter;
    }

    public Filter getShipMethodNameFilter() {
        return shipMethodNameFilter;
    }

    public Filter getStatusFilter() {
        return statusFilter;
    }

    public Filter getShipDateFilter() {
        return shipDateFilter;
    }

    @Override
    protected List<Filter> getFilters() {
        return filters;
    }

    @Override
    protected void sort(String sortField, SortOrder sortOrder, List<ShippingOrder> list) {
        if (sortField == null) {
            sortField = REFERENCE_NUMBER_FILTER; // We want to sort by name if no sort field was specified.
        }
        final SortOrder order = sortOrder;
        if (null != sortField) {
            switch (sortField) {
                case REFERENCE_NUMBER_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(one.getReferenceNumber(), other.getReferenceNumber());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SOURCE_LOCATION_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(one.getSourceLocation().getName(), other.getSourceLocation().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case TARGET_LOCATION_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(one.getTargetLocation().getName(), other.getTargetLocation().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SHIP_METHOD_NAME_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(one.getShipMethod().getName(), other.getShipMethod().getName());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case DELIVERY_DATE_FILTER: {
                    final Comparator<Date> comparator = DefaultComparator.<Date>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(one.getDeliveryDate(), other.getDeliveryDate());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case SHIP_DATE_FILTER: {
                    final Comparator<Date> comparator = DefaultComparator.<Date>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(one.getShipDate(), other.getShipDate());
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                case STATUS_FILTER: {
                    final Comparator<String> comparator = DefaultComparator.<String>getInstance();
                    Collections.sort(list, new Comparator<ShippingOrder>() {
                        @Override
                        public int compare(ShippingOrder one, ShippingOrder other) {
                            int result = comparator.compare(translator.translate(one.getStatus()), translator.translate(other.getStatus()));
                            if (order == SortOrder.DESCENDING) {
                                return -result;
                            }
                            return result;
                        }
                    });
                    break;
                }
                default:
                    break;
            }
        }
    }

}
