-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema optimumcrm
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `optimumcrm` ;

-- -----------------------------------------------------
-- Schema optimumcrm
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `optimumcrm` DEFAULT CHARACTER SET utf8 ;
USE `optimumcrm` ;

-- -----------------------------------------------------
-- Table `accounts`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `accounts` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `UNQ_ACCOUNTS_0` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addresses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addresses` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `LINE1` VARCHAR(255) NULL DEFAULT NULL,
  `LINE2` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `channel_types`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `channel_types` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `channels`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `channels` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `IS_ACTIVE` TINYINT(1) NULL DEFAULT '0',
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `CHANNEL_TYPE_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC),
  INDEX `FK_CHANNELS_CHANNEL_TYPE_ID` (`CHANNEL_TYPE_ID` ASC),
  CONSTRAINT `FK_CHANNELS_CHANNEL_TYPE_ID`
    FOREIGN KEY (`CHANNEL_TYPE_ID`)
    REFERENCES `channel_types` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `people`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `people` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `BIRTH_DATE` DATE NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `FIRST_NAME` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_NAME` VARCHAR(255) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME_PREFIX` VARCHAR(255) NULL DEFAULT NULL,
  `NAME_SUFFIX` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `contacts`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `contacts` (
  `ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `FK_CONTACTS_ID`
    FOREIGN KEY (`ID`)
    REFERENCES `people` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `contacts_addresses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `contacts_addresses` (
  `ADDRESS_ID` BIGINT(20) NOT NULL,
  `ADDRESS_TYPE` VARCHAR(255) NOT NULL,
  `CONTACT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ADDRESS_ID`),
  UNIQUE INDEX `UNQ_CONTACTS_ADDRESSES_0` (`CONTACT_ID` ASC, `ADDRESS_TYPE` ASC),
  CONSTRAINT `FK_CONTACTS_ADDRESSES_ADDRESS_ID`
    FOREIGN KEY (`ADDRESS_ID`)
    REFERENCES `addresses` (`ID`),
  CONSTRAINT `FK_CONTACTS_ADDRESSES_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `emails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `emails` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `contacts_emails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `contacts_emails` (
  `EMAIL_ID` BIGINT(20) NOT NULL,
  `EMAIL_TYPE` VARCHAR(255) NOT NULL,
  `CONTACT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`EMAIL_ID`),
  UNIQUE INDEX `UNQ_CONTACTS_EMAILS_0` (`CONTACT_ID` ASC, `EMAIL_TYPE` ASC),
  CONSTRAINT `FK_CONTACTS_EMAILS_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`),
  CONSTRAINT `FK_CONTACTS_EMAILS_EMAIL_ID`
    FOREIGN KEY (`EMAIL_ID`)
    REFERENCES `emails` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `faxes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `faxes` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `contacts_faxes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `contacts_faxes` (
  `FAX_ID` BIGINT(20) NOT NULL,
  `FAX_TYPE` VARCHAR(255) NOT NULL,
  `CONTACT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`FAX_ID`),
  UNIQUE INDEX `UNQ_CONTACTS_FAXES_0` (`CONTACT_ID` ASC, `FAX_TYPE` ASC),
  CONSTRAINT `FK_CONTACTS_FAXES_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`),
  CONSTRAINT `FK_CONTACTS_FAXES_FAX_ID`
    FOREIGN KEY (`FAX_ID`)
    REFERENCES `faxes` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `phones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `phones` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `DTYPE` VARCHAR(31) NULL DEFAULT NULL,
  `LINE` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `contacts_phones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `contacts_phones` (
  `PHONE_ID` BIGINT(20) NOT NULL,
  `PHONE_TYPE` VARCHAR(255) NOT NULL,
  `CONTACT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`PHONE_ID`),
  UNIQUE INDEX `UNQ_CONTACTS_PHONES_0` (`CONTACT_ID` ASC, `PHONE_TYPE` ASC),
  CONSTRAINT `FK_CONTACTS_PHONES_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`),
  CONSTRAINT `FK_CONTACTS_PHONES_PHONE_ID`
    FOREIGN KEY (`PHONE_ID`)
    REFERENCES `phones` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `ACCOUNT_ID` BIGINT(20) NOT NULL,
  `CHANNEL_ID` BIGINT(20) NOT NULL,
  `CONTACT_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC),
  INDEX `FK_CUSTOMERS_ACCOUNT_ID` (`ACCOUNT_ID` ASC),
  INDEX `FK_CUSTOMERS_CONTACT_ID` (`CONTACT_ID` ASC),
  INDEX `FK_CUSTOMERS_CHANNEL_ID` (`CHANNEL_ID` ASC),
  CONSTRAINT `FK_CUSTOMERS_ACCOUNT_ID`
    FOREIGN KEY (`ACCOUNT_ID`)
    REFERENCES `accounts` (`ID`),
  CONSTRAINT `FK_CUSTOMERS_CHANNEL_ID`
    FOREIGN KEY (`CHANNEL_ID`)
    REFERENCES `channels` (`ID`),
  CONSTRAINT `FK_CUSTOMERS_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `customers_addresses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers_addresses` (
  `ADDRESS_ID` BIGINT(20) NOT NULL,
  `ADDRESS_TYPE` VARCHAR(255) NOT NULL,
  `CUSTOMER_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ADDRESS_ID`),
  UNIQUE INDEX `UNQ_CUSTOMERS_ADDRESSES_0` (`CUSTOMER_ID` ASC, `ADDRESS_TYPE` ASC),
  CONSTRAINT `FK_CUSTOMERS_ADDRESSES_ADDRESS_ID`
    FOREIGN KEY (`ADDRESS_ID`)
    REFERENCES `addresses` (`ID`),
  CONSTRAINT `FK_CUSTOMERS_ADDRESSES_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `customers_emails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers_emails` (
  `EMAIL_ID` BIGINT(20) NOT NULL,
  `EMAIL_TYPE` VARCHAR(255) NOT NULL,
  `CUSTOMER_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`EMAIL_ID`),
  UNIQUE INDEX `UNQ_CUSTOMERS_EMAILS_0` (`CUSTOMER_ID` ASC, `EMAIL_TYPE` ASC),
  CONSTRAINT `FK_CUSTOMERS_EMAILS_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`),
  CONSTRAINT `FK_CUSTOMERS_EMAILS_EMAIL_ID`
    FOREIGN KEY (`EMAIL_ID`)
    REFERENCES `emails` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `customers_faxes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers_faxes` (
  `FAX_ID` BIGINT(20) NOT NULL,
  `FAX_TYPE` VARCHAR(255) NOT NULL,
  `CUSTOMER_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`FAX_ID`),
  UNIQUE INDEX `UNQ_CUSTOMERS_FAXES_0` (`CUSTOMER_ID` ASC, `FAX_TYPE` ASC),
  CONSTRAINT `FK_CUSTOMERS_FAXES_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`),
  CONSTRAINT `FK_CUSTOMERS_FAXES_FAX_ID`
    FOREIGN KEY (`FAX_ID`)
    REFERENCES `faxes` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `customers_phones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers_phones` (
  `PHONE_ID` BIGINT(20) NOT NULL,
  `PHONE_TYPE` VARCHAR(255) NOT NULL,
  `CUSTOMER_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`PHONE_ID`),
  UNIQUE INDEX `UNQ_CUSTOMERS_PHONES_0` (`CUSTOMER_ID` ASC, `PHONE_TYPE` ASC),
  CONSTRAINT `FK_CUSTOMERS_PHONES_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`),
  CONSTRAINT `FK_CUSTOMERS_PHONES_PHONE_ID`
    FOREIGN KEY (`PHONE_ID`)
    REFERENCES `phones` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `email_templates`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `email_templates` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `ENTITY_TYPE` VARCHAR(255) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `TYPE` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `marketing_lists`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `marketing_lists` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `ENTITY_TYPE` VARCHAR(255) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LIST_TYPE` VARCHAR(255) NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `email_campaigns`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `email_campaigns` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `DESCRIPTION` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NULL DEFAULT NULL,
  `SCHEDULE` VARCHAR(255) NOT NULL,
  `SENDER_EMAIL` VARCHAR(255) NULL DEFAULT NULL,
  `SENDER_NAME` VARCHAR(255) NULL DEFAULT NULL,
  `IS_SENT` TINYINT(1) NOT NULL DEFAULT '0',
  `VERSION` BIGINT(20) NOT NULL,
  `EMAIL_TEMPLATE_ID` BIGINT(20) NOT NULL,
  `MARKETING_LIST_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_EMAIL_CAMPAIGNS_MARKETING_LIST_ID` (`MARKETING_LIST_ID` ASC),
  INDEX `FK_EMAIL_CAMPAIGNS_EMAIL_TEMPLATE_ID` (`EMAIL_TEMPLATE_ID` ASC),
  CONSTRAINT `FK_EMAIL_CAMPAIGNS_EMAIL_TEMPLATE_ID`
    FOREIGN KEY (`EMAIL_TEMPLATE_ID`)
    REFERENCES `email_templates` (`ID`),
  CONSTRAINT `FK_EMAIL_CAMPAIGNS_MARKETING_LIST_ID`
    FOREIGN KEY (`MARKETING_LIST_ID`)
    REFERENCES `marketing_lists` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `email_templates_data`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `email_templates_data` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CONTENT` TEXT NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `LOCALE` VARCHAR(255) NOT NULL,
  `SUBJECT` VARCHAR(255) NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `EMAIL_TEMPLATE_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_EMAIL_TEMPLATES_DATA_EMAIL_TEMPLATE_ID` (`EMAIL_TEMPLATE_ID` ASC),
  CONSTRAINT `FK_EMAIL_TEMPLATES_DATA_EMAIL_TEMPLATE_ID`
    FOREIGN KEY (`EMAIL_TEMPLATE_ID`)
    REFERENCES `email_templates` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `filters`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `filters` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `FILED_NAME` VARCHAR(255) NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `OPERATOR` VARCHAR(255) NOT NULL,
  `VALUE` LONGBLOB NULL DEFAULT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `MARKETING_LIST_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_FILTERS_MARKETING_LIST_ID` (`MARKETING_LIST_ID` ASC),
  CONSTRAINT `FK_FILTERS_MARKETING_LIST_ID`
    FOREIGN KEY (`MARKETING_LIST_ID`)
    REFERENCES `marketing_lists` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `leads`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `leads` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `CHANNEL_ID` BIGINT(20) NOT NULL,
  `CONTACT_ID` BIGINT(20) NULL DEFAULT NULL,
  `CUSTOMER_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC),
  UNIQUE INDEX `UNQ_LEADS_0` (`NAME` ASC),
  INDEX `FK_LEADS_CHANNEL_ID` (`CHANNEL_ID` ASC),
  INDEX `FK_LEADS_CUSTOMER_ID` (`CUSTOMER_ID` ASC),
  INDEX `FK_LEADS_CONTACT_ID` (`CONTACT_ID` ASC),
  CONSTRAINT `FK_LEADS_CHANNEL_ID`
    FOREIGN KEY (`CHANNEL_ID`)
    REFERENCES `channels` (`ID`),
  CONSTRAINT `FK_LEADS_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`),
  CONSTRAINT `FK_LEADS_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `marketing_lists_contacts`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `marketing_lists_contacts` (
  `MARKETING_LIST_ID` BIGINT(20) NOT NULL,
  `CONTACT_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`MARKETING_LIST_ID`, `CONTACT_ID`),
  INDEX `FK_MARKETING_LISTS_CONTACTS_CONTACT_ID` (`CONTACT_ID` ASC),
  CONSTRAINT `FK_MARKETING_LISTS_CONTACTS_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`),
  CONSTRAINT `FK_MARKETING_LISTS_CONTACTS_MARKETING_LIST_ID`
    FOREIGN KEY (`MARKETING_LIST_ID`)
    REFERENCES `marketing_lists` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `marketing_lists_customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `marketing_lists_customers` (
  `CUSTOMER_ID` BIGINT(20) NOT NULL,
  `MARKETING_LIST_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`CUSTOMER_ID`, `MARKETING_LIST_ID`),
  INDEX `FK_MARKETING_LISTS_CUSTOMERS_MARKETING_LIST_ID` (`MARKETING_LIST_ID` ASC),
  CONSTRAINT `FK_MARKETING_LISTS_CUSTOMERS_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`),
  CONSTRAINT `FK_MARKETING_LISTS_CUSTOMERS_MARKETING_LIST_ID`
    FOREIGN KEY (`MARKETING_LIST_ID`)
    REFERENCES `marketing_lists` (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `opportunities`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `opportunities` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `BUDGET_AMOUNT` DOUBLE NULL DEFAULT NULL,
  `CLOSE_DATE` DATETIME NULL DEFAULT NULL,
  `CLOSE_REASON` VARCHAR(255) NULL DEFAULT NULL,
  `CLOSE_REVENUE` DOUBLE NULL DEFAULT NULL,
  `COMMENTS` VARCHAR(255) NULL DEFAULT NULL,
  `CREATION_DATE` DATETIME NOT NULL,
  `CUSTOMER_NEED` VARCHAR(255) NULL DEFAULT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `NAME` VARCHAR(255) NOT NULL,
  `PROBABILITY` DOUBLE NULL DEFAULT NULL,
  `PROPOSED_SOLUTION` VARCHAR(255) NULL DEFAULT NULL,
  `STATUS` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `CHANNEL_ID` BIGINT(20) NOT NULL,
  `CONTACT_ID` BIGINT(20) NULL DEFAULT NULL,
  `CUSTOMER_ID` BIGINT(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `NAME` (`NAME` ASC),
  UNIQUE INDEX `UNQ_OPPORTUNITIES_0` (`NAME` ASC),
  INDEX `FK_OPPORTUNITIES_CUSTOMER_ID` (`CUSTOMER_ID` ASC),
  INDEX `FK_OPPORTUNITIES_CHANNEL_ID` (`CHANNEL_ID` ASC),
  INDEX `FK_OPPORTUNITIES_CONTACT_ID` (`CONTACT_ID` ASC),
  CONSTRAINT `FK_OPPORTUNITIES_CHANNEL_ID`
    FOREIGN KEY (`CHANNEL_ID`)
    REFERENCES `channels` (`ID`),
  CONSTRAINT `FK_OPPORTUNITIES_CONTACT_ID`
    FOREIGN KEY (`CONTACT_ID`)
    REFERENCES `people` (`ID`),
  CONSTRAINT `FK_OPPORTUNITIES_CUSTOMER_ID`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `customers` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 17
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sales_processes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sales_processes` (
  `ID` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` DATETIME NOT NULL,
  `LAST_UPDATE_DATE` DATETIME NOT NULL,
  `START_DATE` DATETIME NOT NULL,
  `STEP` VARCHAR(255) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `CHANNEL_ID` BIGINT(20) NOT NULL,
  `LEAD_ID` BIGINT(20) NULL DEFAULT NULL,
  `OPPORTUNITY_ID` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  INDEX `FK_SALES_PROCESSES_LEAD_ID` (`LEAD_ID` ASC),
  INDEX `FK_SALES_PROCESSES_CHANNEL_ID` (`CHANNEL_ID` ASC),
  INDEX `FK_SALES_PROCESSES_OPPORTUNITY_ID` (`OPPORTUNITY_ID` ASC),
  CONSTRAINT `FK_SALES_PROCESSES_CHANNEL_ID`
    FOREIGN KEY (`CHANNEL_ID`)
    REFERENCES `channels` (`ID`),
  CONSTRAINT `FK_SALES_PROCESSES_LEAD_ID`
    FOREIGN KEY (`LEAD_ID`)
    REFERENCES `leads` (`ID`),
  CONSTRAINT `FK_SALES_PROCESSES_OPPORTUNITY_ID`
    FOREIGN KEY (`OPPORTUNITY_ID`)
    REFERENCES `opportunities` (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 122
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
